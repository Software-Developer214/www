URL = ''
window.addEventListener('DOMContentLoaded', () => {
	document.querySelectorAll('.nav-link').forEach((item) => {
		//console.log(item.href.split('#')[1]);
		item.addEventListener('click', (e) => {
			console.log(item.dataset.value);
         
            
        
            
            
            
            
            
            //fetch('$/new_chat&tab='+item.dataset.value)
			var data_panel = document.getElementById("data-panel");
			chosen_avatar = "";
			chosen_pers_name = ""
			document.getElementById('chosen_personality').innerHTML = ""
			document.getElementById('send_message_form').disabled = true;

			var children = document.getElementById('send_message_form').children;
			var i;
			for (i = 0; i < children.length; i++) {
				children[i].disabled = true;
			}
			document.getElementById('chat_input').value = "";

			document.getElementById('story_input').value = "";

			//optionChooseButtons = document.querySelectorAll('.option-choose')
			optionChooseButtons.forEach(btn => {
				btn.classList.remove("active");

			})
            checkboxes.forEach(btn => {
					btn.checked = false;
                //btn.removeAttr()

				})


			var pers_radios = document.querySelectorAll('.personality-chat');

			for (i in pers_radios) {
				pers_radios[i].checked = false
			}

			data_panel.style.display = "block";
			//document.querySelector(`#${item.href.split('#')[1]}`).innerHTML = data['html'];

            
            var myurl=window.location.href;
            
        console.log("-- myurl:",myurl);
            //window.location
            
        var xhr = new XMLHttpRequest();
        //xhr.open('GET', '/new_chat&tab='+item.dataset.value, true); url="/change_selectLocation?name="+url
        xhr.open('GET', '/new_chat?tab='+item.dataset.value, true);
        xhr.onload = function (e) {
          if (xhr.readyState === 4) {
            if (xhr.status === 200) {
              console.log(xhr.responseText);
            } else {
              console.error(xhr.statusText);
            }
          }
        };
            
        xhr.onerror = function (e) {
          console.error(xhr.statusText);
        };
        xhr.send(null); 
            
            

        var timer;
        timer = setInterval(function() {
 
            if (xhr.readyState == XMLHttpRequest.DONE) {
                console.log("new_chat ready")
                clearInterval(timer);
        //         
            }
         }, 1000);               
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

		});
	});
	var chosen_avatar = "";
	var chosen_pers_name = ""

	document.querySelectorAll('.personality-chat').forEach((item) => {
		//console.log(item.href.split('#')[1]);
		item.addEventListener('click', (e) => {
			var pers_radios = document.querySelectorAll('.personality-chat');

			for (i in pers_radios) {
				pers_radios[i].checked = false
			}

			//'input[name="pwd"]'
			var input_identifier = 'input[name="' + item.name + '"]';
			document.querySelector(input_identifier).checked = true;

			console.log(item.getAttribute('avatar'))

			chosen_avatar = item.getAttribute('avatar')
			chosen_pers_name = item.getAttribute('person_name')


			var chosen_personality_elem = document.getElementById('chosen_personality');
			var chosen_personality_html = '<h5 style = "width: 236px;" class="card-title">' + ' <img style="width:20%;" src="https://bootdey.com/img/Content/avatar/' + chosen_avatar + '" class="img-circle img-sm" alt="Profile Picture">' + '<br>'  + chosen_pers_name + '</h5>';
			chosen_personality_elem.innerHTML = chosen_personality_html;
			document.getElementById('send_message_form').disabled = false;
			var children = document.getElementById('send_message_form').children;

			var i;
			for (i = 0; i < children.length; i++) {
				children[i].disabled = false;
			}


		});
	});


	document.querySelector('.submit-chat').addEventListener('click', (e) => {
		const text = document.querySelector('.chat-input').value;
		console.log(text)
		fetch(`${URL}&value=1&text=${text}`)
			.then(response => {
				return response.json();
			}).then((data) => {
				console.log(data)
				document.getElementById('chat_input').value = "";
				//PUT DATA TO CHAT HERE
			})
	})

	document.querySelector('.submit-story').addEventListener('click', (e) => {

		const text = document.querySelector('.input-story').value;
		console.log(text)
		fetch(`${URL}&value=2&text=${text}`)
			.then(response => {
				return response.json();
			}).then((data) => {
				//Change UI with data here.
				document.getElementById('story_input').value = "";
			})
	});

	var optionChooseButtons = document.querySelectorAll('.option-choose')
	console.log(optionChooseButtons)
	optionChooseButtons.forEach(btn => {
		btn.addEventListener('click', e => {
			btn.classList.toggle('active')

		})
	})
	document.querySelector('.submit-choose').addEventListener('click', e => {
		let selectedBtns = [...optionChooseButtons].filter((btn) => {
			return btn.classList.contains('active')
		})
		selectedBtns = selectedBtns.map(btn => {
			return btn.childNodes[0].textContent
		})
        console.log(selectedBtns)
		fetch(`${URL}&value=3&options=${selectedBtns}`)
        
        
        //optionChooseButtons = document.querySelectorAll('.option-choose')
			optionChooseButtons.forEach(btn => {
				btn.classList.remove("active")

			})
	})
    
   	var checkboxes = document.querySelectorAll('.option-checkboxes') 
    
	document.querySelector('.submit-checkboxes').addEventListener('click', e => {

		const values = [...checkboxes].filter(el => {
			return el.checked
		}).map(el => {
			//document.querySelector(`label[for="#${el.id}"`).textContent
            document.querySelector('label[for="'+el.id+'"').textContent
            
		});
        //console.log(values)
		fetch(`${URL}&value=4&data=${values}`)
			.then(response => {
				return response.json()
			})
			.then(data => {

				//optionChooseButtons = document.querySelectorAll('.option-checkboxes')
				checkboxes.forEach(btn => {
					btn.checked = false;

				})


			})
	});
    
   function getCookie(cname) {
      var name = cname + "=";
      var decodedCookie = decodeURIComponent(document.cookie);
      var ca = decodedCookie.split(';');
      for(var i = 0; i <ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
          c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
          return c.substring(name.length, c.length);
        }
      }
      return "";
}  
        var mycookie = getCookie("sessionID");
        console.log("mycookie: ", mycookie);
        
   
    
    
    
})