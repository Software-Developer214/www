from kivy.app import App
from kivy.uix.screenmanager import Screen
from kivy.uix.button import Button
from kivy.uix.label import Label 
from kivy.uix.dropdown import DropDown
from kivy.uix.textinput import TextInput
from kivy.base import runTouchApp
from kivy.uix.checkbox import CheckBox 
from kivy.uix.tabbedpanel import TabbedPanel
from kivy.uix.tabbedpanel import TabbedPanelItem
from kivy.graphics import Line, InstructionGroup
from kivy.uix.slider import Slider 
from kivy.graphics import *
from kivy.properties import ObjectProperty, BooleanProperty
from kivy.uix.floatlayout import FloatLayout 
from kivy.config import Config  
import asyncio
import socket
import sys
import io
import serial
from kivy.clock import Clock
import datetime
import os
import re
import subprocess
import platform
default_font_size = "10sp"
class DEF_TITAN:
    COM_SERIAL = 0
    COM_ETHERNET = 1
    TCPClieantAvailableWaitTick = 100000
    SACStr = "SAC"
    SAYStr = "SAY"
    SASStr = "SAS"

    SASM1Str = "SASM1"
    SASM2Str = "SASM2"
    ST_ENABLE = 0x1
    ST_IN_POSITION = 0x2
    ST_MOVING = 0x4
    ST_FAULT = 0x8
    ST_HOMING_COMP = 0x10

    #*** Status Position Velocity Current Read
    CURQA = "CURQA" # ***Actual Current A
    CURDA = "CURDA"     # ***Actual Current D
    EX = "EX"           # ***Actual Encoder Position
    FLT = "FLT"         # ***Get Fault Code
    MST = "MST"         # ***Motor Status
    PERR = "PERR"       # ***Position Error
    POSD = "POSD"       # ***Target Demand Position
    VPROF = "VPROF"     # ***Target Demand Profile Velocity
    VX = "VX"           # ***Actual Velocity based on Encoder Rate

    # *** Clear Error
    ECLEARX = "ECLEARX" # ***Clear Error

    # *** Lights
    LED = "LED"         # ***LED Light
    RGB = "RGB"         # ***RGB Light

    # *** Motion Stop
    STOPX = "STOPX"     # ***Stop Motion

    # *** Servo On Off Reset
    SVOFF = "SVOFF"     # ***Servo Off
    SVON = "SVON"       # ***Servo On
    SVRST = "SVRST"     # ***Reset Servo

    # *** Speed Accel Decel Jerk
    ACC = "ACC"         # ***Acceleration Rate
    DEC = "DEC"         # ***Deceleration Rate
    HSPD = "HSPD"       # ***Target Speed
    JERK = "JERK"       # ***Target Jerk
    SCURVE = "SCURVE"   # ***Set S Curve Profile
    TRAP = "TRAP"       # ***Set Trapezoidal Profile

    # *** Target Position
    X = "X"             # ***Perform Absolute Position Move

    # ***Jogging
    JOGXN = "JOGXN"     # ***Jog in Negative Direction
    JOGXP = "JOGXP"     # ***Jog in Positive Direction

    # *** Homing
    HMODE = "HMODE"     # ***Homing Mode
    HOMEX = "HOMEX"     # ***Perform Home

    # *** Gains
    CGAINF = "CGAINF"   # ***Current Gain
    IGAINF = "IGAINF"   # ***Integeral Gain
    PGAINF = "PGAINF"   # ***Proportional Gain
    VGAINF = "VGAINF"   # ***Velocity Gain
    KFCF = "KFCF"       # ***Kalman Filter for Current
    KFNF = "KFNF"       # ***Kalman Filter for Position

    # *** Digital Inputs Outputs, Analog Input
    DIN = "DIN"         # ***Digital Input
    DOA = "DOA"         # ***Digital Output 1
    DOB = "DOB"         # ***Digital Output 2
    DOC = "DOC"         # ***Digital Output 3
    DOUT = "DOUT"       # ***Digital Output for all 3 bits
    AIN = "AIN"         # ***Analog Input Value
    V = "V"             # ***Variable
    FIRMVS = "FIRMVS"   # ***Firmware Version
    MOTNAME = "MOTNAME" # ***Motor Name
    PWRV = "PWRV"       # ***Power Input Voltage
    PWRC = "PWRC"       # ***Power Input Current
    TEMP = "TEMP"       # ***Temperature

    # *** A-Script Program Control
    GOSUB = "GOSUB"    # ***Run Sub Routine
    SAC = "SAC"         # ***Standalone Program Control
    SASM = "SASM"       # ***Standalone Program Status

    serverIP = ""

class comm:
    comType = DEF_TITAN.COM_SERIAL
    skiptimeout = 0
    read_try = 0
    comStat = 0
    socketStat = False
    comPort = serial.Serial()

    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    def Disconnect():
        try:
            if comm.comType == DEF_TITAN.COM_SERIAL:
                comm.comPort.close()
                
            else:
                comm.client.close()
                comm.socketStat = False
            return True
        except:
          return False

    def Connect(typeNumber, port, reply_timeout):
        try:
            comm.comType = typeNumber
            if comm.comType == DEF_TITAN.COM_SERIAL:
                
                if comm.comPort != None and comm.comPort.is_open:
                    comm.comPort.close()
                else:
                    tout = 0
                    tout = int( reply_timeout)
                    if tout < 100:
                        tout = 100
                    elif tout > 1000:
                        tout = 1000
                    comm.comPort = serial.Serial(port, 115200, timeout=tout)
                    return True
                
            else:
                comm.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                comm.client.connect((port, 5000))
                DEF_TITAN.serverIP = port
                reply_timeout_val = 0

                if reply_timeout != int(reply_timeout):
                    reply_timeout_val = int(reply_timeout)
                else:
                    reply_timeout_val = 100
                if reply_timeout_val < 5:
                    reply_timeout_val = 5
                if reply_timeout_val > 100:
                    reply_timeout_val = 100
                DEF_TITAN.TCPClieantAvailableWaitTick = 200000
                comm.socketStat = True
                return True
        except socket.error as msg:
            print ("Couldnt connect with the socket-server: %s\n terminating program" % msg)
            comm.socketStat = False
            return False

    def IsConnected():
        if comm.comType == DEF_TITAN.COM_SERIAL:
            return comm.comPort != None and comm.comPort.is_open
        else:
            return comm.socketStat

    def Send(data):
        try:
            if comm.comType == DEF_TITAN.COM_SERIAL:
                if comm.comPort != None and comm.comPort.is_open:
                    output = io.StringIO()
                    output.write(data+"\n\r")
                    comm.comPort.write(bytes(output.getvalue(),"utf-8"))  
            else:
                data = data + chr(13) + chr(10)
                comm.client.sendall(bytes(data,'UTF-8'))   
            return True
        except Exception:
            print("Communication Port Error")
            comm.comStat = -2
        return False

    def Recv():
        try:
            if comm.comType == DEF_TITAN.COM_SERIAL:
                if comm.comPort != None and comm.comPort.is_open:
                    retstr = ""
                    comm.comPort.flush() # it is buffering. required to get the data out *now*
                    retstr = comm.comPort.readline().decode("utf-8")
                    comm.read_try = 0
                    return retstr
                else:
                    return ""
            else:
                counter = 0
                maxcounter = DEF_TITAN.TCPClieantAvailableWaitTick
                if maxcounter < 50000:
                    maxcounter = 50000
                if maxcounter > 500000:
                    maxcounter = 500000
                data = ""
                data = comm.client.recv(1024).decode() 
                comm.read_try = 0
                return data
            return ""
        except Exception:
            print("communication port error")
            comm.comStat = -4
        return ""


class TITAN_SerialCom:
        ComStatus = False
        PortStr = ""
        netid = 0
        comType = DEF_TITAN.COM_SERIAL
        value = []
        regex = r"[^;^=^\r]+"
        regex1 = r"[^\n^\r]+"

        def LED(stat):
            try:
                if (stat != 0) & (stat != 1):
                    return -3
                if int(TITAN_SerialCom.netid) < 10:
                    comm.Send("@0" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.LED + "=" + str(stat))
                else:
                    comm.Send("@" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.LED + "=" + str(stat))
                resp = comm.Recv()
                if len(str(resp)) > 0:
                    TITAN_SerialCom.value = re.findall(TITAN_SerialCom.regex, str(resp), re.MULTILINE)
                    return int(TITAN_SerialCom.value[1])
                return 0
            except:
                return -1

        def DOBit(bit, stat):
            try:
                cmdStr = DEF_TITAN.DOA
                if bit == 0:
                    cmdStr = DEF_TITAN.DOA
                elif bit == 1:
                    cmdStr = DEF_TITAN.DOB
                elif bit == 2:
                    cmdStr = DEF_TITAN.DOC
                else:
                    return -2
                if (stat != 0) & (stat != 1):
                    return -3
                if int(TITAN_SerialCom.netid) < 10:
                    comm.Send("@0" + str(TITAN_SerialCom.netid) + ":" + cmdStr + "=" + str(stat))
                else:
                    comm.Send("@" + str(TITAN_SerialCom.netid) + ":" + cmdStr + "=" + str(stat))
                resp = comm.Recv()
                if len(str(resp)) > 0:
                    TITAN_SerialCom.value = re.findall(TITAN_SerialCom.regex, str(resp), re.MULTILINE)
                    return int(TITAN_SerialCom.value[1])
                return 0
            except:
                return -1

        def RGB(stat):
            try:
                if (stat < 0) | (stat > 7):
                    return -3
                if int(TITAN_SerialCom.netid) < 10:
                    comm.Send("@0" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.RGB + "=" + str(stat))
                else:
                    comm.Send("@" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.RGB + "=" + str(stat))
                resp = comm.Recv()
                if len(str(resp)) > 0:
                    TITAN_SerialCom.value = re.findall(TITAN_SerialCom.regex, str(resp), re.MULTILINE)
                    return int(TITAN_SerialCom.value[1])
                return 0
            except:
                return -1

        def WRITE_VAR(vn, vval):
            try:
                strn = str(int(vn) - 1)
                if int(TITAN_SerialCom.netid) < 10:
                    comm.Send("@0" + str(TITAN_SerialCom.netid) + ":" + "V[" + strn + "]" + "=" + str(vval))
                else:
                    comm.Send("@" + str(TITAN_SerialCom.netid) + ":" + "V[" + strn + "]" + "=" + str(vval))
                resp = comm.Recv()
                if len(str(resp)) > 0:
                    TITAN_SerialCom.value = re.findall(TITAN_SerialCom.regex, str(resp), re.MULTILINE)
                    vval = int(TITAN_SerialCom.value[1])
                    return True, vn, vval
                return False, vn, vval
            except:
                comm.Recv()
            return False, vn, vval

        def READ_VAR(vn, vval):
            try:
                strn = str(int(vn) - 1)
                if int(TITAN_SerialCom.netid) < 10:
                    comm.Send("@0" + str(TITAN_SerialCom.netid) + ":" + "V[" + strn + "]")
                else:
                    comm.Send("@" + str(TITAN_SerialCom.netid) + ":" + "V[" + strn + "]")
                resp = comm.Recv()
                if len(str(resp)) > 0:
                    TITAN_SerialCom.value = re.findall(TITAN_SerialCom.regex, str(resp), re.MULTILINE)
                    vval = int(TITAN_SerialCom.value[1])
                    return True, vn, vval
                return False, vn, vval
            except:
                comm.Recv()
            return False, vn, vval

        def EX_SET(nTarget):
            if int(TITAN_SerialCom.netid) < 10:
                comm.Send("@0" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.EX + "=" + str(nTarget))
            else:
                comm.Send("@" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.EX + "=" + str(nTarget))
            resp = comm.Recv()
            return

        def SVON():
            try:
                if int(TITAN_SerialCom.netid) < 10:
                    comm.Send("@0" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.SVON)
                else:
                    comm.Send("@" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.SVON)
                resp = comm.Recv()
                if len(str(resp)) > 0:
                    TITAN_SerialCom.value = re.findall(TITAN_SerialCom.regex, str(resp), re.MULTILINE)
                    return int(TITAN_SerialCom.value[1])
                return 0
            except:
                return -1

        def SVOFF():
            try:
                if int(TITAN_SerialCom.netid) < 10:
                    comm.Send("@0" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.SVOFF)
                else:
                    comm.Send("@" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.SVOFF)
                resp = comm.Recv()
                if len(str(resp)) > 0:
                    TITAN_SerialCom.value = re.findall(TITAN_SerialCom.regex, str(resp), re.MULTILINE)
                    return int(TITAN_SerialCom.value[1])
                return 0
            except:
                return -1

        def ECLEARX():
            try:
                if int(TITAN_SerialCom.netid) < 10:
                    comm.Send("@0" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.ECLEARX)
                else:
                    comm.Send("@" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.ECLEARX)
                resp = comm.Recv()
                if len(str(resp)) > 0:
                    TITAN_SerialCom.value = re.findall(TITAN_SerialCom.regex, str(resp), re.MULTILINE)
                    return int(TITAN_SerialCom.value[1])
                return 0
            except:
                return -1

        def JOGXP(hspd, accel, decel, jerk, profile):
            try:
                profileStr = DEF_TITAN.TRAP
                if profile == 1:
                    profileStr = DEF_TITAN.SCURVE
                if int(TITAN_SerialCom.netid) < 10:
                    comm.Send("@0" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.HSPD + "=" + str(hspd) + ";" + DEF_TITAN.ACC + "=" + str(accel) + ";" + DEF_TITAN.DEC + "=" + str(decel) + ";" + DEF_TITAN.JERK + "=" + str(jerk) + ";" + profileStr + ";" + DEF_TITAN.JOGXP)
                else:
                    comm.Send("@" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.HSPD + "=" + str(hspd) + ";" + DEF_TITAN.ACC + "=" + str(accel) + ";" + DEF_TITAN.DEC + "=" + str(decel) + ";" + DEF_TITAN.JERK + "=" + str(jerk) + ";" + profileStr + ";" + DEF_TITAN.JOGXP)
                resp = comm.Recv()
                if len(str(resp)) > 0:
                    TITAN_SerialCom.value = re.findall(TITAN_SerialCom.regex, str(resp), re.MULTILINE)
                    return int(TITAN_SerialCom.value[11])
                return 0
            except:
                return -1

        def JOGXN(hspd, accel, decel, jerk, profile):
            try:
                profileStr = DEF_TITAN.TRAP
                if profile == 1:
                    profileStr = DEF_TITAN.SCURVE
                if int(TITAN_SerialCom.netid) < 10:
                    comm.Send("@0" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.HSPD + "=" + str(hspd) + ";" + DEF_TITAN.ACC + "=" + str(accel) + ";" + DEF_TITAN.DEC + "=" + str(decel) + ";" + DEF_TITAN.JERK + "=" + str(jerk) + ";" + profileStr + ";" + DEF_TITAN.JOGXN)
                else:
                    comm.Send("@" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.HSPD + "=" + str(hspd) + ";" + DEF_TITAN.ACC + "=" + str(accel) + ";" + DEF_TITAN.DEC + "=" + str(decel) + ";" + DEF_TITAN.JERK + "=" + str(jerk) + ";" + profileStr + ";" + DEF_TITAN.JOGXN)
                resp = comm.Recv()
                if len(str(resp)) > 0:
                    TITAN_SerialCom.value = re.findall(TITAN_SerialCom.regex, str(resp), re.MULTILINE)
                    return int(TITAN_SerialCom.value[11])
                return 0
            except:
                return -1

        def HOMEX(hmode, hspd, accel, decel, jerk, profile):
            try:
                profileStr = DEF_TITAN.TRAP
                if profile == 1:
                    profileStr = DEF_TITAN.SCURVE
                if int(TITAN_SerialCom.netid) < 10:
                    comm.Send("@0" + str(TITAN_SerialCom.netid) + ":" + "SVA" + "=" + str(hmode) + ";" + DEF_TITAN.HMODE + "=" + str(hmode) + ";" + DEF_TITAN.HSPD + "=" + str(hspd) + ";" + DEF_TITAN.ACC + "=" + str(accel) + ";" + DEF_TITAN.DEC + "=" + str(decel) + ";" + DEF_TITAN.JERK + "=" + str(jerk) + ";" + profileStr + ";" + DEF_TITAN.HOMEX)
                else:
                    comm.Send("@" + str(TITAN_SerialCom.netid) + ":" + "SVA" + "=" + str(hmode) + ";" + DEF_TITAN.HMODE + "=" + str(hmode) + ";" + DEF_TITAN.HSPD + "=" + str(hspd) + ";" + DEF_TITAN.ACC + "=" + str(accel) + ";" + DEF_TITAN.DEC + "=" + str(decel) + ";" + DEF_TITAN.JERK + "=" + str(jerk) + ";" + profileStr + ";" + DEF_TITAN.HOMEX)
                resp = comm.Recv()
                if len(str(resp)) > 0:
                    TITAN_SerialCom.value = re.findall(TITAN_SerialCom.regex, str(resp), re.MULTILINE)
                    return int(TITAN_SerialCom.value[15])
                return 0
            except:
                return -1

        def X(target, hspd, accel, decel, jerk, scurve):
            try:
                profile = DEF_TITAN.TRAP
                if scurve == 1:
                    profile = DEF_TITAN.SCURVE
                if int(TITAN_SerialCom.netid) < 10:
                    comm.Send("@0" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.HSPD + "=" + str(hspd) + ";" + DEF_TITAN.ACC + "=" + str(accel) + ";" + DEF_TITAN.DEC + "=" + str(decel) + ";" + DEF_TITAN.JERK + "=" + str(jerk) + ";" + profile + ";" + DEF_TITAN.X + "=" + str(target))
                else:
                    comm.Send("@" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.HSPD + "=" + str(hspd) + ";" + DEF_TITAN.ACC + "=" + str(accel) + ";" + DEF_TITAN.DEC + "=" + str(decel) + ";" + DEF_TITAN.JERK + "=" + str(jerk) + ";" + profile + ";" + DEF_TITAN.X + "=" + str(target))
                resp = comm.Recv()
                if len(str(resp)) > 0:
                    TITAN_SerialCom.value = re.findall(TITAN_SerialCom.regex, str(resp), re.MULTILINE)
                    return int(TITAN_SerialCom.value[11])
                return 0
            except:
                return -1

        def STOPX(hspd, accel, decel):
            try:
                if int(TITAN_SerialCom.netid) < 10:
                    comm.Send("@0" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.HSPD + "=" + str(hspd) + ";" + DEF_TITAN.ACC + "=" + str(accel) + ";" + DEF_TITAN.DEC + "=" + str(decel) + ";" + DEF_TITAN.STOPX)
                else:
                    comm.Send("@" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.HSPD + "=" + str(hspd) + ";" + DEF_TITAN.ACC + "=" + str(accel) + ";" + DEF_TITAN.DEC + "=" + str(decel) + ";" + DEF_TITAN.STOPX)
                resp = comm.Recv()
                if len(str(resp)) > 0:
                    TITAN_SerialCom.value = re.findall(TITAN_SerialCom.regex, str(resp), re.MULTILINE)
                    return int(TITAN_SerialCom.value[7])
                return 0
            except:
                return -1

        def SCURVE():
            try:
                if int(TITAN_SerialCom.netid) < 10:
                    comm.Send("@0" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.SCURVE)
                else:
                    comm.Send("@" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.SCURVE)
                resp = comm.Recv()
                if len(str(resp)) > 0:
                   return True
                return False
            except:
                return False

        def TRAP():
            try:
                if int(TITAN_SerialCom.netid) < 10:
                    comm.Send("@0" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.TRAP)
                else:
                    comm.Send("@" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.TRAP)
                resp = comm.Recv()
                if len(str(resp)) > 0:
                    return True
                return False
            except:
                return False

        def SA_COMMAND(nId):
            if int(TITAN_SerialCom.netid) < 10:
                comm.Send("@0" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.SACStr + "=" + str(nId))
            else:
                comm.Send("@" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.SACStr + "=" + str(nId))
            resp = comm.Recv()
            return

        def ALLSTATUS(digital_input, digital_out, motor_stat, enc_pos, enc_vel, tar_pos, tar_vel, led_stat, rgb_stat):
            resp = ""
            try:
                if int(TITAN_SerialCom.netid) < 10:
                    comm.Send("@0" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.DIN + ";" + DEF_TITAN.DOUT + ";" + DEF_TITAN.MST + ";" + DEF_TITAN.EX + ";" + DEF_TITAN.VX + ";" + DEF_TITAN.POSD + ";" + DEF_TITAN.VPROF + ";" + DEF_TITAN.LED + ";" + DEF_TITAN.RGB)
                else:
                    comm.Send("@" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.DIN + ";" + DEF_TITAN.DOUT + ";" + DEF_TITAN.MST + ";" + DEF_TITAN.EX + ";" + DEF_TITAN.VX + ";" + DEF_TITAN.POSD + ";" + DEF_TITAN.VPROF + ";" + DEF_TITAN.LED + ";" + DEF_TITAN.RGB)
                resp = comm.Recv();
                if len(str(resp)) > 0: 
                    TITAN_SerialCom.value = re.findall(TITAN_SerialCom.regex, str(resp), re.MULTILINE)

                    digital_input = int(str(TITAN_SerialCom.value[1]), 0)

                    digital_out = int(str(TITAN_SerialCom.value[3]), 0)
                    motor_stat = int(str(TITAN_SerialCom.value[5]), 0)
                    enc_pos = int(str(TITAN_SerialCom.value[7]))
                    enc_vel = float(TITAN_SerialCom.value[9])
                    tar_pos = int(TITAN_SerialCom.value[11])
                    tar_vel = float(TITAN_SerialCom.value[13])
                    led_stat = int(TITAN_SerialCom.value[15])
                    rgb_stat = int(TITAN_SerialCom.value[17])
                    return True, digital_input, digital_out, motor_stat, enc_pos, enc_vel, tar_pos, tar_vel, led_stat, rgb_stat
            except:
                comm.Recv()
            return False, digital_input, digital_out, motor_stat, enc_pos, enc_vel, tar_pos, tar_vel, led_stat, rgb_stat

        def SOFTWARE_VERSION():
            try:
                if int(TITAN_SerialCom.netid) < 10:                    
                    comm.Send("@0" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.FIRMVS)
                    
                else:
                    comm.Send("@" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.FIRMVS)
                resp = comm.Recv();
               
                if len(str(resp)) > 0:
                    TITAN_SerialCom.value = re.findall(TITAN_SerialCom.regex, str(resp), re.MULTILINE)
                    tempStr = TITAN_SerialCom.value[1]
                    return float(tempStr) / float(100)
            except:
                resp = comm.Recv()
            return -1

        def GOSUBCMD(n, retA):
            try:
                if int(TITAN_SerialCom.netid) < 10:
                    comm.Send("@0" + str(TITAN_SerialCom.netid) + ":" + "GOSUB=" + str(n))
                else:
                    comm.Send("@" + str(TITAN_SerialCom.netid) + ":" + "GOSUB=" + str(n))
                resp = comm.Recv()
                if len(str(resp)) > 0:
                    TITAN_SerialCom.value = re.findall(TITAN_SerialCom.regex, str(resp), re.MULTILINE)
                    retA = int(TITAN_SerialCom.value[1])
                return retA
            except:
                comm.Recv()
            return 0

        def SAY():
            try:
                if int(TITAN_SerialCom.netid) < 10:
                    comm.Send("@0" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.SAYStr)
                else:
                    comm.Send("@" + str(TITAN_SerialCom.netid) + ":" + DEF_TITAN.SAYStr)
                resp = comm.Recv()
                if len(str(resp)) > 0:
                    TITAN_SerialCom.value = re.findall(TITAN_SerialCom.regex, str(resp), re.MULTILINE)
                    return TITAN_SerialCom.value[1]
            except:
                print("")
            return "0"

        def CommandReply(cmdStr, replyStr):
            try:
                comm.Send(cmdStr)
                resp = comm.Recv()
                if len(resp) > 0:
                    replyStr = resp
                    return True, cmdStr, replyStr
                else:
                    replyStr = ""
                    return False, cmdStr, replyStr
            except:
                comm.Recv()
            return False, cmdStr, replyStr

        def IsCommunicating():
            if comm.IsConnected() == False:
                return False
            comm.skiptimeout = 1
            str1 = str(TITAN_SerialCom.SOFTWARE_VERSION())
            if TITAN_SerialCom.SOFTWARE_VERSION() > 0:
                TITAN_SerialCom.ComStatus = True
                comm.skiptimeout = 0
                return True
            TITAN_SerialCom.ComStatus = False
            comm.skiptimeout = 0
            return False

        def Connect(port, reply_timeout):
            if comm.Connect(TITAN_SerialCom.comType, port, reply_timeout) == True:
                TITAN_SerialCom.PortStr = port
                return True
            else:
                TITAN_SerialCom.PortStr = "None"
                return False

        def Disconnect():
            TITAN_SerialCom.ComStatus = False
            return comm.Disconnect()

        def IsConnected():
            return comm.IsConnected()

class TITAN_Python_Sample_ProgramApp(App): 
    App.g_comstatus = False
    App.g_netindex = 0
    App.g_led = 0
    App.g_rgb = 0
    App.g_di = 0
    App.g_do = 0
    App.g_motorstat = 0
    App.g_encpos = 0
    App.g_encvel = 0
    App.g_tarpos = 0
    App.g_tarvel = 0

    App.DIDisplay = []
    App.DODisplay = []
    App.RGBDisplay = []

    def build(self):
        Config.set('graphics', 'resizable', False)  
        Config.set('kivy','window_icon','icon.png')
        Config.write()
        self.icon = 'icon.png'

        def EthernetConnectBtn_Click(instance):
            if TITAN_SerialCom.IsConnected() == True:
                CloseCom()
                return

            TITAN_SerialCom.comType = DEF_TITAN.COM_ETHERNET
            TITAN_SerialCom.ComStatus = False
            TITAN_SerialCom.Connect(IPAddress.text, "100")
            if TITAN_SerialCom.IsConnected() == True:
                App.g_netindex = startId.text
                TITAN_SerialCom.netid = App.g_netindex

                if TITAN_SerialCom.IsConnected() == True:
                    App.g_netindex = startId.text
                    TITAN_SerialCom.netid = App.g_netindex
                    if TITAN_SerialCom.IsCommunicating() == True:
                        App.g_comstatus = True
                        COMConnectBtn.background_color = (0.2, 0.2, 0.2, 1)
                        COMConnectBtn.disabled = True
                        COMConnectBtn.background_disabled_down = ""
                        COMConnectBtn.background_disabled_normal = ""
                        COMConnectBtn.text = "NA"
                        COMConnectBtn.font_size = "12sp"
                        COMConnectBtn.color = (0, 0, 0, 1)
                        EthernetConnectBtn.text = "Disconnect"
                        EthernetConnectBtn.background_color = (255, 0, 255, 1)
                        Button_Gosub.disabled = False
                        Button_Run0.disabled = False
                        Button_Run1.disabled = False
                        Button_Run2.disabled = False
                        Button_Enable.disabled = False
                        CommandTextbox.disabled = False
                        Button_Disable.disabled = False
                        Button_ClearFault.disabled = False
                        Button_X_Move1.disabled = False
                        Button_X_Move2.disabled = False
                        ReadVar.disabled = False
                        WriteVar.disabled = False
                        ButtonSetPos.disabled = False
                        Button_JogMinus.disabled = False
                        Button_JogPlus.disabled = False
                        JogVelBar.disabled = False
                        JogVelBar.value = 100
                        Button_Home.disabled = False
                        Button_STOPX.disabled = False
                        Button_ZeroVel.disabled = False
                        Button_STOPX.background_color = (255, 0, 0, 1)
                        LEDStat1.disabled = False
                        for i in range(8):
                            App.DIDisplay[i].disabled = False

                        for i in range(3):
                            App.DODisplay[i].disabled = False 
                            App.RGBDisplay[i].disabled = False                
                    else:
                        App.g_comstatus = False
                else:
                    App.g_comstatus = False
                    print("Ethernet Communication Port not available to open!")
            else:
                print("Cannot Connect to IP Address")
            return

        def ReadVar_Click(instance):
            try:
                if TITAN_SerialCom.IsConnected() == True:
                    vid = 0
                    vval = 0
                    vid = int(VarIDList.text[1 : len(VarIDList.text)])
                    ret, vid, vval = TITAN_SerialCom.READ_VAR(vid, vval)
                    if ret == False:
                        print("Var Read Error")
                    VarValue.text = str(vval)
            except:
                print("Read Variable Exception Error!")

        def WriteVar_Click(instance):
            try:
                if TITAN_SerialCom.IsConnected() == True:
                    vid = 0
                    ret = False
                    vval = 0
                    vval = int(VarValue.text)
                    vid = int(VarIDList.text[1 : len(VarIDList.text)])
                    ret, vid, vval = TITAN_SerialCom.WRITE_VAR(vid, vval)
                    if ret == False:
                        print("Var Write Error")
                    VarValue.text = str(vval)
            except:
                print("WRITE Variable Exception Error!")

        def COMConnectBtn_Click(instance):
            comPortStr = ""
            comPortStr = COMPort.text
            if comPortStr == "":
                comPortStr = "COM5"
            App.g_netindex = startId.text
            if TITAN_SerialCom.IsConnected() == True:
                CloseCom()
                return
            TITAN_SerialCom.comType = DEF_TITAN.COM_SERIAL
            TITAN_SerialCom.Connect(comPortStr, 100)
            if TITAN_SerialCom.IsConnected() == True:
                App.g_netindex = startId.text
                TITAN_SerialCom.netid = App.g_netindex
                if TITAN_SerialCom.IsCommunicating() == True:
                    App.g_comstatus = True;
                    EthernetConnectBtn.background_color = (0.2, 0.2, 0.2, 1)
                    EthernetConnectBtn.disabled = True
                    EthernetConnectBtn.background_disabled_down = ""
                    EthernetConnectBtn.background_disabled_normal = ""
                    EthernetConnectBtn.text = "NA"
                    EthernetConnectBtn.font_size = "12sp"
                    EthernetConnectBtn.color = (0, 0, 0, 1)
                    COMConnectBtn.text = "Disconnect"
                    COMConnectBtn.background_color = (255, 0, 255, 1)
                    Button_Gosub.disabled = False
                    Button_Run0.disabled = False
                    Button_Run1.disabled = False
                    Button_Run2.disabled = False
                    Button_Enable.disabled = False
                    CommandTextbox.disabled = False
                    Button_Disable.disabled = False
                    Button_ClearFault.disabled = False
                    Button_X_Move1.disabled = False
                    Button_X_Move2.disabled = False
                    ReadVar.disabled = False
                    WriteVar.disabled = False
                    ButtonSetPos.disabled = False
                    Button_JogMinus.disabled = False
                    Button_JogPlus.disabled =False
                    JogVelBar.disabled = False
                    JogVelBar.value = 100
                    Button_Home.disabled = False
                    Button_STOPX.disabled = False
                    Button_ZeroVel.disabled = False
                    Button_STOPX.background_color = (255, 0, 0, 1)
                    LEDStat1.disabled = False
                    for i in range(8):
                        App.DIDisplay[i].disabled = False

                    for i in range(3):
                        App.DODisplay[i].disabled = False 
                        App.RGBDisplay[i].disabled = False 
                else:
                    App.g_comstatus = False
            else:
                App.g_comstatus = False
                print("Communication Port")

        def Button_STOPX_Click(instance):
            try:
                if TITAN_SerialCom.IsConnected() == True:
                    SAStop(0)
                    SAStop(1)
                    SAStop(2)
                    accel = float(TextBox_TargetAccel.text)
                    decel = float(TextBox_TargetDecel.text)
                    TITAN_SerialCom.STOPX(0, accel, decel)
                    JogVelBar.value = 100
            except:
                print("Move Exception Error")

        def GosubBtn_Click(instance):
            if TITAN_SerialCom.IsConnected() == True:
                subnumber = 0
                stat = 0
                subnumber = int(SubNumberList.text)
                if TITAN_SerialCom.GOSUBCMD(subnumber, stat) != 1:
                    print("GOSUB Command Error.")

        def SARun(pn):
            if TITAN_SerialCom.IsConnected() == True:
                cn = 40
                if pn == 0:
                    cn = 40
                elif pn == 1:
                    cn = 41
                elif pn == 2:
                    cn = 42
                TITAN_SerialCom.SA_COMMAND(cn)
                reply_str = TITAN_SerialCom.SAY()
                if reply_str == "3":
                    print("Cannot run program.  Program is empty.")
                    return
                elif reply_str == "2":
                    print("Cannot run program.  Program is in error state.")
                    return
                elif reply_str == "1":
                    print("Cannot run program.  Program is not in idle.")
                    return

        def SAStop(pn):
            if TITAN_SerialCom.IsConnected() == True:
                cn = 40
                if pn == 0:
                    cn = 43
                elif pn == 1:
                    cn = 44
                elif pn == 2:
                    cn = 45
                TITAN_SerialCom.SA_COMMAND(cn)

        def ButtonSetPos_Click(instance):
            if TITAN_SerialCom.IsConnected() == True:
                target = 0
                target = int(TextBox_TargetPosition2.text)
                TITAN_SerialCom.EX_SET(target)

        def Button_X_Move2_Click(instance):
            try:
                if TITAN_SerialCom.IsConnected() == True:
                    target = 0
                    ret = 0
                    scurve = 0
                    if ScurveRadio.active == True:
                        scurve = 1
                    target = int(TextBox_TargetPosition2.text)
                    speed = float(TextBox_TargetSpeed.text)
                    accel = float(TextBox_TargetAccel.text)
                    decel = float(TextBox_TargetDecel.text)
                    jerk = float(TextBox_TargetJerk.text)
                    ret = TITAN_SerialCom.X(target, speed, accel, decel, jerk, scurve)
                    if ret != 1:
                        print("Move to Target Error")
            except:
                print("Move Exception Error")

        def Button_ZeroVel_Click(instance):
            try:
                ret = 0
                scurve = 0
                if ScurveRadio.active == True:
                    scurve = 1
                speed = float(TextBox_TargetSpeed.text)
                accel = float(TextBox_TargetAccel.text)
                decel = float(TextBox_TargetDecel.text)
                jerk = float(TextBox_TargetJerk.text)
                ret = TITAN_SerialCom.JOGXP(0, accel, decel, jerk, scurve)
                JogVelBar.value = 100
            except:
                print("Move Exception Error")

        def RLed1_DoubleClick(instance):
            if TITAN_SerialCom.IsConnected() == True:
                toggleRGB(0)

        def GLed1_DoubleClick(instance):
            if TITAN_SerialCom.IsConnected() == True:
                toggleRGB(1)

        def BLed1_DoubleClick(instance):
            if TITAN_SerialCom.IsConnected() == True:
                toggleRGB(2)

        def JogVelBar_Scroll(instance, val):
            if TITAN_SerialCom.IsConnected() == True:
                try:
                    ret = 0
                    scurve = 0
                    speed = 0.1
                    if ScurveRadio.active == True:
                        scurve = 1
                    speed = float(TextBox_TargetSpeed.text)
                    speed = speed * (val - 100) / float(100)
                    accel = float(TextBox_TargetAccel.text);
                    decel = float(TextBox_TargetDecel.text);
                    jerk = float(TextBox_TargetJerk.text);
                    ret = TITAN_SerialCom.JOGXP(speed, accel, decel, jerk, scurve)
                    if ret != 1:
                        ret = TITAN_SerialCom.JOGXP(0, accel, decel, jerk, scurve)
                        JogVelBar.value = 100
                        print("Jog Plus Error")
                except:
                    print("Move Exception Error")

        def Button_ClearFault_C_Click(instance):
            if TITAN_SerialCom.IsConnected() == True:
                ret = TITAN_SerialCom.ECLEARX()
                if ret != 1:
                    print("ECLEAR Error")

        def Run0_Click(instance):
            SARun(0)

        def Run1_Click(instance):
            SARun(1)

        def Run2_Click(instance):
            SARun(2)

        def LEDStat1_DoubleClick(instance):
            print("LED")
            if TITAN_SerialCom.IsConnected() == True:
                if LEDStat1.background_color == [0.5, 0.5, 0.5, 1]:
                    TITAN_SerialCom.LED(1)
                else:
                    TITAN_SerialCom.LED(0)

        def Button_Enable_C_Click(instance):
            if TITAN_SerialCom.IsConnected() == True:
                ret = TITAN_SerialCom.SVON()
                if ret != 1:
                    print("SVON Error")

        def Button_JogPlus_MouseDown_1(instance):
            try:
                JogVelBar.value = int(JogVelBar.value) + 1
                if TITAN_SerialCom.IsConnected() == True:
                    ret = 0
                    scurve = 0
                    if ScurveRadio.active == True:
                        scurve = 1
                    speed = float(TextBox_TargetSpeed.text)
                    accel = float(TextBox_TargetAccel.text)
                    decel = float(TextBox_TargetDecel.text)
                    jerk = float(TextBox_TargetJerk.text)
                    ret = TITAN_SerialCom.JOGXP(speed, accel, decel, jerk, scurve)
                    if ret != 1:
                        ret = TITAN_SerialCom.JOGXP(0, accel, decel, jerk, scurve)
                        print("Jog Plus Error")
            except:
                print("Move Exception Error")

        def Button_JogMinus_MouseDown_1(instance):
            try:
                JogVelBar.value = int(JogVelBar.value) - 1
                if TITAN_SerialCom.IsConnected() == True:
                    ret = 0
                    scurve = 0
                    if ScurveRadio.active == True:
                        scurve = 1
                    speed = float(TextBox_TargetSpeed.text)
                    accel = float(TextBox_TargetAccel.text)
                    decel = float(TextBox_TargetDecel.text)
                    jerk = float(TextBox_TargetJerk.text)
                    ret = TITAN_SerialCom.JOGXN(speed, accel, decel, jerk, scurve)
                    if ret != 1:
                        ret = TITAN_SerialCom.JOGXP(0, accel, decel, jerk, scurve)
                        print("Jog Minus Error")
            except:
                print("Move Exception Error")

        def Button_Disable_C_Click(instance):
            if TITAN_SerialCom.IsConnected() == True:
                ret = TITAN_SerialCom.SVOFF()
                if ret != 1:
                    print("SVOFF Error")

        def Timer1_Tick(dt):
            if App.g_comstatus == True:
                TITAN_SerialCom.netid = App.g_netindex
                bFlag, App.g_di, App.g_do, App.g_motorstat, App.g_encpos, App.g_encvel, App.g_tarpos, App.g_tarvel, App.g_led, App.g_rgb = TITAN_SerialCom.ALLSTATUS(App.g_di, App.g_do, App.g_motorstat, App.g_encpos, App.g_encvel, App.g_tarpos, App.g_tarvel, App.g_led, App.g_rgb)
                if bFlag == False:
                    App.g_comstatus = False
                    CloseCom()
                    return
                else:
                    STAT1.text = str(App.g_motorstat) + "\r\n"
                    if (App.g_motorstat & DEF_TITAN.ST_ENABLE) > 0:
                        STAT1.text = STAT1.text + "/ENA "
                    else:
                        STAT1.text = STAT1.text + "/DIS "
                    if (App.g_motorstat & DEF_TITAN.ST_IN_POSITION) > 0:
                        STAT1.text = STAT1.text + "/INP "
                    if (App.g_motorstat & DEF_TITAN.ST_MOVING) > 0:
                        STAT1.text = STAT1.text + "/MOV "
                    if (App.g_motorstat & DEF_TITAN.ST_FAULT ) > 0:
                        STAT1.text = STAT1.text + "/FLT "
                    if (App.g_motorstat & DEF_TITAN.ST_HOMING_COMP) > 0:
                        STAT1.text = STAT1.text + "/HM "

                    EX1.text = str(App.g_encpos)
                    if len(str(App.g_encvel)) > 3:
                        VX1.text = str(App.g_encvel)[0:3]
                    else:
                        VX1.text = str(App.g_encvel)
                    POSD1.text = str(App.g_tarpos)
                    if len(str(App.g_tarvel)) > 3:
                        VPROF1.text = str(App.g_tarvel)[0:3]
                    else:
                        VPROF1.text = str(App.g_tarvel)


                    for i in range(8):
                        if (App.g_di != 0)  and ((1 << i) != 0):
                            if App.DIDisplay[i].background_color != [0, 255, 0, 1]:
                                App.DIDisplay[i].background_color = (0, 255, 0, 1)
                        elif App.DIDisplay[i].background_color != [0.5, 0.5, 0.5, 1]:
                            App.DIDisplay[i].background_color = (0.5, 0.5, 0.5, 1)
                    for i in range(3):
                        if (App.g_do & (1 << i)) > 0:
                            if App.DODisplay[i].background_color != [255, 0, 0, 1]:
                                App.DODisplay[i].background_color = (255, 0, 0, 1)
                        elif App.DODisplay[i].background_color != [0.5, 0.5, 0.5, 1]:
                            App.DODisplay[i].background_color = (0.5, 0.5, 0.5, 1)

                    if App.g_led == 0:
                        if LEDStat1.background_color != [0.5, 0.5, 0.5, 1]:
                            LEDStat1.background_color = (0.5, 0.5, 0.5, 1)
                    elif LEDStat1.background_color != [0, 0, 255, 1]:
                        LEDStat1.background_color = (0, 0, 255, 1)
                    if (App.g_rgb & 1) > 0:
                        if RLed1.background_color != [255, 0, 0, 1]:
                            RLed1.background_color = (255, 0, 0, 1)
                    elif RLed1.background_color != [0.5, 0.5, 0.5, 1]:
                        RLed1.background_color = (0.5, 0.5, 0.5, 1)
                    if (App.g_rgb & 2) > 0:
                        if GLed1.background_color != [0, 255, 0, 1]:
                            GLed1.background_color = (0, 255, 0, 1)
                    elif GLed1.background_color != [0.5, 0.5, 0.5, 1]:
                        GLed1.background_color = (0.5, 0.5, 0.5, 1)
                    if (App.g_rgb & 4) > 0:
                        if BLed1.background_color != [0, 0, 255, 1]:
                            BLed1.background_color = (0, 0, 255, 1)
                    elif BLed1.background_color != [0.5, 0.5, 0.5, 1]:
                        BLed1.background_color = (0.5, 0.5, 0.5, 1)


        def DoHome_Click(instance):
            try:
                if TITAN_SerialCom.IsConnected() == True:
                    ret = 0
                    hmode = 0
                    scurve = 0;
                    if ScurveRadio.active == True:
                        scurve = 1
                    hmode = int(ComboBox_HomeMode.text[0])
                    speed = float(TextBox_TargetSpeed.text)
                    accel = float(TextBox_TargetAccel.text)
                    decel = float(TextBox_TargetDecel.text)
                    jerk = float(TextBox_TargetJerk.text)
                    ret = TITAN_SerialCom.HOMEX(hmode, speed, accel, decel, jerk, scurve)
                    if int(ret) != 1:
                        print("Jog Plus Error")
            except:
                print("Move Exception Error")

        def Button_MoveTest1_Click(instance):
            if TITAN_SerialCom.IsConnected() == True:
                try:
                    target = 0
                    ret = 0
                    scurve = 0
                    if ScurveRadio.active == True:
                        scurve = 1
                    target = int(TextBox_TargetPosition1.text)
                    speed = float(TextBox_TargetSpeed.text)
                    accel = float(TextBox_TargetAccel.text)
                    decel = float(TextBox_TargetDecel.text)
                    jerk = float(TextBox_TargetJerk.text)
                    ret = TITAN_SerialCom.X(target, speed, accel, decel, jerk, scurve)
                    if ret != 1:
                        print("Move to Target Error")
                except:
                    print("Move to Target Error")

        def ScurveRadio_CheckedChanged(instance):
            if TITAN_SerialCom.IsConnected() == True:
                TITAN_SerialCom.SCURVE()

        def DO11_DoubleClick(instance):
            TriggerDO(0)

        def DO12_DoubleClick(instance):
            TriggerDO(1)

        def DO13_DoubleClick(instance):
            TriggerDO(2)

        def TrapRadio_CheckedChanged(instance):
            if TITAN_SerialCom.IsConnected() == True:
                TITAN_SerialCom.TRAP()

        def TriggerDO(bit):
            print(bit)
            if TITAN_SerialCom.IsConnected() == True:
                if App.DODisplay[bit].background_color == [0.5, 0.5, 0.5, 1]:
                    TITAN_SerialCom.DOBit(bit, 1)
                else:
                    TITAN_SerialCom.DOBit(bit, 0)

        def toggleRGB(bit):
            currentStat = 0 
            if RLed1.background_color == [255, 0, 0, 1]:
                currentStat = currentStat | 1
            if GLed1.background_color == [0, 255, 0, 1]:
                currentStat = currentStat | 2
            if BLed1.background_color == [0, 0, 255, 1]:
                currentStat = currentStat | 4

            if App.RGBDisplay[bit].background_color == [0.5, 0.5, 0.5, 1]:
                currentStat = currentStat | (1 << bit)
            else:
                currentStat = currentStat & (7 & ~ (1 << bit))

            TITAN_SerialCom.RGB(currentStat)
            return currentStat

        def CommandTextbox_KeyPress(instance):
            text = str(instance.text)
            try:
                replyStr = ""
                cmdStr = text
                bFlag, cmdStr, replyStr = TITAN_SerialCom.CommandReply(cmdStr, replyStr)
                if bFlag == True:
                    ReplyTextbox.text = str(re.findall(TITAN_SerialCom.regex1, str(replyStr), re.MULTILINE)[0])
                else:
                    ReplyTextbox.text = "<NOCOM>"
                CommandTextbox.text = ""
            except:
                print("Command and Reply Exception Error!")

        def CloseCom():
            TITAN_SerialCom.Disconnect()
            EthernetConnectBtn.text = "Connect"
            EthernetConnectBtn.background_color = (0, 30, 50, 1)
            EthernetConnectBtn.disabled = False
            COMConnectBtn.text = "Connect"
            COMConnectBtn.background_color = (0, 255, 0, 1)
            COMConnectBtn.disabled = False
            App.g_comstatus = False
            JogVelBar.value = 100

            Button_STOPX.background_color = (0.7, 0.7, 0.7, 1)
            LEDStat1.background_color = (0.7, 0.7, 0.7, 1)
            for i in range(8):
                App.DIDisplay[i].background_color = (0.7, 0.7, 0.7, 1)

            for i in range(3):
                App.DODisplay[i].background_color = (0.7, 0.7, 0.7, 1)
                App.RGBDisplay[i].background_color = (0.7, 0.7, 0.7, 1)


        layout = FloatLayout(size=(800,600), pos=(0,0))
        with layout.canvas:
            Color(1,1,1,1)
            Icon = "icon.png"
            Rectangle(pos=layout.pos, size=layout.size)

        Label50 = Label(text='Network ID', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(45, 550))
        layout.add_widget(Label50)

        dropdownStartID = DropDown()
        for index in range(24):
            btnStartId = Button(text='%d' % (index + 1), font_size = default_font_size, size_hint_y=None, background_color =(0.8, 0.8, 0.8, 1), color = (0, 0, 0, 1), background_normal = "", height=20)
            btnStartId.bind(on_release=lambda btnStartId: dropdownStartID.select(btnStartId.text))
            dropdownStartID.add_widget(btnStartId)
        startId = Button(text='1', color = (0, 0, 0, 1), background_color =(0.8, 0.8, 0.8, 1), background_normal = "", font_size = default_font_size, size_hint =(.1, .045), pos =(45, 520))
        startId.bind(on_release=dropdownStartID.open)
        dropdownStartID.bind(on_select=lambda instance, x: setattr(startId, 'text', x))
        layout.add_widget(startId)

        GroupBox4 = Label(text='Ethernet Communication', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(245, 565))
        layout.add_widget(GroupBox4)

        Label13 = Label(text='IP Address', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(240, 535))
        layout.add_widget(Label13)

        IPAddress = TextInput(text='192.168.1.100', font_size = default_font_size, size_hint =(.17, .04), pos =(218, 510))
        layout.add_widget(IPAddress) 

        EthernetConnectBtn = Button(text ='Connect', color = (0, 0, 0, 1), background_color =(0, 30, 50, 1),  font_size = default_font_size, size_hint =(.13, .09), pos =(375, 509)) 
        layout.add_widget(EthernetConnectBtn)
        EthernetConnectBtn.bind(on_press=EthernetConnectBtn_Click)

        GroupBox3 = Label(text='USB/Serial Communication', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(575, 565))
        layout.add_widget(GroupBox3)

        Label32 = Label(text='COM Port', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(540, 537))
        layout.add_widget(Label32)

        COMPort = TextInput(text='/dev/cu.SLAB_USBtoUART', font_size = default_font_size, size_hint =(.12, .06), pos =(535, 510))
        layout.add_widget(COMPort) 

        COMConnectBtn = Button(text ='Connect', color = (0, 0, 0, 1), background_color =(0, 255, 0, 1),  font_size = default_font_size, size_hint =(.13, .09), pos =(635, 509)) 
        layout.add_widget(COMConnectBtn)
        COMConnectBtn.bind(on_press=COMConnectBtn_Click)

        ID1GroupBox = Label(text='Status', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(32, 460))
        layout.add_widget(ID1GroupBox)

        Label2 = Label(text='Enc Pos:', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(71, 430))
        layout.add_widget(Label2)

        EX1 = TextInput(text='0', font_size = default_font_size, size_hint =(.15, .04), pos =(155, 430))
        layout.add_widget(EX1)

        Label14 = Label(text='Motor Status:', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(300, 428))
        layout.add_widget(Label14)

        STAT1 = TextInput(text='0', font_size = default_font_size, multiline = True, size_hint =(.12, .1), pos =(293, 365))
        layout.add_widget(STAT1)

        Label7 = Label(text='Target Pos:', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(63, 400))
        layout.add_widget(Label7)

        POSD1 = TextInput(text='0', font_size = default_font_size, size_hint =(.15, .04), pos =(155, 402))
        layout.add_widget(POSD1)

        Label3 = Label(text='Speed:', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(75, 370))
        layout.add_widget(Label3)

        VX1 = TextInput(text='0', font_size = default_font_size, size_hint =(.15, .04), pos =(155, 374))
        layout.add_widget(VX1)

        Label8 = Label(text='Target Speed:', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(56, 340))
        layout.add_widget(Label8)

        VPROF1 = TextInput(text='0', font_size = default_font_size, size_hint =(.15, .04), pos =(155, 345))
        layout.add_widget(VPROF1)

        GroupBox1 = Label(text='DIO / LED / RGB', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(465, 460))
        layout.add_widget(GroupBox1)

        Label33 = Label(text='1          2           3           4           5           6           7           8', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(585, 440))
        layout.add_widget(Label33)

        Label5 = Label(text='DI', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(473, 419))
        layout.add_widget(Label5)

        DI11 = Button(text ='', font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.8, 0.8, 0.8, 1), background_normal = "", size_hint =(.02, .03), pos =(530, 425)) 
        layout.add_widget(DI11)

        DI12 = Button(text ='', font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.8, 0.8, 0.8, 1), background_normal = "", size_hint =(.02, .03), pos =(555, 425)) 
        layout.add_widget(DI12)

        DI13 = Button(text ='', font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.8, 0.8, 0.8, 1), background_normal = "", size_hint =(.02, .03), pos =(580, 425)) 
        layout.add_widget(DI13)

        DI14 = Button(text ='', font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.8, 0.8, 0.8, 1), background_normal = "", size_hint =(.02, .03), pos =(605, 425)) 
        layout.add_widget(DI14)

        DI15 = Button(text ='', font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.8, 0.8, 0.8, 1), background_normal = "", size_hint =(.02, .03), pos =(630, 425)) 
        layout.add_widget(DI15)

        DI16 = Button(text ='', font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.8, 0.8, 0.8, 1), background_normal = "", size_hint =(.02, .03), pos =(655, 425)) 
        layout.add_widget(DI16)

        DI17 = Button(text ='', font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.8, 0.8, 0.8, 1), background_normal = "", size_hint =(.02, .03), pos =(680, 425)) 
        layout.add_widget(DI17)

        DI18 = Button(text ='', font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.8, 0.8, 0.8, 1), background_normal = "", size_hint =(.02, .03), pos =(705, 425)) 
        layout.add_widget(DI18)

        Label6 = Label(text='DO', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(471, 398))
        layout.add_widget(Label6)

        DO11 = Button(text ='', background_color =(0.8, 0.8, 0.8, 1), background_normal = "", size_hint =(.02, .03), pos =(530, 404)) 
        layout.add_widget(DO11)
        DO11.bind(on_press=DO11_DoubleClick)

        DO12 = Button(text ='', background_color =(0.8, 0.8, 0.8, 1), background_normal = "", size_hint =(.02, .03), pos =(555, 404)) 
        layout.add_widget(DO12)
        DO12.bind(on_press=DO12_DoubleClick)

        DO13 = Button(text ='',background_color =(0.8, 0.8, 0.8, 1), background_normal = "", size_hint =(.02, .03), pos =(580, 404)) 
        layout.add_widget(DO13)
        DO13.bind(on_press=DO13_DoubleClick)

        Label34 = Label(text='LED', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(470, 373))
        layout.add_widget(Label34)

        LEDStat1 = Button(text ='', background_color =(0.8, 0.8, 0.8, 1), background_normal = "", size_hint =(.06, .037), pos =(529, 376)) 
        layout.add_widget(LEDStat1)
        LEDStat1.bind(on_press=LEDStat1_DoubleClick)

        Label35 = Label(text='RGB', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(468, 347))
        layout.add_widget(Label35)

        GLed1 = Button(text ='', font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.8, 0.8, 0.8, 1), background_normal = "", size_hint =(.031, .038), pos =(555, 350)) 
        layout.add_widget(GLed1)
        GLed1.bind(on_press=GLed1_DoubleClick)

        RLed1 = Button(text ='', font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.8, 0.8, 0.8, 1), background_normal = "", size_hint =(.031, .038), pos =(529, 350)) 
        layout.add_widget(RLed1)
        RLed1.bind(on_press=RLed1_DoubleClick)

        BLed1 = Button(text ='', font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.8, 0.8, 0.8, 1), background_normal = "", size_hint =(.031, .038), pos =(581, 350)) 
        layout.add_widget(BLed1)
        BLed1.bind(on_press=BLed1_DoubleClick)

        GroupBox2 = Label(text='Motion', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(32, 295))
        layout.add_widget(GroupBox2)

        Label21 = Label(text='Profile:', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(55, 260))
        layout.add_widget(Label21)

        ScurveRadio = CheckBox(group = "radiobutton", color = (0, 0, 0, 1), active = True, size_hint =(.1, .05), pos =(105, 270))
        layout.add_widget(ScurveRadio)
        ScurveRadio.bind(on_press=ScurveRadio_CheckedChanged)

        LabelScurveRadio = Label(text='SCurve', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(140, 270))
        layout.add_widget(LabelScurveRadio)

        TrapRadio = CheckBox(group = "radiobutton", color = (0, 0, 0, 1), size_hint =(.1, .05), pos =(105, 245))
        layout.add_widget(TrapRadio)
        TrapRadio.bind(on_press=TrapRadio_CheckedChanged)

        LabelTrapRadio = Label(text='Trap', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(135, 245))
        layout.add_widget(LabelTrapRadio)

        Label1 = Label(text='Speed:', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(57, 215))
        layout.add_widget(Label1)

        TextBox_TargetSpeed = TextInput(text='100', font_size = default_font_size, size_hint =(.13, .04), pos =(124, 218))
        layout.add_widget(TextBox_TargetSpeed)

        Label4 = Label(text='Accel:', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(59, 190))
        layout.add_widget(Label4)

        TextBox_TargetAccel = TextInput(text='2000', font_size = default_font_size, size_hint =(.13, .04), pos =(124, 193))
        layout.add_widget(TextBox_TargetAccel)
        
        Label76 = Label(text='Decel:', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(59, 165))
        layout.add_widget(Label76)

        TextBox_TargetDecel = TextInput(text='2000', font_size = default_font_size, size_hint =(.13, .04), pos =(124, 168))
        layout.add_widget(TextBox_TargetDecel)

        Label9 = Label(text='Jerk:', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(61, 140))
        layout.add_widget(Label9)

        TextBox_TargetJerk = TextInput(text='50000', font_size = default_font_size, size_hint =(.13, .04), pos =(124, 143))
        layout.add_widget(TextBox_TargetJerk)

        Servo=TabbedPanel(do_default_tab = False, tab_width = 78, background_color =(0.8, 0.8, 0.8, 0.2), tab_height = 30, size_hint =(.51, .3), pos =(250, 120))
        tabitem1=TabbedPanelItem(font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.8, 0.8, 0.8, 1), background_normal = "", text = 'Servo')
        Button_Enable = Button(text ='SVON', color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", font_size = default_font_size, size_hint =(.17, .2), pos = (390, 200))
        Button_Disable = Button(text ='SVOFF', color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", font_size = default_font_size, size_hint =(.17, .2), pos = (460, 200))
        Button_ClearFault = Button(text ='Clear', color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", font_size = default_font_size, size_hint =(.34, .2), pos = (390, 150))
        layout1 = FloatLayout()
        layout1.add_widget(Button_Enable)
        Button_Enable.bind(on_press=Button_Enable_C_Click)
        layout1.add_widget(Button_Disable)
        Button_Disable.bind(on_press=Button_Disable_C_Click)
        layout1.add_widget(Button_ClearFault)
        Button_ClearFault.bind(on_press=Button_ClearFault_C_Click)
        tabitem1.add_widget(layout1)

        tabitem2=TabbedPanelItem(font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.8, 0.8, 0.8, 1), background_normal = "", text = 'Target')
        Label29 = Label(text='Pos1:', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(360, 220))
        TextBox_TargetPosition1 = TextInput(text='2500', font_size = default_font_size, size_hint =(.25, .18), pos =(410, 210))
        Button_X_Move1 = Button(text ='Go', color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", font_size = default_font_size, size_hint =(.1, .18), pos = (515, 210))
        Label10 = Label(text='Pos2:', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(360, 185))
        TextBox_TargetPosition2 = TextInput(text='-2500', font_size = default_font_size, size_hint =(.25, .18), pos =(410, 175))
        Button_X_Move2 = Button(text ='Go', color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", font_size = default_font_size, size_hint =(.1, .18), pos = (515, 175))
        ButtonSetPos = Button(text ='SetPos', color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", font_size = default_font_size, size_hint =(.25, .18), pos = (410, 140))
        layout2 = FloatLayout()
        layout2.add_widget(Label29)
        layout2.add_widget(Label10)
        layout2.add_widget(TextBox_TargetPosition1)
        layout2.add_widget(TextBox_TargetPosition2)
        layout2.add_widget(ButtonSetPos)
        ButtonSetPos.bind(on_press=ButtonSetPos_Click)
        layout2.add_widget(Button_X_Move1)
        Button_X_Move1.bind(on_press=Button_MoveTest1_Click)
        layout2.add_widget(Button_X_Move2)
        Button_X_Move2.bind(on_press=Button_X_Move2_Click)
        tabitem2.add_widget(layout2)

        tabitem3=TabbedPanelItem(font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.8, 0.8, 0.8, 1), background_normal = "", text = 'Jog')
        Button_JogMinus = Button(text ='J-', color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", font_size = default_font_size, size_hint =(.1, .18), pos = (390, 200))
        Button_ZeroVel = Button(text ='0', color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", font_size = default_font_size, size_hint =(.1, .18), pos = (440, 200))
        Button_JogPlus = Button(text ='J+', color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", font_size = default_font_size, size_hint =(.1, .18), pos = (490, 200))
        JogVelBar = Slider(min = 0, max = 200, step = 1, size_hint =(.51, .18), value = 100, pos = (360, 160))
        layout3 = FloatLayout()
        layout3.add_widget(Button_JogMinus)
        Button_JogMinus.bind(on_press=Button_JogMinus_MouseDown_1)
        layout3.add_widget(Button_ZeroVel)
        Button_ZeroVel.bind(on_press=Button_ZeroVel_Click)
        layout3.add_widget(Button_JogPlus)
        Button_JogPlus.bind(on_press=Button_JogPlus_MouseDown_1)
        layout3.add_widget(JogVelBar)
        JogVelBar.fbind('value', JogVelBar_Scroll)
        tabitem3.add_widget(layout3)

        tabitem4=TabbedPanelItem(font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.8, 0.8, 0.8, 1), background_normal = "", text = 'Home')
        Label68 = Label(text='Homing:', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(360, 220))
        dropdownCB = DropDown()
        for index in range(10):
            if index == 0:
                btnCB = Button(text='0-Plus Home', font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", size_hint_y=None, height=20)
            elif index == 1:
                btnCB = Button(text='1-Neg Home', font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", size_hint_y=None, height=20)
            elif index == 2:
                btnCB = Button(text='2-Plus Lim', font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", size_hint_y=None, height=20)
            elif index == 3:
                btnCB = Button(text='3-Neg Lim', font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", size_hint_y=None, height=20)
            elif index == 4:
                btnCB = Button(text='4-Plus Home Index', font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", size_hint_y=None, height=20)
            elif index == 5:
                btnCB = Button(text='5-Neg Home Index', font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", size_hint_y=None, height=20)
            elif index == 6:
                btnCB = Button(text='6-Plus Lim Index', font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", size_hint_y=None, height=20)
            elif index == 7:
                btnCB = Button(text='7-Neg Lim Index', font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", size_hint_y=None, height=20)
            elif index == 8:
                btnCB = Button(text='8-Plus Index', font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", size_hint_y=None, height=20)
            elif index == 9:
                btnCB = Button(text='9-Lim Index', font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", size_hint_y=None, height=20)
            btnCB.bind(on_release=lambda btnCB: dropdownCB.select(btnCB.text))
            dropdownCB.add_widget(btnCB)
        ComboBox_HomeMode = Button(text='0-Plus Home', color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", font_size = default_font_size, size_hint =(.3, .18), pos = (410, 208))
        ComboBox_HomeMode.bind(on_release=dropdownCB.open)
        dropdownCB.bind(on_select=lambda instance, x: setattr(ComboBox_HomeMode, 'text', x))
        Button_Home = Button(text ='HOME', color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", font_size = default_font_size, size_hint =(.3, .18), pos = (410, 150))
        layout4 = FloatLayout()
        layout4.add_widget(Label68)
        layout4.add_widget(ComboBox_HomeMode)
        layout4.add_widget(Button_Home)
        Button_Home.bind(on_press=DoHome_Click)
        tabitem4.add_widget(layout4)

        tabitem5=TabbedPanelItem(font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.8, 0.8, 0.8, 1), background_normal = "", text = 'SA')
        layout5 = FloatLayout()
        dropdownSL = DropDown()
        for index in range(32):
            btnSubNumberId = Button(text='%d' % (index + 1), color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", size_hint_y=None, height=20)
            btnSubNumberId.bind(on_release=lambda btnSubNumberId: dropdownSL.select(btnSubNumberId.text))
            dropdownSL.add_widget(btnSubNumberId)
        SubNumberList = Button(text='1', color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", font_size = default_font_size, size_hint =(.16, .18), pos = (360, 188))
        SubNumberList.bind(on_release=dropdownSL.open)
        dropdownSL.bind(on_select=lambda instance, x: setattr(SubNumberList, 'text', x))
        Button_Gosub = Button(text ='Gosub', color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", font_size = default_font_size, size_hint =(.16, .18), pos = (360, 158))
        Label11 = Label(text='RUN', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(475, 190))
        Button_Run0 = Button(text ='0', color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", font_size = default_font_size, size_hint =(.02, .015), pos =(463, 170)) 
        Button_Run1 = Button(text ='1', color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", font_size = default_font_size, size_hint =(.02, .015), pos =(491, 170)) 
        Button_Run2 = Button(text ='2', color = (0, 0, 0, 1), background_color =(0.6, 0.6, 0.6, 1), background_normal = "", font_size = default_font_size, size_hint =(.02, .015), pos =(519, 170)) 
        layout5.add_widget(SubNumberList)
        layout5.add_widget(Button_Gosub)
        Button_Gosub.bind(on_press=GosubBtn_Click)
        layout5.add_widget(Label11)
        layout5.add_widget(Button_Run0)
        Button_Run0.bind(on_press=Run0_Click)
        layout5.add_widget(Button_Run1)
        Button_Run1.bind(on_press=Run1_Click)
        layout5.add_widget(Button_Run2)
        Button_Run2.bind(on_press=Run2_Click)
        tabitem5.add_widget(layout5)
        Servo.add_widget(tabitem1)
        Servo.add_widget(tabitem2)
        Servo.add_widget(tabitem3)
        Servo.add_widget(tabitem4)
        Servo.add_widget(tabitem5)
        layout.add_widget(Servo)

        Button_STOPX = Button(text ='STOP', font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.8, 0.8, 0.8, 1), background_normal = "", size_hint =(.072, .17), pos =(675, 140)) 
        layout.add_widget(Button_STOPX)
        Button_STOPX.bind(on_press=Button_STOPX_Click)

        GroupBox5 = Label(text='Variable', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(32, 70))
        layout.add_widget(GroupBox5)

        Label15 = Label(text='Value', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(105, 55))
        layout.add_widget(Label15)

        dropdownVarID = DropDown()
        for index in range(10):
            btnVarID = Button(text='V%d' % (index + 1), font_size = default_font_size, color = (0, 0, 0, 1), background_color =(0.8, 0.8, 0.8, 1), background_normal = "", size_hint_y=None, height=20)
            btnVarID.bind(on_release=lambda btnVarID: dropdownVarID.select(btnVarID.text))
            dropdownVarID.add_widget(btnVarID)
        VarIDList = Button(text='V1', color = (0, 0, 0, 1), background_color =(0.8, 0.8, 0.8, 1), background_normal = "", font_size = default_font_size, size_hint =(.07, .04), pos =(60, 35))
        VarIDList.bind(on_release=dropdownVarID.open)
        dropdownVarID.bind(on_select=lambda instance, x: setattr(VarIDList, 'text', x))
        layout.add_widget(VarIDList)

        VarValue = TextInput(text='0', font_size = default_font_size, size_hint =(.07, .04), pos =(118, 35))
        layout.add_widget(VarValue) 

        ReadVar = Button(text ='R', color = (0, 0, 0, 1), background_color =(0.8, 0.8, 0.8, 1), background_normal = "", font_size = default_font_size, size_hint =(.049, .04), pos =(179, 35)) 
        layout.add_widget(ReadVar)
        ReadVar.bind(on_press = ReadVar_Click)

        WriteVar = Button(text ='W', color = (0, 0, 0, 1), background_color =(0.8, 0.8, 0.8, 1), background_normal = "", font_size = default_font_size, size_hint =(.049, .04), pos =(220, 35)) 
        layout.add_widget(WriteVar)
        WriteVar.bind(on_press = WriteVar_Click)

        Label17 = Label(text='Reply:', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(405, 55))
        layout.add_widget(Label17)

        ReplyTextbox = TextInput(text='', multiline = False, readonly = True, font_size = default_font_size, size_hint =(.3, .047), pos =(470, 57))
        layout.add_widget(ReplyTextbox) 

        Label16 = Label(text='Command:', color = (0, 0, 0, 1), font_size = default_font_size, size_hint =(.1, .05), pos =(392, 27))
        layout.add_widget(Label16)

        CommandTextbox = TextInput(text='', multiline = False, font_size = default_font_size, size_hint =(.3, .047), pos =(470, 26))
        layout.add_widget(CommandTextbox) 
        CommandTextbox.bind(on_text_validate=CommandTextbox_KeyPress)

        App.DIDisplay.append(DI11)
        App.DIDisplay.append(DI12)
        App.DIDisplay.append(DI13)
        App.DIDisplay.append(DI14)
        App.DIDisplay.append(DI15)
        App.DIDisplay.append(DI16)
        App.DIDisplay.append(DI17)
        App.DIDisplay.append(DI18)

        App.DODisplay.append(DO11)
        App.DODisplay.append(DO12)
        App.DODisplay.append(DO13)

        App.RGBDisplay.append(RLed1)
        App.RGBDisplay.append(GLed1)
        App.RGBDisplay.append(BLed1)

        App.g_netindex = 1
        Clock.schedule_interval(Timer1_Tick, 0.5)


        return layout 
        
  
# run the App 
if __name__ == "__main__": 
    TITAN_Python_Sample_ProgramApp().run() 
