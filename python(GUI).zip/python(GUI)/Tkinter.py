import tkinter as tk
from tkinter import * 
from tkinter.filedialog import askopenfilename
from tkinter import messagebox 
from selenium import webdriver
from bs4 import BeautifulSoup
import time
import threading 
import pandas as pd
import os
import csv

root = tk.Tk(className=' Data Scraping')
root.geometry("600x200")
class My_App(tk.Frame):
	def __init__(self, parent):
		tk.Frame.__init__(self, parent)
		self.parent = parent 
		self.driver = webdriver.Chrome()
		self.textFrom = "1"
		self.textTo = ""
		self.textSpeed = ""
		self.textFilePath = ""


		lblFile = Label(self.parent, font="Verdana 10 bold", text = "CSV File : ")
		lblFile.place(x=70, y=40)

		self.txtFilePath = tk.Entry(root, font=('calibre',10,'normal'), width=35) 
		self.txtFilePath.place(x=155, y=40)

		self.btnFileOpen = tk.Button(self.parent, text="Open", command = self.OnFileOpen, width=12)
		self.btnFileOpen.pack()
		self.btnFileOpen.place(x=410, y=37)

		lblFrom = Label(self.parent, font="Verdana 10 bold", text = "From : ")
		lblFrom.place(x=90, y=90)

		self.txtFrom = tk.Entry(root, font=('calibre',10,'normal'), width=8) 
		self.txtFrom.place(x=150, y=90)

		lblTo = Label(self.parent, font="Verdana 10 bold", text = "To : ")
		lblTo.place(x=220, y=90)

		self.txtTo = tk.Entry(root, font=('calibre',10,'normal'), width=8) 
		self.txtTo.place(x=260, y=90)

		lblSpeed = Label(self.parent, font="Verdana 10 bold", text = "Speed : ")
		lblSpeed.place(x=340, y=90)

		self.txtSpeed = tk.Entry(root, font=('calibre',10,'normal'), width=8) 
		self.txtSpeed.place(x=410, y=90)

		self.btnStart = tk.Button(self.parent, text="Start", command = self.OnStart, width=12)
		self.btnStart.pack()
		self.btnStart.place(x=230, y=140)

	def OnFileOpen(self):
		name = askopenfilename(initialdir="C:/",
                           filetypes =(("CSV File", "*.csv"),("All Files","*.*")),
                           title = "Choose a CSV file."
                           )
		self.txtFilePath.delete(0, "end")
		self.txtFilePath.insert(0, name)

	def OnStart(self):
		col_names = ['Company',
             'Industry',
             'Sales',
             'Phone',
             'Location',
             'Website',
             'City',
             'Zip code',
             'SIC code',
             'NAICS code']
		
		if self.txtFilePath.get() == "":
			messagebox.showwarning("Warning", "Please select the CSV file") 
			return
		if self.txtFrom.get() != "":
			self.textFrom = self.txtFrom.get()
		if self.txtTo.get() != "":
			self.textTo = self.txtTo.get()
		if self.txtSpeed.get() == "":
			messagebox.showwarning("Warning", "Please input the speed") 
			return
		
		
		self.textSpeed = self.txtSpeed.get()
		self.textFilePath = self.txtFilePath.get()
		df = pd.read_csv(self.textFilePath, names=col_names, header=None)
		self.textTo = str(len(df.to_dict()['Website']))
		self.driver.get("https://app.uplead.com/login")
		time.sleep(3)
		self.driver.find_element_by_xpath('//input[@type="text"]').send_keys("support@leadgibbon.com")
		time.sleep(1)
		self.driver.find_element_by_xpath('//input[@type="password"]').send_keys("gRZ6N6WA%D")
		time.sleep(1)
		self.driver.find_element_by_xpath('//button[@type="submit"]').click()
		time.sleep(15)
		self.driver.find_element_by_xpath('//div[@class="filter__list"]/div[2]').click()
		time.sleep(2)
		self.driver.find_element_by_xpath('//div[@class="filter__tree-body-inner"]/div[3]/span').click()
		time.sleep(1)
		self.driver.find_element_by_xpath('//div[@class="checkbox-list checkbox-list__simple"]/div[1]').click()
		time.sleep(1)
		self.driver.find_element_by_xpath('//div[@class="checkbox-list checkbox-list__simple"]/div[2]').click()
		time.sleep(1)
		self.driver.find_element_by_xpath('//div[@class="checkbox-list checkbox-list__simple"]/div[3]').click()
		time.sleep(1)
		self.driver.find_element_by_xpath('//div[@class="checkbox-list checkbox-list__simple"]/div[4]').click()
		time.sleep(1)
		self.driver.find_element_by_xpath('//div[@class="filter__tree-closeBtn"]/button').click()
		time.sleep(5)
		self.driver.find_element_by_xpath('//div[@class="filter__list"]/div[3]').click()
		time.sleep(2)
		self.driver.find_element_by_xpath('//div[@class="filter__tree-closeBtn"]/button').click()
		time.sleep(5)
		for i in range(int(self.textFrom), int(self.textTo), 1):
			strUrl = df.to_dict()['Website'][i]
			self.driver.find_element_by_xpath('//div[@class="filter__list"]/div[7]').click()
			time.sleep(2)
			self.driver.find_element_by_xpath('//input[@class="filter__searchGroup-input filter__searchGroup-input--icon"]').send_keys(strUrl)
			time.sleep(2)
			self.driver.find_element_by_xpath('//div[@class="filter__list"]/div[7]/div[2]/div[1]/button').click()
			time.sleep(15)
			self.driver.find_element_by_xpath('//div[@class="search-bar__column"]').click()
			time.sleep(1)
			self.driver.find_element_by_xpath('//div[@class="search-bar__column-list"]/div[4]').click()
			time.sleep(1)
			self.driver.find_element_by_xpath('//div[@class="search-bar__column-list"]/div[5]').click()
			time.sleep(1)
			self.driver.find_element_by_xpath('//div[@class="search-bar__column-list"]/div[6]').click()
			time.sleep(1)
			self.driver.find_element_by_xpath('//div[@class="search-bar__column-list"]/div[7]').click()
			time.sleep(1)
			self.driver.find_element_by_xpath('//div[@class="search-bar__column search-bar__column--open"]').click()
			time.sleep(1)
			self.driver.find_element_by_xpath('//div[@class="custom-select__wrapper"]/div').click()
			time.sleep(1)
			self.driver.find_element_by_xpath('//div[@class="custom-select__search-list"]/div[3]').click()
			time.sleep(5)

			nItem = 1
			tags = BeautifulSoup(self.driver.page_source, "html.parser")
			lis = tags.find_all("div", class_="app-table__body__row")
			with open("result.csv", 'w', newline='') as csv_file:
				fieldnames = ['Contact', 'Company', 'Title']
				writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
				writer.writeheader()
				for elem in lis:
					contact = self.driver.find_element_by_xpath('//div[@role="rowgroup"]/div['+str(nItem)+']/div[2]/a').text
					company = self.driver.find_element_by_xpath('//div[@role="rowgroup"]/div['+str(nItem)+']/div[3]/a').text
					title = self.driver.find_element_by_xpath('//div[@role="rowgroup"]/div['+str(nItem)+']/div[4]').text
					writer.writerow({'Contact':contact, 'Company':company, 'Title':title})
					nItem = nItem + 1
				nItem = 1
				time.sleep(int(self.textSpeed))
				self.driver.find_element_by_xpath('//div[@class="pagination__wrap"]/ul/li[4]').click()
				time.sleep(7)
				tags = BeautifulSoup(self.driver.page_source, "html.parser")
				lis = tags.find_all("div", class_="app-table__body__row")
				for elem in lis:
					contact = self.driver.find_element_by_xpath('//div[@role="rowgroup"]/div['+str(nItem)+']/div[2]/a').text
					company = self.driver.find_element_by_xpath('//div[@role="rowgroup"]/div['+str(nItem)+']/div[3]/a').text
					title = self.driver.find_element_by_xpath('//div[@role="rowgroup"]/div['+str(nItem)+']/div[4]').text
					writer.writerow({'Contact':contact, 'Company':company, 'Title':title})
					nItem = nItem + 1
				nItem = 1
				time.sleep(int(self.textSpeed))
				self.driver.find_element_by_xpath('//div[@class="pagination__wrap"]/ul/li[5]').click()
				time.sleep(7)
				tags = BeautifulSoup(self.driver.page_source, "html.parser")
				lis = tags.find_all("div", class_="app-table__body__row")
				for elem in lis:
					contact = self.driver.find_element_by_xpath('//div[@role="rowgroup"]/div['+str(nItem)+']/div[2]/a').text
					company = self.driver.find_element_by_xpath('//div[@role="rowgroup"]/div['+str(nItem)+']/div[3]/a').text
					title = self.driver.find_element_by_xpath('//div[@role="rowgroup"]/div['+str(nItem)+']/div[4]').text
					writer.writerow({'Contact':contact, 'Company':company, 'Title':title})
					nItem = nItem + 1
				nItem = 1

				nLoop = self.driver.find_element_by_xpath('//ul[@class="pagination-block"]/li[7]/a').text
				for x in range(int(nLoop) - 3):
					time.sleep(int(self.textSpeed))
					self.driver.find_element_by_xpath('//div[@class="pagination__wrap"]/ul/li[6]').click()
					time.sleep(7)
					tags = BeautifulSoup(self.driver.page_source, "html.parser")
					lis = tags.find_all("div", class_="app-table__body__row")
					for elem in lis:
						contact = self.driver.find_element_by_xpath('//div[@role="rowgroup"]/div['+str(nItem)+']/div[2]/a').text
						company = self.driver.find_element_by_xpath('//div[@role="rowgroup"]/div['+str(nItem)+']/div[3]/a').text
						title = self.driver.find_element_by_xpath('//div[@role="rowgroup"]/div['+str(nItem)+']/div[4]').text
						writer.writerow({'Contact':contact, 'Company':company, 'Title':title})
						nItem = nItem + 1
					nItem = 1


root.resizable(False, False) 
My_App(root)
root.mainloop()