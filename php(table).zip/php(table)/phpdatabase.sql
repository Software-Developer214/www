/*
SQLyog Community v13.1.5  (64 bit)
MySQL - 10.4.10-MariaDB : Database - phpdatabase
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`phpdatabase` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `phpdatabase`;

/*Table structure for table `table_name` */

DROP TABLE IF EXISTS `table_name`;

CREATE TABLE `table_name` (
  `unit` varchar(100) DEFAULT NULL,
  `unit_amount` varchar(100) DEFAULT NULL,
  `currency` varchar(100) DEFAULT NULL,
  `tx_id` varchar(100) DEFAULT NULL,
  `tx_type` varchar(100) DEFAULT NULL,
  `tx_timestamp` date DEFAULT NULL,
  `meta` longtext DEFAULT NULL,
  `invoice_ref` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `table_name` */

insert  into `table_name`(`unit`,`unit_amount`,`currency`,`tx_id`,`tx_type`,`tx_timestamp`,`meta`,`invoice_ref`) values 
('1','1111','RM','12542','Hellow',NULL,NULL,'1254511'),
('1','1111','RM','12542','Hellow',NULL,NULL,'1254511'),
('ozt','10','RM','FDS2541','Sale','2020-02-19','{\"user_data\":{\"name\":\"USER 1\",\"email\":\"testvictorfoo1@gmail.com\",\"contact\":\"601129211111\",\"id_number\":\"TEST\"},\"agent_data\":{\"name\":\"ace\",\"email\":\"ace-admin@sgpmx.com\"},\"transaction_fee\":\"0.15\",\"supplier\":\"mks\",\"spot_price\":\"1519.90\",\"mks_spot_price_captured\":\"1520.45\",\"spot_price_mark\":\"0.55\",\"payment_method\":\"wallet\",\"exchange_rate\":{\"SGD\":\"1.3409\",\"USD\":\"1.0000\"},\"exchange_rate_mark\":{\"SGD\":{\"markup_buy\":\"0.005\",\"markup_sell\":\"0.005\",\"end_markup_buy\":\"0.005\",\"end_markup_sell\":\"0.005\",\"start_time\":\"10:00:00\",\"end_time\":\"17:00:00\"}},\"ip_address\":\"115.42.210.173\",\"trade_id\":\"35112\",\"via\":\"mobile\",\"commission_percentage\":{\"SGPMX\":\"25|25|50|0\",\"MKS\":\"25|25|0|0\",\"IT Solutions\":\"10|10|0|0\",\"VALU\":\"15|15|0|0\",\"Vendor\":\"25|25|50|0\"},\"mdr_percentage\":\"1\",\"gst_percentage\":\"7\",\"mks_quantity\":\"0.0009869\",\"grand_total\":\"0.16\",\"collectable_amount\":\"1.34\",\"wallet_balance\":\"17342.57\",\"transaction_fee_method\":\"exclusive\"}','INV1000'),
('ozt','10','RM','FDS2541','Sale','2020-02-19','{\"user_data\":{\"name\":\"USER 1\",\"email\":\"testvictorfoo1@gmail.com\",\"contact\":\"601129211111\",\"id_number\":\"TEST\"},\"agent_data\":{\"name\":\"ace\",\"email\":\"ace-admin@sgpmx.com\"},\"transaction_fee\":\"0.15\",\"supplier\":\"mks\",\"spot_price\":\"1519.90\",\"mks_spot_price_captured\":\"1520.45\",\"spot_price_mark\":\"0.55\",\"payment_method\":\"wallet\",\"exchange_rate\":{\"SGD\":\"1.3409\",\"USD\":\"1.0000\"},\"exchange_rate_mark\":{\"SGD\":{\"markup_buy\":\"0.005\",\"markup_sell\":\"0.005\",\"end_markup_buy\":\"0.005\",\"end_markup_sell\":\"0.005\",\"start_time\":\"10:00:00\",\"end_time\":\"17:00:00\"}},\"ip_address\":\"115.42.210.173\",\"trade_id\":\"35112\",\"via\":\"mobile\",\"commission_percentage\":{\"SGPMX\":\"25|25|50|0\",\"MKS\":\"25|25|0|0\",\"IT Solutions\":\"10|10|0|0\",\"VALU\":\"15|15|0|0\",\"Vendor\":\"25|25|50|0\"},\"mdr_percentage\":\"1\",\"gst_percentage\":\"7\",\"mks_quantity\":\"0.0009869\",\"grand_total\":\"0.16\",\"collectable_amount\":\"1.34\",\"wallet_balance\":\"17342.57\",\"transaction_fee_method\":\"exclusive\"}','INV1000');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
