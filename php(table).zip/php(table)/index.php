<!DOCTYPE html>
<html lang="en">
<head>
  <title>Log in</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="jumbotron text-center">
  <h1>User Login</h1>
</div>
  
<div class="container">
  <div class="row">
    <div class="container">
      <br><br><br><br><br><br>
      <form>
        <div class="form-group">
          <label for="userid">User ID:</label>
          <input type="text" class="form-control" id="userid" placeholder="Enter UserId" name="userid">
        </div>
        <div class="form-group">
          <label for="password">Password:</label>
          <input type="password" class="form-control" id="password" placeholder="Enter password" name="password">
        </div>
        <br><br>
        <button style="margin-left: 45%;" type="button" id="btnLogin" name="btnLogin" class="btn btn-primary">Login</button>
      </form>
    </div>
  </div>
</div>
<script>
  $(document).ready(function(){
    $("#btnLogin").click(function(){
      var userid = $("#userid").val();
      var pass = $("#password").val();
      $.post("database.php",
      {
        userId: userid,
        password: pass
      },
      function(data,status){
        if(data == "OK"){
          window.location = "first.php";
        }
        else{
          alert("Try again");
        }
      });
    });
});
</script>
</body>
</html>
