<?php
  $sdt = $_POST['sdt'];
  $edt = $_POST['edt'];
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "phpdatabase";
  $conn = new mysqli($servername, $username, $password, $dbname);
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }
  if(isset($_POST['chView'])){
    $sql = "SELECT * FROM table_name";
  }
  else{
    $sql = "SELECT * FROM table_name WHERE tx_timestamp BETWEEN '".$sdt."' AND '".$edt."'";
  }
  $result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Show Data</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">



  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
  <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>

</head>
  <div class="container">
    <br><br>
    <div class="table-responsive" id="creat_excel">
      <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>unit</th>
                <th>unit_amount</th>
                <th>currency</th>
                <th>tx_id</th>
                <th>tx_type</th>
                <th>tx_timestamp</th>
                <th>name</th>
                <th>email</th>
                <th>contact</th>
                <th>id_number</th>
                <th>name</th>
                <th>email</th>
                <th>transaction_fee</th>
                <th>supplier</th>
                <th>spot_price</th>
                <th>mks_spot_price_captured</th>
                <th>spot_price_mark</th>
                <th>payment_method</th>
                <th>SGD</th>
                <th>USD</th>
                <th>markup_buy</th>
                <th>markup_sell</th>
                <th>end_markup_buy</th>
                <th>end_markup_sell</th>
                <th>start_time</th>
                <th>end_time</th>
                <th>ip_address</th>
                <th>trade_id</th>
                <th>via</th>
                <th>SGPMX</th>
                <th>MKS</th>
                <th>IT Solutions</th>
                <th>VALU</th>
                <th>Vendor</th>
                <th>mdr_percentage</th>
                <th>gst_percentage</th>
                <th>mks_quantity</th>
                <th>grand_total</th>
                <th>collectable_amount</th>
                <th>wallet_balance</th>
                <th>transaction_fee_method</th>
                <th>invoice_ref</th>
            </tr>
        </thead>
        <tbody>
          <?php
            foreach ($result as $temp) {
          ?>
            <tr>
                <td><?php echo $temp['unit'];?></td>
                <td><?php echo $temp['unit_amount'];?></td>
                <td><?php echo $temp['currency'];?></td>
                <td><?php echo $temp['tx_id'];?></td>
                <td><?php echo $temp['tx_type'];?></td>
                <td><?php echo $temp['tx_timestamp'];?></td>
                

                <?php 
                  $temp1 = $temp['meta'];
                  $start = '"'.':'.'"';
                  $end = '"'.','.'"';
                  $end1 = '"'.'}'.','.'"';
                  $end2 = '"'.'}'.'}'.','.'"';
                  $end3 = '"'.'}';
                  $nStr = strlen($temp1);
                  for ($i=0; $i < $nStr; $i++) { 
                    $startpos = stripos($temp1, $start) + 3;
                    $temp1 = substr($temp1, $startpos);
                    
                    if($i == 3){
                      $end1pos = stripos($temp1, $end1);
                      $temp2 = substr($temp1, 0, $end1pos);
                      $temp1 = substr($temp1, $end1pos);
                    }else if($i == 5){
                      $end1pos = stripos($temp1, $end1);
                      $temp2 = substr($temp1, 0, $end1pos);
                      $temp1 = substr($temp1, $end1pos);
                    }else if($i == 13){
                      $end1pos = stripos($temp1, $end1);
                      $temp2 = substr($temp1, 0, $end1pos);
                      $temp1 = substr($temp1, $end1pos);
                    }else if($i == 19){
                      $end2pos = stripos($temp1, $end2);
                      $temp2 = substr($temp1, 0, $end2pos);
                      $temp1 = substr($temp1, $end2pos);
                    }else if($i == 27){
                      $end1pos = stripos($temp1, $end1);
                      $temp2 = substr($temp1, 0, $end1pos);
                      $temp1 = substr($temp1, $end1pos);
                    }else if($i == 34){
                      $end3pos = stripos($temp1, $end3);
                      $temp2 = substr($temp1, 0, $end3pos);
                      $temp1 = substr($temp1, $end3pos);
                      $i = $nStr;
                    }else{
                      $endpos = stripos($temp1, $end);
                      $temp2 = substr($temp1, 0, $endpos);
                      $temp1 = substr($temp1, $endpos);
                    }
                ?>
                    <td><?php echo $temp2;?></td>
                <?php
                    
                  }
                  
                ?>
                <td><?php echo $temp['invoice_ref'];?></td>
            </tr>
          <?php

            }
          ?>
        </tbody>
    </table>
    </div>
    <br><br>
    <button id="btnCSV" name="btnCSV">CSV</button>
    <button id="btnExcel" name="btnExcel">EXCEL</button>
  </div>
  <script>
  $(document).ready(function(){
    $('#example').DataTable();

    $("#btnCSV").click(function(){
      var html = document.querySelector("table").outerHTML;
      export_table_to_csv(html, "csv.csv");
    });

    $("#btnExcel").click(function(){
      exportTableToExcel("table","excel.xls");
    });

    function download_csv(csv, filename) {
      var csvFile;
      var downloadLink;
      csvFile = new Blob([csv], {type: "text/csv"});
      downloadLink = document.createElement("a");
      downloadLink.download = filename;
      downloadLink.href = window.URL.createObjectURL(csvFile);
      downloadLink.style.display = "none";
      document.body.appendChild(downloadLink);
      downloadLink.click();
    }

    function export_table_to_csv(html, filename) {
      var csv = [];
      var rows = document.querySelectorAll("table tr");
      
        for (var i = 0; i < rows.length; i++) {
        var row = [], cols = rows[i].querySelectorAll("td, th");
        
            for (var j = 0; j < cols.length; j++) 
                row.push(cols[j].innerText);
            
        csv.push(row.join(","));    
      }
        download_csv(csv.join("\n"), filename);
    }


    function exportTableToExcel(tableID, filename = ''){
      var downloadLink;
      var dataType = 'application/vnd.ms-excel';
      var tableSelect = document.querySelector("table");
      var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');
      filename = filename?filename+'.xls':'excel_data.xls';
      downloadLink = document.createElement("a");
      
      document.body.appendChild(downloadLink);
      
      if(navigator.msSaveOrOpenBlob){
          var blob = new Blob(['\ufeff', tableHTML], {
              type: dataType
          });
          navigator.msSaveOrOpenBlob( blob, filename);
      }else{
          downloadLink.href = 'data:' + dataType + ', ' + tableHTML;
      
          downloadLink.download = filename;
          
          downloadLink.click();
      }
    }
  });
</script>
</body>
</html>
