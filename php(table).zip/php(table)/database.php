<?php
	$userid = $_POST['userId'];
	$userpass = $_POST['password'];
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "phptemp";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
	    die("Connection failed: " . $conn->connect_error);
	}
	$sql = "SELECT * FROM user WHERE uid = '".$userid."' AND password = '".$userpass."'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		echo "OK";
	}
	else {
		echo "NO";
	}
?>