<!DOCTYPE html>
<html lang="en">
<head>
  <title>Search and Download</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
  <div class="container">
    <br><br><br><br><br><br><br><br><br><br>
    <form action="/php/table.php" method="post">
      <div class="input-group mb-3">
        <div class="input-group-prepend">
          <span class="input-group-text">StartDate</span>
        </div>
        <input type="date" id="sdt" name="sdt" class="form-control">
      </div>
      <div class="input-group mb-3">
        <div class="input-group-prepend">
          <span class="input-group-text">EndDate</span>
        </div>
        <input type="date" id="edt" name="edt" class="form-control">
      </div>
      <input style="margin-left: 1px;" class="form-check-input" type="checkbox" id="chView" name="chView" value="0"><h6 style="margin-left: 20px;">View All</h6>
<!--       <label for="sel1">Report type</label>
      <select class="form-control" id="rtt" name="rtt">
        <option>EXCEL</option>
        <option>CSV</option>
      </select> -->
      <br><br>
      <button style="margin-left: 45%;" type="submit" class="btn btn-primary">Submit</button>
    </form>
  </div>
</body>
</html>
