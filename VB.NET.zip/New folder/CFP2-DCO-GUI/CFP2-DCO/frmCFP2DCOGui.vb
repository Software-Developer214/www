﻿
Imports System.Deployment.Application
Imports System.IO
Imports System.Reflection

Public Class frmCFP2DCOGui

End Class