﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCFP2DCOGui
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()

        Me.BackgroundImage = My.Resources.ResourceManager.GetObject("background")
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmCFP2DCOGui))
        Me.output_monitors = New System.Windows.Forms.Panel()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.PauseGuiButton = New System.Windows.Forms.Button()
        Me.refreshInterval = New System.Windows.Forms.ComboBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.monitorRefresh = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.WarningLabel = New System.Windows.Forms.Label()
        Me.lblModuleTemperature = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.p33v_monitor = New System.Windows.Forms.Label()
        Me.P3v3Label = New System.Windows.Forms.Label()
        Me.DSPModulationGroup = New System.Windows.Forms.GroupBox()
        Me.LabelHighPow = New System.Windows.Forms.Label()
        Me.btn_EnableHighPow = New System.Windows.Forms.Button()
        Me.txtGridSpacing = New System.Windows.Forms.Label()
        Me.lblGridSpacing = New System.Windows.Forms.Label()
        Me.txtFirstFrequency = New System.Windows.Forms.Label()
        Me.lblFirstFrequency = New System.Windows.Forms.Label()
        Me.lblLastFrequency = New System.Windows.Forms.Label()
        Me.txtLastFrequency = New System.Windows.Forms.Label()
        Me.serNum = New System.Windows.Forms.Label()
        Me.parNum = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.module_state_display = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.EvalBoardMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.Eval1MenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Eval2MenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Eval3MenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Eval4MenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ManualEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConnectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DisconnectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MDIOToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReadWriteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PopupGUIToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.QuitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.dsp_panel = New System.Windows.Forms.GroupBox()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.DSPSyncCheckBox = New System.Windows.Forms.CheckBox()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.cbDSPCSP = New System.Windows.Forms.ComboBox()
        Me.cbDSPFEC = New System.Windows.Forms.ComboBox()
        Me.cbDSPModulation = New System.Windows.Forms.ComboBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.postFecBerA = New System.Windows.Forms.Label()
        Me.preFecBerA = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.biasLoopControl = New System.Windows.Forms.ComboBox()
        Me.FreqComboBox = New System.Windows.Forms.ComboBox()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.lblChannelFrequencyRd = New System.Windows.Forms.Label()
        Me.lblMSAChannel = New System.Windows.Forms.Label()
        Me.txtMSAChannel = New System.Windows.Forms.TextBox()
        Me.lblValidMSAChannels = New System.Windows.Forms.Label()
        Me.lblModulationFormat = New System.Windows.Forms.Label()
        Me.cbModulationFormat = New System.Windows.Forms.ComboBox()
        Me.txtChannelFrequency = New System.Windows.Forms.TextBox()
        Me.lblFTF = New System.Windows.Forms.Label()
        Me.lblChannelFrequency = New System.Windows.Forms.Label()
        Me.txtFTF = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.pb_txOn = New System.Windows.Forms.PictureBox()
        Me.txtTxOutPutPower = New System.Windows.Forms.TextBox()
        Me.txPowerMon = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.lblTxOutputPower = New System.Windows.Forms.Label()
        Me.txOnButton = New System.Windows.Forms.Button()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.refreshTimer = New System.Windows.Forms.Timer(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.disconnectFromModule = New System.Windows.Forms.Button()
        Me.connectToModule = New System.Windows.Forms.Button()
        Me.snapshot = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cbMDIOinstance = New System.Windows.Forms.ComboBox()
        Me.cbMDIOaddress = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.output_monitors.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.DSPModulationGroup.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.dsp_panel.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.txtFTF, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        CType(Me.pb_txOn, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'output_monitors
        '
        Me.output_monitors.BackColor = System.Drawing.Color.Silver
        Me.output_monitors.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.output_monitors.Controls.Add(Me.GroupBox4)
        Me.output_monitors.Controls.Add(Me.GroupBox1)
        Me.output_monitors.Controls.Add(Me.DSPModulationGroup)
        Me.output_monitors.Enabled = False
        Me.output_monitors.Location = New System.Drawing.Point(43, 79)
        Me.output_monitors.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.output_monitors.Name = "output_monitors"
        Me.output_monitors.Size = New System.Drawing.Size(504, 897)
        Me.output_monitors.TabIndex = 3
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.PauseGuiButton)
        Me.GroupBox4.Controls.Add(Me.refreshInterval)
        Me.GroupBox4.Controls.Add(Me.Label12)
        Me.GroupBox4.Controls.Add(Me.monitorRefresh)
        Me.GroupBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(4, 709)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox4.Size = New System.Drawing.Size(490, 178)
        Me.GroupBox4.TabIndex = 247
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "GUI Controls"
        '
        'PauseGuiButton
        '
        Me.PauseGuiButton.BackColor = System.Drawing.Color.Silver
        Me.PauseGuiButton.Enabled = False
        Me.PauseGuiButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PauseGuiButton.Location = New System.Drawing.Point(260, 108)
        Me.PauseGuiButton.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PauseGuiButton.Name = "PauseGuiButton"
        Me.PauseGuiButton.Size = New System.Drawing.Size(140, 46)
        Me.PauseGuiButton.TabIndex = 232
        Me.PauseGuiButton.Tag = "output_monitors"
        Me.PauseGuiButton.Text = "Pause Reads"
        Me.PauseGuiButton.BackColor = Color.Gray
        Me.PauseGuiButton.UseVisualStyleBackColor = False
        '
        'refreshInterval
        '
        Me.refreshInterval.Enabled = False
        Me.refreshInterval.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.refreshInterval.FormattingEnabled = True
        Me.refreshInterval.Items.AddRange(New Object() {"1", "2", "5", "10"})
        Me.refreshInterval.Location = New System.Drawing.Point(40, 52)
        Me.refreshInterval.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.refreshInterval.Name = "refreshInterval"
        Me.refreshInterval.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.refreshInterval.Size = New System.Drawing.Size(82, 30)
        Me.refreshInterval.TabIndex = 231
        Me.refreshInterval.Text = "2"
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Label12.Location = New System.Drawing.Point(135, 57)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(128, 31)
        Me.Label12.TabIndex = 230
        Me.Label12.Tag = "output_monitors"
        Me.Label12.Text = "Seconds"
        '
        'monitorRefresh
        '
        Me.monitorRefresh.BackColor = System.Drawing.Color.Silver
        Me.monitorRefresh.Enabled = False
        Me.monitorRefresh.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.monitorRefresh.Location = New System.Drawing.Point(80, 108)
        Me.monitorRefresh.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.monitorRefresh.Name = "monitorRefresh"
        Me.monitorRefresh.Size = New System.Drawing.Size(140, 46)
        Me.monitorRefresh.TabIndex = 229
        Me.monitorRefresh.Tag = "output_monitors"
        Me.monitorRefresh.Text = "Refresh"
        Me.monitorRefresh.BackColor = Color.Gray
        Me.monitorRefresh.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.PictureBox6)
        Me.GroupBox1.Controls.Add(Me.PictureBox7)
        Me.GroupBox1.Controls.Add(Me.PictureBox4)
        Me.GroupBox1.Controls.Add(Me.PictureBox5)
        Me.GroupBox1.Controls.Add(Me.PictureBox3)
        Me.GroupBox1.Controls.Add(Me.PictureBox2)
        Me.GroupBox1.Controls.Add(Me.Label28)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.WarningLabel)
        Me.GroupBox1.Controls.Add(Me.lblModuleTemperature)
        Me.GroupBox1.Controls.Add(Me.Label73)
        Me.GroupBox1.Controls.Add(Me.p33v_monitor)
        Me.GroupBox1.Controls.Add(Me.P3v3Label)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(4, 403)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox1.Size = New System.Drawing.Size(490, 280)
        Me.GroupBox1.TabIndex = 246
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Alarm Status"
        '
        'PictureBox6
        '
        Me.PictureBox6.Image = Global.ITTRA_GUI.My.Resources.Resources.green
        Me.PictureBox6.Location = New System.Drawing.Point(420, 200)
        Me.PictureBox6.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(26, 26)
        Me.PictureBox6.TabIndex = 259
        Me.PictureBox6.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.Image = Global.ITTRA_GUI.My.Resources.Resources.green
        Me.PictureBox7.Location = New System.Drawing.Point(330, 200)
        Me.PictureBox7.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(26, 26)
        Me.PictureBox7.TabIndex = 258
        Me.PictureBox7.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = Global.ITTRA_GUI.My.Resources.Resources.green
        Me.PictureBox4.Location = New System.Drawing.Point(420, 154)
        Me.PictureBox4.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(26, 26)
        Me.PictureBox4.TabIndex = 257
        Me.PictureBox4.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = Global.ITTRA_GUI.My.Resources.Resources.green
        Me.PictureBox5.Location = New System.Drawing.Point(330, 154)
        Me.PictureBox5.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(26, 26)
        Me.PictureBox5.TabIndex = 256
        Me.PictureBox5.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.ITTRA_GUI.My.Resources.Resources.green
        Me.PictureBox3.Location = New System.Drawing.Point(420, 108)
        Me.PictureBox3.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(26, 26)
        Me.PictureBox3.TabIndex = 255
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.ITTRA_GUI.My.Resources.Resources.green
        Me.PictureBox2.Location = New System.Drawing.Point(330, 108)
        Me.PictureBox2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(26, 26)
        Me.PictureBox2.TabIndex = 254
        Me.PictureBox2.TabStop = False
        '
        'Label28
        '
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(38, 200)
        Me.Label28.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(150, 31)
        Me.Label28.TabIndex = 253
        Me.Label28.Tag = "output_monitors"
        Me.Label28.Text = "Link Up"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(405, 46)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 24)
        Me.Label2.TabIndex = 252
        Me.Label2.Text = "Alarm"
        Me.Label2.BackColor = Color.Yellow
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'WarningLabel
        '
        Me.WarningLabel.Location = New System.Drawing.Point(296, 46)
        Me.WarningLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.WarningLabel.Name = "WarningLabel"
        Me.WarningLabel.Size = New System.Drawing.Size(87, 24)
        Me.WarningLabel.TabIndex = 251
        Me.WarningLabel.Text = "Warning"
        Me.WarningLabel.BackColor = Color.Yellow
        Me.WarningLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblModuleTemperature
        '
        Me.lblModuleTemperature.BackColor = System.Drawing.Color.LightGray
        Me.lblModuleTemperature.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblModuleTemperature.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblModuleTemperature.Location = New System.Drawing.Point(225, 154)
        Me.lblModuleTemperature.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblModuleTemperature.Name = "lblModuleTemperature"
        Me.lblModuleTemperature.Size = New System.Drawing.Size(72, 31)
        Me.lblModuleTemperature.TabIndex = 250
        Me.lblModuleTemperature.Tag = "output_monitors"
        Me.lblModuleTemperature.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label73
        '
        Me.Label73.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label73.Location = New System.Drawing.Point(38, 154)
        Me.Label73.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(150, 31)
        Me.Label73.TabIndex = 249
        Me.Label73.Tag = "output_monitors"
        Me.Label73.Text = "Temperature [°C]"
        Me.Label73.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'p33v_monitor
        '
        Me.p33v_monitor.BackColor = System.Drawing.Color.LightGray
        Me.p33v_monitor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.p33v_monitor.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p33v_monitor.Location = New System.Drawing.Point(225, 108)
        Me.p33v_monitor.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.p33v_monitor.Name = "p33v_monitor"
        Me.p33v_monitor.Size = New System.Drawing.Size(72, 31)
        Me.p33v_monitor.TabIndex = 248
        Me.p33v_monitor.Tag = "output_monitors"
        Me.p33v_monitor.Text = "-99"
        Me.p33v_monitor.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'P3v3Label
        '
        Me.P3v3Label.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.P3v3Label.Location = New System.Drawing.Point(38, 108)
        Me.P3v3Label.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.P3v3Label.Name = "P3v3Label"
        Me.P3v3Label.Size = New System.Drawing.Size(150, 31)
        Me.P3v3Label.TabIndex = 247
        Me.P3v3Label.Tag = "output_monitors"
        Me.P3v3Label.Text = "Vcc"
        Me.P3v3Label.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'DSPModulationGroup
        '
        Me.DSPModulationGroup.Controls.Add(Me.LabelHighPow)
        Me.DSPModulationGroup.Controls.Add(Me.btn_EnableHighPow)
        Me.DSPModulationGroup.Controls.Add(Me.txtGridSpacing)
        Me.DSPModulationGroup.Controls.Add(Me.lblGridSpacing)
        Me.DSPModulationGroup.Controls.Add(Me.txtFirstFrequency)
        Me.DSPModulationGroup.Controls.Add(Me.lblFirstFrequency)
        Me.DSPModulationGroup.Controls.Add(Me.lblLastFrequency)
        Me.DSPModulationGroup.Controls.Add(Me.txtLastFrequency)
        Me.DSPModulationGroup.Controls.Add(Me.serNum)
        Me.DSPModulationGroup.Controls.Add(Me.parNum)
        Me.DSPModulationGroup.Controls.Add(Me.Label4)
        Me.DSPModulationGroup.Controls.Add(Me.Label5)
        Me.DSPModulationGroup.Controls.Add(Me.module_state_display)
        Me.DSPModulationGroup.Controls.Add(Me.Label7)
        Me.DSPModulationGroup.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DSPModulationGroup.Location = New System.Drawing.Point(4, 5)
        Me.DSPModulationGroup.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.DSPModulationGroup.Name = "DSPModulationGroup"
        Me.DSPModulationGroup.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.DSPModulationGroup.Size = New System.Drawing.Size(490, 375)
        Me.DSPModulationGroup.TabIndex = 245
        Me.DSPModulationGroup.TabStop = False
        Me.DSPModulationGroup.Text = "Module Status"
        '
        'LabelHighPow
        '
        Me.LabelHighPow.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelHighPow.Location = New System.Drawing.Point(24, 331)
        Me.LabelHighPow.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelHighPow.Name = "LabelHighPow"
        Me.LabelHighPow.Size = New System.Drawing.Size(190, 31)
        Me.LabelHighPow.TabIndex = 262
        Me.LabelHighPow.Tag = "input_controls"
        Me.LabelHighPow.Text = "Module Power State: "
        Me.LabelHighPow.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btn_EnableHighPow
        '
        Me.btn_EnableHighPow.BackColor = System.Drawing.Color.Silver
        Me.btn_EnableHighPow.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_EnableHighPow.Location = New System.Drawing.Point(246, 323)
        Me.btn_EnableHighPow.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btn_EnableHighPow.Name = "btn_EnableHighPow"
        Me.btn_EnableHighPow.Size = New System.Drawing.Size(136, 46)
        Me.btn_EnableHighPow.TabIndex = 261
        Me.btn_EnableHighPow.Tag = "input_controls"
        Me.btn_EnableHighPow.Text = "Low Power"
        Me.btn_EnableHighPow.BackColor = Color.Gray
        Me.btn_EnableHighPow.UseVisualStyleBackColor = False
        '
        'txtGridSpacing
        '
        Me.txtGridSpacing.BackColor = System.Drawing.Color.LightGray
        Me.txtGridSpacing.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.txtGridSpacing.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGridSpacing.Location = New System.Drawing.Point(246, 285)
        Me.txtGridSpacing.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.txtGridSpacing.Name = "txtGridSpacing"
        Me.txtGridSpacing.Size = New System.Drawing.Size(111, 31)
        Me.txtGridSpacing.TabIndex = 260
        Me.txtGridSpacing.Tag = "output_monitors"
        Me.txtGridSpacing.Text = "50"
        Me.txtGridSpacing.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.txtGridSpacing.Visible = False
        '
        'lblGridSpacing
        '
        Me.lblGridSpacing.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGridSpacing.Location = New System.Drawing.Point(24, 285)
        Me.lblGridSpacing.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblGridSpacing.Name = "lblGridSpacing"
        Me.lblGridSpacing.Size = New System.Drawing.Size(178, 31)
        Me.lblGridSpacing.TabIndex = 259
        Me.lblGridSpacing.Tag = "input_controls"
        Me.lblGridSpacing.Text = "Grid Spacing [GHz]"
        Me.lblGridSpacing.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblGridSpacing.Visible = False
        '
        'txtFirstFrequency
        '
        Me.txtFirstFrequency.BackColor = System.Drawing.Color.LightGray
        Me.txtFirstFrequency.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.txtFirstFrequency.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFirstFrequency.Location = New System.Drawing.Point(246, 192)
        Me.txtFirstFrequency.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.txtFirstFrequency.Name = "txtFirstFrequency"
        Me.txtFirstFrequency.Size = New System.Drawing.Size(111, 31)
        Me.txtFirstFrequency.TabIndex = 256
        Me.txtFirstFrequency.Tag = "output_monitors"
        Me.txtFirstFrequency.Text = "191.6"
        Me.txtFirstFrequency.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.txtFirstFrequency.Visible = False
        '
        'lblFirstFrequency
        '
        Me.lblFirstFrequency.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFirstFrequency.Location = New System.Drawing.Point(36, 192)
        Me.lblFirstFrequency.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblFirstFrequency.Name = "lblFirstFrequency"
        Me.lblFirstFrequency.Size = New System.Drawing.Size(168, 31)
        Me.lblFirstFrequency.TabIndex = 255
        Me.lblFirstFrequency.Tag = "output_monitors"
        Me.lblFirstFrequency.Text = "First Freq [THz]"
        Me.lblFirstFrequency.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblFirstFrequency.Visible = False
        '
        'lblLastFrequency
        '
        Me.lblLastFrequency.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLastFrequency.Location = New System.Drawing.Point(40, 238)
        Me.lblLastFrequency.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblLastFrequency.Name = "lblLastFrequency"
        Me.lblLastFrequency.Size = New System.Drawing.Size(164, 31)
        Me.lblLastFrequency.TabIndex = 257
        Me.lblLastFrequency.Tag = "output_monitors"
        Me.lblLastFrequency.Text = "Last Freq [THz]"
        Me.lblLastFrequency.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblLastFrequency.Visible = False
        '
        'txtLastFrequency
        '
        Me.txtLastFrequency.BackColor = System.Drawing.Color.LightGray
        Me.txtLastFrequency.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.txtLastFrequency.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLastFrequency.Location = New System.Drawing.Point(246, 238)
        Me.txtLastFrequency.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.txtLastFrequency.Name = "txtLastFrequency"
        Me.txtLastFrequency.Size = New System.Drawing.Size(111, 31)
        Me.txtLastFrequency.TabIndex = 258
        Me.txtLastFrequency.Tag = "output_monitors"
        Me.txtLastFrequency.Text = "196.1"
        Me.txtLastFrequency.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.txtLastFrequency.Visible = False
        '
        'serNum
        '
        Me.serNum.BackColor = System.Drawing.Color.LightGray
        Me.serNum.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.serNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.serNum.Location = New System.Drawing.Point(246, 54)
        Me.serNum.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.serNum.Name = "serNum"
        Me.serNum.Size = New System.Drawing.Size(210, 31)
        Me.serNum.TabIndex = 226
        Me.serNum.Text = "Serial number"
        Me.serNum.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'parNum
        '
        Me.parNum.BackColor = System.Drawing.Color.LightGray
        Me.parNum.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.parNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.parNum.Location = New System.Drawing.Point(246, 100)
        Me.parNum.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.parNum.Name = "parNum"
        Me.parNum.Size = New System.Drawing.Size(210, 31)
        Me.parNum.TabIndex = 225
        Me.parNum.Text = "Part number"
        Me.parNum.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(45, 100)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(159, 31)
        Me.Label4.TabIndex = 224
        Me.Label4.Text = "Part Number:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(45, 54)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(159, 31)
        Me.Label5.TabIndex = 223
        Me.Label5.Text = "Serial Number:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'module_state_display
        '
        Me.module_state_display.BackColor = System.Drawing.Color.LightGray
        Me.module_state_display.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.module_state_display.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.module_state_display.Location = New System.Drawing.Point(246, 146)
        Me.module_state_display.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.module_state_display.Name = "module_state_display"
        Me.module_state_display.Size = New System.Drawing.Size(210, 31)
        Me.module_state_display.TabIndex = 227
        Me.module_state_display.Tag = "output_monitors"
        Me.module_state_display.Text = "module absent"
        Me.module_state_display.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Label7.Location = New System.Drawing.Point(45, 146)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(159, 31)
        Me.Label7.TabIndex = 222
        Me.Label7.Tag = "output_monitors"
        Me.Label7.Text = "Module State:"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.MenuStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EvalBoardMenu, Me.MDIOToolStripMenuItem, Me.PopupGUIToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(14, 14)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(4, 3, 0, 3)
        Me.MenuStrip1.Size = New System.Drawing.Size(253, 35)
        Me.MenuStrip1.TabIndex = 4
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'EvalBoardMenu
        '
        Me.EvalBoardMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Eval1MenuItem, Me.Eval2MenuItem, Me.Eval3MenuItem, Me.Eval4MenuItem, Me.ManualEntryToolStripMenuItem, Me.ConnectToolStripMenuItem, Me.DisconnectToolStripMenuItem})
        Me.EvalBoardMenu.Name = "EvalBoardMenu"
        Me.EvalBoardMenu.Size = New System.Drawing.Size(107, 29)
        Me.EvalBoardMenu.Text = "Eval Board"
        '
        'Eval1MenuItem
        '
        Me.Eval1MenuItem.Name = "Eval1MenuItem"
        Me.Eval1MenuItem.Size = New System.Drawing.Size(216, 30)
        Me.Eval1MenuItem.Text = "222016122320"
        Me.Eval1MenuItem.Visible = False
        '
        'Eval2MenuItem
        '
        Me.Eval2MenuItem.Name = "Eval2MenuItem"
        Me.Eval2MenuItem.Size = New System.Drawing.Size(216, 30)
        Me.Eval2MenuItem.Text = "222017081802"
        Me.Eval2MenuItem.Visible = False
        '
        'Eval3MenuItem
        '
        Me.Eval3MenuItem.Name = "Eval3MenuItem"
        Me.Eval3MenuItem.Size = New System.Drawing.Size(216, 30)
        Me.Eval3MenuItem.Text = "222017081603"
        Me.Eval3MenuItem.Visible = False
        '
        'Eval4MenuItem
        '
        Me.Eval4MenuItem.Name = "Eval4MenuItem"
        Me.Eval4MenuItem.Size = New System.Drawing.Size(216, 30)
        Me.Eval4MenuItem.Text = "222016122213"
        Me.Eval4MenuItem.Visible = False
        '
        'ManualEntryToolStripMenuItem
        '
        Me.ManualEntryToolStripMenuItem.Name = "ManualEntryToolStripMenuItem"
        Me.ManualEntryToolStripMenuItem.Size = New System.Drawing.Size(216, 30)
        Me.ManualEntryToolStripMenuItem.Text = "Manual Entry"
        Me.ManualEntryToolStripMenuItem.Visible = False
        '
        'ConnectToolStripMenuItem
        '
        Me.ConnectToolStripMenuItem.Name = "ConnectToolStripMenuItem"
        Me.ConnectToolStripMenuItem.Size = New System.Drawing.Size(216, 30)
        Me.ConnectToolStripMenuItem.Text = "Connect"
        '
        'DisconnectToolStripMenuItem
        '
        Me.DisconnectToolStripMenuItem.Enabled = False
        Me.DisconnectToolStripMenuItem.Name = "DisconnectToolStripMenuItem"
        Me.DisconnectToolStripMenuItem.Size = New System.Drawing.Size(216, 30)
        Me.DisconnectToolStripMenuItem.Text = "Disconnect"
        '
        'MDIOToolStripMenuItem
        '
        Me.MDIOToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ReadWriteToolStripMenuItem})
        Me.MDIOToolStripMenuItem.Enabled = False
        Me.MDIOToolStripMenuItem.Name = "MDIOToolStripMenuItem"
        Me.MDIOToolStripMenuItem.Size = New System.Drawing.Size(72, 29)
        Me.MDIOToolStripMenuItem.Text = "MDIO"
        '
        'ReadWriteToolStripMenuItem
        '
        Me.ReadWriteToolStripMenuItem.Name = "ReadWriteToolStripMenuItem"
        Me.ReadWriteToolStripMenuItem.Size = New System.Drawing.Size(177, 30)
        Me.ReadWriteToolStripMenuItem.Text = "ReadWrite"
        '
        'PopupGUIToolStripMenuItem
        '
        Me.PopupGUIToolStripMenuItem.Enabled = False
        Me.PopupGUIToolStripMenuItem.Name = "PopupGUIToolStripMenuItem"
        Me.PopupGUIToolStripMenuItem.Size = New System.Drawing.Size(110, 29)
        Me.PopupGUIToolStripMenuItem.Text = "Popup GUI"
        Me.PopupGUIToolStripMenuItem.Visible = False
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem, Me.QuitToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(61, 29)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(146, 30)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'QuitToolStripMenuItem
        '
        Me.QuitToolStripMenuItem.Name = "QuitToolStripMenuItem"
        Me.QuitToolStripMenuItem.Size = New System.Drawing.Size(146, 30)
        Me.QuitToolStripMenuItem.Text = "Quit"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Silver
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.dsp_panel)
        Me.Panel1.Controls.Add(Me.GroupBox3)
        Me.Panel1.Enabled = False
        Me.Panel1.Location = New System.Drawing.Point(570, 79)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(738, 897)
        Me.Panel1.TabIndex = 5
        '
        'dsp_panel
        '
        Me.dsp_panel.Controls.Add(Me.GroupBox7)
        Me.dsp_panel.Controls.Add(Me.GroupBox6)
        Me.dsp_panel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dsp_panel.Location = New System.Drawing.Point(4, 322)
        Me.dsp_panel.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.dsp_panel.Name = "dsp_panel"
        Me.dsp_panel.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.dsp_panel.Size = New System.Drawing.Size(724, 390)
        Me.dsp_panel.TabIndex = 246
        Me.dsp_panel.TabStop = False
        Me.dsp_panel.Text = "DSP Controls"
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.Label71)
        Me.GroupBox7.Controls.Add(Me.Label81)
        Me.GroupBox7.Controls.Add(Me.Label80)
        Me.GroupBox7.Controls.Add(Me.DSPSyncCheckBox)
        Me.GroupBox7.Controls.Add(Me.Label79)
        Me.GroupBox7.Controls.Add(Me.cbDSPCSP)
        Me.GroupBox7.Controls.Add(Me.cbDSPFEC)
        Me.GroupBox7.Controls.Add(Me.cbDSPModulation)
        Me.GroupBox7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox7.Location = New System.Drawing.Point(14, 32)
        Me.GroupBox7.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox7.Size = New System.Drawing.Size(693, 167)
        Me.GroupBox7.TabIndex = 241
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Tag = "input_controls"
        Me.GroupBox7.Text = "Modulation"
        '
        'Label71
        '
        Me.Label71.Location = New System.Drawing.Point(93, 86)
        Me.Label71.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(110, 29)
        Me.Label71.TabIndex = 94
        Me.Label71.Text = "Module"
        '
        'Label81
        '
        Me.Label81.Location = New System.Drawing.Point(513, 28)
        Me.Label81.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(112, 23)
        Me.Label81.TabIndex = 92
        Me.Label81.Text = "Cycle Slip"
        Me.Label81.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label80
        '
        Me.Label80.Location = New System.Drawing.Point(402, 25)
        Me.Label80.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(81, 28)
        Me.Label80.TabIndex = 91
        Me.Label80.Text = "FEC"
        Me.Label80.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'DSPSyncCheckBox
        '
        Me.DSPSyncCheckBox.Checked = True
        Me.DSPSyncCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.DSPSyncCheckBox.Location = New System.Drawing.Point(69, 58)
        Me.DSPSyncCheckBox.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.DSPSyncCheckBox.Name = "DSPSyncCheckBox"
        Me.DSPSyncCheckBox.Size = New System.Drawing.Size(138, 29)
        Me.DSPSyncCheckBox.TabIndex = 93
        Me.DSPSyncCheckBox.Text = "Sync with"
        Me.DSPSyncCheckBox.UseVisualStyleBackColor = True
        '
        'Label79
        '
        Me.Label79.Location = New System.Drawing.Point(264, 28)
        Me.Label79.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(58, 23)
        Me.Label79.TabIndex = 90
        Me.Label79.Text = "Mode"
        Me.Label79.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cbDSPCSP
        '
        Me.cbDSPCSP.DisplayMember = "Text"
        Me.cbDSPCSP.Enabled = False
        Me.cbDSPCSP.FormattingEnabled = True
        Me.cbDSPCSP.Items.AddRange(New Object() {"0", "5", "6", "7", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40"})
        Me.cbDSPCSP.Location = New System.Drawing.Point(516, 58)
        Me.cbDSPCSP.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cbDSPCSP.Name = "cbDSPCSP"
        Me.cbDSPCSP.Size = New System.Drawing.Size(108, 30)
        Me.cbDSPCSP.TabIndex = 89
        Me.cbDSPCSP.Tag = "input_controls"
        Me.cbDSPCSP.Text = "23"
        Me.cbDSPCSP.ValueMember = "Value"
        '
        'cbDSPFEC
        '
        Me.cbDSPFEC.DisplayMember = "Text"
        Me.cbDSPFEC.Enabled = False
        Me.cbDSPFEC.FormattingEnabled = True
        Me.cbDSPFEC.Items.AddRange(New Object() {"16%", "18%", "20%"})
        Me.cbDSPFEC.Location = New System.Drawing.Point(386, 58)
        Me.cbDSPFEC.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cbDSPFEC.Name = "cbDSPFEC"
        Me.cbDSPFEC.Size = New System.Drawing.Size(106, 30)
        Me.cbDSPFEC.TabIndex = 88
        Me.cbDSPFEC.Tag = "input_controls"
        Me.cbDSPFEC.Text = "18%"
        Me.cbDSPFEC.ValueMember = "Value"
        '
        'cbDSPModulation
        '
        Me.cbDSPModulation.DisplayMember = "Text"
        Me.cbDSPModulation.Enabled = False
        Me.cbDSPModulation.FormattingEnabled = True
        Me.cbDSPModulation.Items.AddRange(New Object() {"QPSK", "QAM16"})
        Me.cbDSPModulation.Location = New System.Drawing.Point(216, 58)
        Me.cbDSPModulation.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cbDSPModulation.Name = "cbDSPModulation"
        Me.cbDSPModulation.Size = New System.Drawing.Size(139, 30)
        Me.cbDSPModulation.TabIndex = 87
        Me.cbDSPModulation.Tag = "input_controls"
        Me.cbDSPModulation.Text = "QPSK"
        Me.cbDSPModulation.ValueMember = "Value"
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.Label19)
        Me.GroupBox6.Controls.Add(Me.Label20)
        Me.GroupBox6.Controls.Add(Me.postFecBerA)
        Me.GroupBox6.Controls.Add(Me.preFecBerA)
        Me.GroupBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox6.Location = New System.Drawing.Point(14, 223)
        Me.GroupBox6.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox6.Size = New System.Drawing.Size(693, 138)
        Me.GroupBox6.TabIndex = 240
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Tag = "input_controls"
        Me.GroupBox6.Text = "Forward Error Correction"
        '
        'Label19
        '
        Me.Label19.Location = New System.Drawing.Point(21, 54)
        Me.Label19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(104, 46)
        Me.Label19.TabIndex = 220
        Me.Label19.Text = "Pre-FEC"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label20
        '
        Me.Label20.Location = New System.Drawing.Point(346, 54)
        Me.Label20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(110, 46)
        Me.Label20.TabIndex = 221
        Me.Label20.Text = "Post-FEC"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'postFecBerA
        '
        Me.postFecBerA.BackColor = System.Drawing.Color.LightGray
        Me.postFecBerA.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.postFecBerA.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.postFecBerA.Location = New System.Drawing.Point(465, 54)
        Me.postFecBerA.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.postFecBerA.Name = "postFecBerA"
        Me.postFecBerA.Size = New System.Drawing.Size(202, 46)
        Me.postFecBerA.TabIndex = 223
        Me.postFecBerA.Tag = "input_controls"
        Me.postFecBerA.Text = "0"
        Me.postFecBerA.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'preFecBerA
        '
        Me.preFecBerA.BackColor = System.Drawing.Color.LightGray
        Me.preFecBerA.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.preFecBerA.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.preFecBerA.Location = New System.Drawing.Point(134, 54)
        Me.preFecBerA.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.preFecBerA.Name = "preFecBerA"
        Me.preFecBerA.Size = New System.Drawing.Size(202, 46)
        Me.preFecBerA.TabIndex = 222
        Me.preFecBerA.Tag = "input_controls"
        Me.preFecBerA.Text = "0"
        Me.preFecBerA.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.biasLoopControl)
        Me.GroupBox3.Controls.Add(Me.FreqComboBox)
        Me.GroupBox3.Controls.Add(Me.Label56)
        Me.GroupBox3.Controls.Add(Me.Label53)
        Me.GroupBox3.Controls.Add(Me.lblChannelFrequencyRd)
        Me.GroupBox3.Controls.Add(Me.lblMSAChannel)
        Me.GroupBox3.Controls.Add(Me.txtMSAChannel)
        Me.GroupBox3.Controls.Add(Me.lblValidMSAChannels)
        Me.GroupBox3.Controls.Add(Me.lblModulationFormat)
        Me.GroupBox3.Controls.Add(Me.cbModulationFormat)
        Me.GroupBox3.Controls.Add(Me.txtChannelFrequency)
        Me.GroupBox3.Controls.Add(Me.lblFTF)
        Me.GroupBox3.Controls.Add(Me.lblChannelFrequency)
        Me.GroupBox3.Controls.Add(Me.txtFTF)
        Me.GroupBox3.Controls.Add(Me.GroupBox5)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(4, 5)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox3.Size = New System.Drawing.Size(724, 308)
        Me.GroupBox3.TabIndex = 245
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Module TX Controls"
        '
        'Label13
        '
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(48, 251)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(119, 24)
        Me.Label13.TabIndex = 257
        Me.Label13.Tag = "input_controls"
        Me.Label13.Text = "Bias Loop Control"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'biasLoopControl
        '
        Me.biasLoopControl.DisplayMember = "Text"
        Me.biasLoopControl.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.biasLoopControl.ItemHeight = 22
        Me.biasLoopControl.Items.AddRange(New Object() {"Auto", "Manual"})
        Me.biasLoopControl.Location = New System.Drawing.Point(188, 245)
        Me.biasLoopControl.MaxDropDownItems = 2
        Me.biasLoopControl.Name = "biasLoopControl"
        Me.biasLoopControl.Size = New System.Drawing.Size(88, 30)
        Me.biasLoopControl.TabIndex = 256
        Me.biasLoopControl.Tag = "input_controls"
        Me.biasLoopControl.Text = "Auto"
        Me.biasLoopControl.ValueMember = "Value"
        '
        'FreqComboBox
        '
        Me.FreqComboBox.FormattingEnabled = True
        Me.FreqComboBox.Location = New System.Drawing.Point(519, 157)
        Me.FreqComboBox.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.FreqComboBox.Name = "FreqComboBox"
        Me.FreqComboBox.Size = New System.Drawing.Size(180, 33)
        Me.FreqComboBox.TabIndex = 255
        '
        'Label56
        '
        Me.Label56.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label56.Location = New System.Drawing.Point(648, 205)
        Me.Label56.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(34, 23)
        Me.Label56.TabIndex = 254
        Me.Label56.Text = "Rd"
        '
        'Label53
        '
        Me.Label53.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.Location = New System.Drawing.Point(648, 163)
        Me.Label53.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(33, 23)
        Me.Label53.TabIndex = 253
        Me.Label53.Text = "Wr"
        '
        'lblChannelFrequencyRd
        '
        Me.lblChannelFrequencyRd.BackColor = System.Drawing.Color.LightGray
        Me.lblChannelFrequencyRd.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblChannelFrequencyRd.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblChannelFrequencyRd.Location = New System.Drawing.Point(519, 205)
        Me.lblChannelFrequencyRd.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblChannelFrequencyRd.Name = "lblChannelFrequencyRd"
        Me.lblChannelFrequencyRd.Size = New System.Drawing.Size(120, 31)
        Me.lblChannelFrequencyRd.TabIndex = 252
        Me.lblChannelFrequencyRd.Tag = "input_controls"
        Me.lblChannelFrequencyRd.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblMSAChannel
        '
        Me.lblMSAChannel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMSAChannel.Location = New System.Drawing.Point(334, 100)
        Me.lblMSAChannel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblMSAChannel.Name = "lblMSAChannel"
        Me.lblMSAChannel.Size = New System.Drawing.Size(176, 31)
        Me.lblMSAChannel.TabIndex = 250
        Me.lblMSAChannel.Text = "MSA Channel"
        Me.lblMSAChannel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtMSAChannel
        '
        Me.txtMSAChannel.BackColor = System.Drawing.Color.LightGray
        Me.txtMSAChannel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMSAChannel.Location = New System.Drawing.Point(519, 100)
        Me.txtMSAChannel.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtMSAChannel.Name = "txtMSAChannel"
        Me.txtMSAChannel.ReadOnly = True
        Me.txtMSAChannel.Size = New System.Drawing.Size(85, 28)
        Me.txtMSAChannel.TabIndex = 249
        Me.txtMSAChannel.Tag = "ChannelUpdate"
        Me.txtMSAChannel.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblValidMSAChannels
        '
        Me.lblValidMSAChannels.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblValidMSAChannels.Location = New System.Drawing.Point(614, 100)
        Me.lblValidMSAChannels.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblValidMSAChannels.Name = "lblValidMSAChannels"
        Me.lblValidMSAChannels.Size = New System.Drawing.Size(93, 31)
        Me.lblValidMSAChannels.TabIndex = 251
        Me.lblValidMSAChannels.Text = "[ 0 - 0 ]"
        Me.lblValidMSAChannels.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblModulationFormat
        '
        Me.lblModulationFormat.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblModulationFormat.Location = New System.Drawing.Point(334, 46)
        Me.lblModulationFormat.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblModulationFormat.Name = "lblModulationFormat"
        Me.lblModulationFormat.Size = New System.Drawing.Size(176, 35)
        Me.lblModulationFormat.TabIndex = 248
        Me.lblModulationFormat.Tag = "input_controls"
        Me.lblModulationFormat.Text = "Modulation Format"
        Me.lblModulationFormat.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cbModulationFormat
        '
        Me.cbModulationFormat.DisplayMember = "Text"
        Me.cbModulationFormat.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbModulationFormat.FormattingEnabled = True
        Me.cbModulationFormat.Items.AddRange(New Object() {"QPSK", "QAM8", "QAM16"})
        Me.cbModulationFormat.Location = New System.Drawing.Point(519, 46)
        Me.cbModulationFormat.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cbModulationFormat.Name = "cbModulationFormat"
        Me.cbModulationFormat.Size = New System.Drawing.Size(148, 30)
        Me.cbModulationFormat.TabIndex = 247
        Me.cbModulationFormat.Tag = "input_controls"
        Me.cbModulationFormat.Text = "QPSK"
        Me.cbModulationFormat.ValueMember = "Value"
        '
        'txtChannelFrequency
        '
        Me.txtChannelFrequency.BackColor = System.Drawing.SystemColors.Window
        Me.txtChannelFrequency.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtChannelFrequency.Location = New System.Drawing.Point(519, 162)
        Me.txtChannelFrequency.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtChannelFrequency.Name = "txtChannelFrequency"
        Me.txtChannelFrequency.Size = New System.Drawing.Size(118, 28)
        Me.txtChannelFrequency.TabIndex = 244
        Me.txtChannelFrequency.Tag = "input_controls"
        Me.txtChannelFrequency.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtChannelFrequency.Visible = False
        '
        'lblFTF
        '
        Me.lblFTF.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFTF.Location = New System.Drawing.Point(334, 254)
        Me.lblFTF.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblFTF.Name = "lblFTF"
        Me.lblFTF.Size = New System.Drawing.Size(184, 31)
        Me.lblFTF.TabIndex = 246
        Me.lblFTF.Tag = "input_controls"
        Me.lblFTF.Text = "Fine Tune [MHz]"
        Me.lblFTF.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblFTF.Visible = False
        '
        'lblChannelFrequency
        '
        Me.lblChannelFrequency.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblChannelFrequency.Location = New System.Drawing.Point(394, 160)
        Me.lblChannelFrequency.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblChannelFrequency.Name = "lblChannelFrequency"
        Me.lblChannelFrequency.Size = New System.Drawing.Size(116, 62)
        Me.lblChannelFrequency.TabIndex = 243
        Me.lblChannelFrequency.Tag = "input_controls"
        Me.lblChannelFrequency.Text = "Channel Freq. [THz]"
        Me.lblChannelFrequency.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtFTF
        '
        Me.txtFTF.AutoSize = True
        Me.txtFTF.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFTF.Location = New System.Drawing.Point(522, 258)
        Me.txtFTF.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtFTF.Maximum = New Decimal(New Integer() {32767, 0, 0, 0})
        Me.txtFTF.Minimum = New Decimal(New Integer() {32768, 0, 0, -2147483648})
        Me.txtFTF.Name = "txtFTF"
        Me.txtFTF.Size = New System.Drawing.Size(120, 26)
        Me.txtFTF.TabIndex = 245
        Me.txtFTF.Tag = "input_controls"
        Me.txtFTF.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtFTF.Visible = False
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.pb_txOn)
        Me.GroupBox5.Controls.Add(Me.txtTxOutPutPower)
        Me.GroupBox5.Controls.Add(Me.txPowerMon)
        Me.GroupBox5.Controls.Add(Me.Label46)
        Me.GroupBox5.Controls.Add(Me.lblTxOutputPower)
        Me.GroupBox5.Controls.Add(Me.txOnButton)
        Me.GroupBox5.Controls.Add(Me.Label40)
        Me.GroupBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.Location = New System.Drawing.Point(9, 35)
        Me.GroupBox5.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox5.Size = New System.Drawing.Size(304, 188)
        Me.GroupBox5.TabIndex = 239
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Tag = "input_controls"
        Me.GroupBox5.Text = "Tx Output Power [dBm]"
        '
        'pb_txOn
        '
        Me.pb_txOn.Image = Global.ITTRA_GUI.My.Resources.Resources.green
        Me.pb_txOn.Location = New System.Drawing.Point(9, 135)
        Me.pb_txOn.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.pb_txOn.Name = "pb_txOn"
        Me.pb_txOn.Size = New System.Drawing.Size(26, 26)
        Me.pb_txOn.TabIndex = 239
        Me.pb_txOn.TabStop = False
        '
        'txtTxOutPutPower
        '
        Me.txtTxOutPutPower.Location = New System.Drawing.Point(44, 66)
        Me.txtTxOutPutPower.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtTxOutPutPower.Name = "txtTxOutPutPower"
        Me.txtTxOutPutPower.Size = New System.Drawing.Size(91, 28)
        Me.txtTxOutPutPower.TabIndex = 238
        Me.txtTxOutPutPower.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtTxOutPutPower.Visible = False
        '
        'txPowerMon
        '
        Me.txPowerMon.BackColor = System.Drawing.Color.LightGray
        Me.txPowerMon.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.txPowerMon.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txPowerMon.Location = New System.Drawing.Point(186, 69)
        Me.txPowerMon.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.txPowerMon.Name = "txPowerMon"
        Me.txPowerMon.Size = New System.Drawing.Size(81, 31)
        Me.txPowerMon.TabIndex = 173
        Me.txPowerMon.Tag = "output_monitors"
        Me.txPowerMon.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.txPowerMon.Visible = False
        '
        'Label46
        '
        Me.Label46.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(188, 32)
        Me.Label46.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(76, 31)
        Me.Label46.TabIndex = 237
        Me.Label46.Tag = "input_controls"
        Me.Label46.Text = "Monitor"
        Me.Label46.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Label46.Visible = False
        '
        'lblTxOutputPower
        '
        Me.lblTxOutputPower.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTxOutputPower.Location = New System.Drawing.Point(39, 32)
        Me.lblTxOutputPower.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblTxOutputPower.Name = "lblTxOutputPower"
        Me.lblTxOutputPower.Size = New System.Drawing.Size(92, 31)
        Me.lblTxOutputPower.TabIndex = 60
        Me.lblTxOutputPower.Tag = "input_controls"
        Me.lblTxOutputPower.Text = "Setpoint"
        Me.lblTxOutputPower.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblTxOutputPower.Visible = False
        '
        'txOnButton
        '
        Me.txOnButton.BackColor = System.Drawing.Color.Silver
        Me.txOnButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txOnButton.Location = New System.Drawing.Point(159, 125)
        Me.txOnButton.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txOnButton.Name = "txOnButton"
        Me.txOnButton.Size = New System.Drawing.Size(136, 46)
        Me.txOnButton.TabIndex = 233
        Me.txOnButton.Tag = "input_controls"
        Me.txOnButton.Text = "Turn Tx Off"
        Me.txOnButton.UseVisualStyleBackColor = False
        '
        'Label40
        '
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(60, 135)
        Me.Label40.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(76, 29)
        Me.Label40.TabIndex = 232
        Me.Label40.Tag = "input_controls"
        Me.Label40.Text = "TX ON"
        Me.Label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblStatus
        '
        Me.lblStatus.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblStatus.BackColor = System.Drawing.SystemColors.Control
        Me.lblStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblStatus.Location = New System.Drawing.Point(18, 985)
        Me.lblStatus.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(1324, 24)
        Me.lblStatus.TabIndex = 7
        '
        'refreshTimer
        '
        Me.refreshTimer.Interval = 10
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Silver
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.disconnectFromModule)
        Me.Panel2.Controls.Add(Me.connectToModule)
        Me.Panel2.Controls.Add(Me.snapshot)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.cbMDIOinstance)
        Me.Panel2.Controls.Add(Me.cbMDIOaddress)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Location = New System.Drawing.Point(1312, 577)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(481, 399)
        Me.Panel2.TabIndex = 8
        Me.Panel2.Visible = False
        '
        'disconnectFromModule
        '
        Me.disconnectFromModule.BackColor = System.Drawing.Color.Silver
        Me.disconnectFromModule.Enabled = False
        Me.disconnectFromModule.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.disconnectFromModule.Location = New System.Drawing.Point(312, 38)
        Me.disconnectFromModule.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.disconnectFromModule.Name = "disconnectFromModule"
        Me.disconnectFromModule.Size = New System.Drawing.Size(150, 62)
        Me.disconnectFromModule.TabIndex = 80
        Me.disconnectFromModule.Text = "Disconnect"
        Me.disconnectFromModule.UseVisualStyleBackColor = False
        '
        'connectToModule
        '
        Me.connectToModule.BackColor = System.Drawing.Color.Silver
        Me.connectToModule.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.connectToModule.Location = New System.Drawing.Point(40, 37)
        Me.connectToModule.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.connectToModule.Name = "connectToModule"
        Me.connectToModule.Size = New System.Drawing.Size(150, 62)
        Me.connectToModule.TabIndex = 74
        Me.connectToModule.Text = "Connect"
        Me.connectToModule.UseVisualStyleBackColor = False
        '
        'snapshot
        '
        Me.snapshot.Enabled = False
        Me.snapshot.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.snapshot.Location = New System.Drawing.Point(166, 234)
        Me.snapshot.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.snapshot.Name = "snapshot"
        Me.snapshot.Size = New System.Drawing.Size(150, 62)
        Me.snapshot.TabIndex = 73
        Me.snapshot.Text = "Data dump (.csv)"
        Me.snapshot.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(130, 228)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(84, 31)
        Me.Label1.TabIndex = 72
        Me.Label1.Text = "Instance"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(4, 0)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(128, 34)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Connection"
        '
        'cbMDIOinstance
        '
        Me.cbMDIOinstance.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbMDIOinstance.FormattingEnabled = True
        Me.cbMDIOinstance.Items.AddRange(New Object() {"0", "0", "0"})
        Me.cbMDIOinstance.Location = New System.Drawing.Point(285, 220)
        Me.cbMDIOinstance.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cbMDIOinstance.Name = "cbMDIOinstance"
        Me.cbMDIOinstance.Size = New System.Drawing.Size(67, 30)
        Me.cbMDIOinstance.TabIndex = 71
        Me.cbMDIOinstance.Text = "0"
        '
        'cbMDIOaddress
        '
        Me.cbMDIOaddress.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbMDIOaddress.FormattingEnabled = True
        Me.cbMDIOaddress.Items.AddRange(New Object() {"1", "1", "1", "1", "1"})
        Me.cbMDIOaddress.Location = New System.Drawing.Point(285, 275)
        Me.cbMDIOaddress.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cbMDIOaddress.Name = "cbMDIOaddress"
        Me.cbMDIOaddress.Size = New System.Drawing.Size(67, 30)
        Me.cbMDIOaddress.TabIndex = 69
        Me.cbMDIOaddress.Text = "1"
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(140, 275)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(74, 31)
        Me.Label6.TabIndex = 70
        Me.Label6.Text = "Address"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'frmCFP2DCOGui
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1360, 1018)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.lblStatus)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.output_monitors)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frmCFP2DCOGui"
        Me.Text = "CFP2-DCO GUI"
        Me.output_monitors.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.DSPModulationGroup.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.dsp_panel.ResumeLayout(False)
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.txtFTF, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        CType(Me.pb_txOn, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents output_monitors As Panel
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents DSPModulationGroup As GroupBox
    Friend WithEvents LabelHighPow As Label
    Friend WithEvents btn_EnableHighPow As Button
    Friend WithEvents txtGridSpacing As Label
    Friend WithEvents lblGridSpacing As Label
    Friend WithEvents txtFirstFrequency As Label
    Friend WithEvents lblFirstFrequency As Label
    Friend WithEvents lblLastFrequency As Label
    Friend WithEvents txtLastFrequency As Label
    Friend WithEvents serNum As Label
    Friend WithEvents parNum As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents module_state_display As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents EvalBoardMenu As ToolStripMenuItem
    Friend WithEvents Eval1MenuItem As ToolStripMenuItem
    Friend WithEvents Eval2MenuItem As ToolStripMenuItem
    Friend WithEvents Eval3MenuItem As ToolStripMenuItem
    Friend WithEvents Eval4MenuItem As ToolStripMenuItem
    Friend WithEvents ManualEntryToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ConnectToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DisconnectToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PopupGUIToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MDIOToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReadWriteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Panel1 As Panel
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents dsp_panel As GroupBox
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents txtTxOutPutPower As TextBox
    Friend WithEvents txPowerMon As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents lblTxOutputPower As Label
    Friend WithEvents txOnButton As Button
    Friend WithEvents Label40 As Label
    Friend WithEvents PauseGuiButton As Button
    Friend WithEvents refreshInterval As ComboBox
    Friend WithEvents Label12 As Label
    Friend WithEvents monitorRefresh As Button
    Friend WithEvents FreqComboBox As ComboBox
    Friend WithEvents Label56 As Label
    Friend WithEvents Label53 As Label
    Friend WithEvents lblChannelFrequencyRd As Label
    Friend WithEvents lblMSAChannel As Label
    Friend WithEvents txtMSAChannel As TextBox
    Friend WithEvents lblValidMSAChannels As Label
    Friend WithEvents lblModulationFormat As Label
    Friend WithEvents cbModulationFormat As ComboBox
    Friend WithEvents txtChannelFrequency As TextBox
    Friend WithEvents lblFTF As Label
    Friend WithEvents lblChannelFrequency As Label
    Friend WithEvents txtFTF As NumericUpDown
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents postFecBerA As Label
    Friend WithEvents preFecBerA As Label
    Friend WithEvents Label71 As Label
    Friend WithEvents Label81 As Label
    Friend WithEvents Label80 As Label
    Friend WithEvents DSPSyncCheckBox As CheckBox
    Friend WithEvents Label79 As Label
    Friend WithEvents cbDSPCSP As ComboBox
    Friend WithEvents cbDSPFEC As ComboBox
    Friend WithEvents cbDSPModulation As ComboBox
    Friend WithEvents lblStatus As Label
    Friend WithEvents pb_txOn As PictureBox
    Friend WithEvents Label28 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents WarningLabel As Label
    Friend WithEvents lblModuleTemperature As Label
    Friend WithEvents Label73 As Label
    Friend WithEvents p33v_monitor As Label
    Friend WithEvents P3v3Label As Label
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents QuitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents refreshTimer As Timer
    Friend WithEvents Panel2 As Panel
    Friend WithEvents disconnectFromModule As Button
    Friend WithEvents connectToModule As Button
    Friend WithEvents snapshot As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents cbMDIOinstance As ComboBox
    Friend WithEvents cbMDIOaddress As ComboBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents biasLoopControl As ComboBox
End Class
