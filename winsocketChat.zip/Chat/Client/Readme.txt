Filename: Readme.txt
March 19, 2020

This program was compiled using Microsoft Visual C++ version 6.0
on a Windows 10 Ultimate Platform.

The CodeWright version 7.0 editor was used during development.
Open the Client.psp project space.

The ws2_32.lib library must be included in the linker.

//Visual C++ project workspace file deviations:
//
//  1. The comctl32.lib library must be included in the link
//     to support common dialogs and toolbars.
//     
//  2. The compiler must include the -Zp1 switch.
//     (Pack Structure Members on 1 byte boundary)

