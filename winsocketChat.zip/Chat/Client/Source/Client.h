// Filename: Client.h

#ifndef CLIENT_H
#define CLIENT_H

#include "resource.h"
#include <windows.h>
#include <stdio.h>
#include <process.h>

// Child Windows Support
#define NUM_CONTROLS      3
#define DLG_CHAT          0
#define DLG_NAME          1
#define DLG_CONNECT       2

VOID Thread(PVOID pvoid);
LRESULT CALLBACK WndProc (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK AboutDlgProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK SetupDlgProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

class CLIENT // Client.cpp
{
  void Initialize(HWND hwnd);
  WNDPROC OldClientWndProc;
  static LRESULT CALLBACK EditSubClassProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
  int EditTextReady;
  
  public:
  CLIENT()
  {
    hMainDlg  = 0;
    hMainWnd  = 0;
	EditTextReady = 0;
  }
  SOCKET sock;
  void Chat(HWND hwnd);

  HWND hMainDlg;  
  HWND hMainWnd;

  static BOOL CALLBACK DlgProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
};

class SETUP // Setup.cpp
{
  
  public:
  SETUP()
  {
	strcpy(IP_Address, "192.168.1.18");
    strcpy(Port, "5151");
  }
  char IP_Address[100];
  char Port[100];
};

class UTILITIES  // Utilities.cpp
{
  public:

  void ChangeFont(HWND hwnd, int id);
  void SizeMainWindow(HWND hwnd);
  void RepositionControls(HWND hwnd, LPARAM lParam);
  void CreateChildWindows(HWND hwnd);
  void InitWindowPosition(HWND hwnd);
};

extern CLIENT    client;
extern UTILITIES util;
extern SETUP     setup;
extern HWND hwndChild[NUM_CONTROLS];
extern HINSTANCE hInst;

#endif
