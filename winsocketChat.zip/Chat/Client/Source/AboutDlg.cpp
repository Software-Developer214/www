// Filename: AboutDlg.cpp

#include "resource.h"
#include "Client.h"

BOOL CALLBACK AboutDlgProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  switch(message)
  {
    case WM_INITDIALOG:
      return TRUE;
    
    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDOK:
        case IDCANCEL:
          EndDialog(hwnd, 0);
          return TRUE;
      }
      break;
  }
  return FALSE;
}

