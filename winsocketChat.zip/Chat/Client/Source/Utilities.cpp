// Filename: Utilities.cpp

#include "resource.h"
#include "Client.h"

// Change the font to Courier New
// Call with id of zero to release the font resource 
void UTILITIES::ChangeFont(HWND hwnd, int id)
{
  static HFONT hFont = NULL;
  
  if(id == 0)
  {
    DeleteObject(hFont);
    hFont = NULL;
    return;
  }
  
  if(hFont == NULL)
  {
    hFont = CreateFont(20, 0, 0, 0, FW_BOLD,
                       0, 0, 0, ANSI_CHARSET,
                       OUT_DEFAULT_PRECIS,
                       CLIP_DEFAULT_PRECIS,
                       DEFAULT_QUALITY,
                       DEFAULT_PITCH | FF_DONTCARE,
                       "Courier New" );
  }     

  SendMessage(GetDlgItem(hwnd, id), WM_SETFONT, (WPARAM)hFont,
              (LPARAM)MAKELONG((WORD)TRUE, 0));
}

void UTILITIES::CreateChildWindows(HWND hwnd)
{
  hwndChild[DLG_CHAT] = CreateWindowEx(WS_EX_CLIENTEDGE, "edit", "",
                                       WS_CHILD | WS_VISIBLE | ES_MULTILINE | ES_WANTRETURN |  WS_VSCROLL | WS_HSCROLL,
                                       0, 0, 0, 0, hwnd, (HMENU)IDC_CHAT, hInst, NULL);
  
  hwndChild[DLG_NAME] = CreateWindowEx(WS_EX_CLIENTEDGE, "edit", "",
                                       WS_CHILD | WS_VISIBLE | ES_LEFT | ES_NOHIDESEL | ES_AUTOHSCROLL,  
                                       0, 0, 0, 0, hwnd, (HMENU)IDC_NAME, hInst, NULL);

  hwndChild[DLG_CONNECT] = CreateWindow("button", "Connect", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
                                        0, 0, 0, 0, hwnd, (HMENU)IDC_CONNECT, hInst, NULL);
}

// Size the Parent Window around a Dialog Window
void UTILITIES::SizeMainWindow(HWND hwnd)
{
  RECT rect;
  
  GetWindowRect(hwnd, &rect);
  //  SetWindowPos(GetParent(hwnd), NULL, 0, 0, rect.right - rect.left,
  //               rect.bottom - rect.top + GetSystemMetrics(SM_CYCAPTION) 
  //               + GetSystemMetrics(SM_CYMENU), SWP_NOMOVE | SWP_NOZORDER);
  SetWindowPos(GetParent(hwnd), NULL, 0, 0, rect.right - rect.left,
               rect.bottom - rect.top, SWP_NOMOVE | SWP_NOZORDER);
}

void UTILITIES::InitWindowPosition(HWND hwnd)
{
  //  SetWindowPos(hwnd, NULL, 0, 0,
  //               State.WinSize.cx,
  //               State.WinSize.cy + GetSystemMetrics(SM_CYCAPTION) + GetSystemMetrics(SM_CYMENU),
  //               SWP_NOZORDER);
  SetWindowPos(hwnd, NULL, 0, 0, 600, 300, SWP_NOZORDER);
}

void UTILITIES::RepositionControls(HWND hwnd, LPARAM lParam)
{
  int i, cxChar, cyChar, cxClient = LOWORD(lParam), cyClient = HIWORD(lParam);
  RECT rect[NUM_CONTROLS];
  SIZE ButtonSize;
  POINT Pivot;

  cxChar = LOWORD(GetDialogBaseUnits());
  cyChar = HIWORD(GetDialogBaseUnits());

  ButtonSize.cx = 14 * cxChar;
  ButtonSize.cy = 7 * cyChar / 4;
  Pivot.x = cxChar;
  Pivot.y = cyClient - 2 * ButtonSize.cy - 2 * cxChar;

  rect[DLG_CHAT].left   = cxChar; 
  rect[DLG_CHAT].top    = cxChar;
  rect[DLG_CHAT].right  = cxClient - 2 * cxChar;
  rect[DLG_CHAT].bottom = cyClient - ButtonSize.cy - 3 * cxChar;

  rect[DLG_NAME].left   = Pivot.x; 
  rect[DLG_NAME].top    = Pivot.y + ButtonSize.cy + cxChar;
  rect[DLG_NAME].right  = cxClient - 3 * cxChar - ButtonSize.cx;
  rect[DLG_NAME].bottom = ButtonSize.cy;

  rect[DLG_CONNECT].left   = Pivot.x + rect[DLG_NAME].right + cxChar;
  rect[DLG_CONNECT].top    = Pivot.y + ButtonSize.cy + cxChar;
  rect[DLG_CONNECT].right  = ButtonSize.cx;
  rect[DLG_CONNECT].bottom = ButtonSize.cy;

  //  SetWindowPos(hMainDlg, NULL, 0, 0,
  //               cxClient, cyClient + GetSystemMetrics(SM_CYCAPTION) + GetSystemMetrics(SM_CYMENU),
  //               SWP_NOZORDER);
  SetWindowPos(client.hMainDlg, NULL, 0, 0, cxClient, cyClient, SWP_NOZORDER);

  for(i = 0; i < NUM_CONTROLS; i++)
  {
    SetWindowPos(hwndChild[i], NULL, rect[i].left, rect[i].top, rect[i].right, rect[i].bottom, SWP_NOZORDER);
  }
}


