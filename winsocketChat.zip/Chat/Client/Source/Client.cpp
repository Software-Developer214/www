// Filename: Client.cpp

#include "resource.h"
#include "Client.h"

VOID Thread(PVOID pvoid)
{
  while(TRUE)
  {
    client.Chat(client.hMainDlg);
  }
}

BOOL CALLBACK CLIENT::DlgProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  static int id;
  static HBRUSH hBlueBrush;
  char Str[100];
     
  switch(message)
  {
    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDOK:
        case IDCANCEL:
          //EndDialog(hwnd, 0);
          return TRUE;

        case IDC_CONNECT:
		  GetDlgItemText(hwnd, IDC_NAME, Str, 100);
		  if(strcmp(Str, "") == 0)
		  {
		    MessageBox(hwnd, "You need to enter your name", "Error", MB_OK);
			return TRUE;
          }
          EnableWindow(GetDlgItem(hwnd, IDC_CONNECT), FALSE);
		  SetDlgItemText(hwnd, IDC_CONNECT, "Connected");
          _beginthread(Thread, 0, NULL);
          return TRUE;
      }
      break;
    
    case WM_INITDIALOG:
      hBlueBrush = CreateSolidBrush(RGB(0, 0, 255));
      util.CreateChildWindows(hwnd);
      util.InitWindowPosition(hwnd);
      util.SizeMainWindow(hwnd);
      client.Initialize(hwnd);
      client.OldClientWndProc = (WNDPROC)SetWindowLong(GetDlgItem(hwnd, IDC_CHAT),
                                 GWL_WNDPROC, (LONG)EditSubClassProc);
      return TRUE;

    case WM_CTLCOLOREDIT:
      id = GetWindowLong((HWND)lParam, GWL_ID);

      if(id == IDC_NAME || IDC_CHAT)
      {
        SetTextColor((HDC)wParam, RGB(255, 255, 255));
        SetBkColor((HDC)wParam, RGB(0, 0, 255));
        return (LRESULT)hBlueBrush;
      }
      break;
  }
  return FALSE;
}

// Subclass to detect WM_CHAR in Edit Control
LRESULT CALLBACK CLIENT::EditSubClassProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  switch(message)
  {
    case WM_CHAR:
      if(wParam == VK_RETURN)
	  {
	    client.EditTextReady = 1;  
      }
      break;
  }
  return CallWindowProc(client.OldClientWndProc, hwnd, message, wParam, lParam);
}

void CLIENT::Initialize(HWND hwnd)
{
  util.ChangeFont(hwnd, IDC_CHAT);
  util.ChangeFont(hwnd, IDC_CONNECT);
  util.ChangeFont(hwnd, IDC_DESIGNATOR_NAME);
  util.ChangeFont(hwnd, IDC_NAME);
}

void CLIENT::Chat(HWND hwnd)
{
  WSADATA wsd;
  struct sockaddr_in server;
  char Str[1024], Name[100], szBuffer[1024];
  
  GetDlgItemText(client.hMainDlg, IDC_NAME, Name, 100);
  
  if(WSAStartup(MAKEWORD(2, 2), &wsd) != 0)
  {
    MessageBox(hwnd, "Failed to load Winsock library!", "Error", MB_OK);
    return;
  }

  sock = socket(AF_INET, SOCK_STREAM, 0); //sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  if(sock == INVALID_SOCKET)
  {
    sprintf(Str, "socket() failed: %d\n", WSAGetLastError());
    MessageBox(hwnd, Str, "Error", MB_OK);
    return;
  }
  
  server.sin_family = AF_INET;
  server.sin_addr.s_addr = inet_addr(setup.IP_Address);
  server.sin_port = htons(atoi(setup.Port));
  if(connect(sock, (struct sockaddr *)&server, sizeof(server)) == SOCKET_ERROR)
  {
    sprintf(Str, "connect() failed: %d\n", WSAGetLastError());
    MessageBox(hwnd, Str, "Error", MB_OK);
    SendMessage(client.hMainWnd, WM_COMMAND, ID_EXIT, 0);
    return;
  }

  strcpy(szBuffer, "");
  while(strcmp(szBuffer, "QUIT") != 0)
  {
    if(client.EditTextReady == 1)
    {  
	  GetDlgItemText(client.hMainDlg, IDC_CHAT, szBuffer, 1024);
	  SetDlgItemText(client.hMainDlg, IDC_CHAT, "");
	  client.EditTextReady = 0;
   	}
	else
	{
	  continue;
    }

    if(strcmp(szBuffer, "QUIT\r\n") != 0)
    {
      strcpy(Str, szBuffer);
	  sprintf(szBuffer, "%s(%d)", Name, ntohs(server.sin_port));
	  strcat(szBuffer, Str);
    } 

    int nLength = strlen(szBuffer);
    int nCntSend = 0;
    char *pBuffer = szBuffer;
    while((nCntSend = send(sock, pBuffer, nLength, 0) != nLength))
    {
      if(nCntSend == -1)
      {
        MessageBox(hwnd, "Error sending the data to server", "Error", MB_OK);
        break;
      }
      if(nCntSend == nLength)
      break;

      pBuffer += nCntSend;
      nLength -= nCntSend;
    }

    if(strcmp(szBuffer, "QUIT\r\n") == 0)
    {
      SendMessage(hwnd, WM_CLOSE, 0, 0);
      break;
    }

    nLength = recv(sock, szBuffer, sizeof(szBuffer), 0);
    if(nLength > 0)
    {
      szBuffer[nLength] = '\0';
      sprintf(Str, "%s OK\r\n", szBuffer);
	  SetDlgItemText(hwnd, IDC_CHAT, Str);
	  
      SendMessageA(GetDlgItem(hwnd, IDC_CHAT), EM_SETSEL, 0, -1);     // Select all. 
      SendMessageA(GetDlgItem(hwnd, IDC_CHAT), EM_SETSEL, -1, -1);    // Unselect and stay at the end pos
      SendMessageA(GetDlgItem(hwnd, IDC_CHAT), EM_SCROLLCARET, 0, 0); // Set scrollcaret to the current Pos
	  Sleep(1000);
	  SetDlgItemText(hwnd, IDC_CHAT, "");
    }
  }
  closesocket(sock);
  WSACleanup();
}

