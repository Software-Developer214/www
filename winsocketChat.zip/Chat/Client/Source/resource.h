//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Client.rc
//
#define IDD_MAINDIALOG                  101
#define IDM_ABOUT                       102
#define ID_ABOUT                        103
#define IDD_SETUP                       104
#define IDD_ABOUTDLG                    105
#define IDR_MENU1                       106
#define IDC_CHAT                        107
#define IDC_IP_ADDR                     108
#define IDC_DESIGNATOR_IP_ADDRESS       109
#define IDC_PORT                        110
#define IDC_DESIGNATOR_PORT             111
#define IDC_NAME                        112
#define IDC_DESIGNATOR_NAME             113
#define IDC_CONNECT                     114
#define ID_EXIT                         115
#define ID_SETUP                        116
#define IDM_SETUP                       117
#define IDM_URGENT                      118

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        200
#define _APS_NEXT_COMMAND_VALUE         300
#define _APS_NEXT_CONTROL_VALUE         400
#define _APS_NEXT_SYMED_VALUE           500
#endif
#endif
