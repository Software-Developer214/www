// Filename: main.cpp
// July 7, 2020
// Author: John M. Klein

#include "resource.h"
#include "Client.h"

HINSTANCE hInst;
HWND hwndChild[NUM_CONTROLS];

// Class Instantiations
CLIENT    client;
UTILITIES util;
SETUP     setup;

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                     PSTR szCmdLine, int iCmdShow)
{
  static char szAppName[] = "Client";
  MSG  msg;
  WNDCLASSEX wndclassex;
     
  wndclassex.cbSize        = sizeof(wndclassex);
  wndclassex.style         = CS_HREDRAW | CS_VREDRAW;
  wndclassex.lpfnWndProc   = WndProc;
  wndclassex.cbClsExtra    = 0;
  wndclassex.cbWndExtra    = 0; // DLGWINDOWEXTRA;
  wndclassex.hInstance     = hInstance;
  wndclassex.hIcon         = LoadIcon(hInstance, "Icon"); //LoadIcon(hThisInst, MAKEINTRESOURCE(IDI_SERVER));
  wndclassex.hCursor       = LoadCursor(NULL, IDC_ARROW);
  wndclassex.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1); //(HBRUSH)GetStockObject(LTGRAY_BRUSH);
  wndclassex.lpszMenuName  = MAKEINTRESOURCE(IDR_MENU1);
  wndclassex.lpszClassName = szAppName; // Must agree with Dialog CLASS name
  wndclassex.hIconSm       = LoadIcon(hInstance, "Icon");
     
  if(!RegisterClassEx(&wndclassex))
  {
    return 0;
  }

  hInst = hInstance;
  
  client.hMainWnd = CreateWindow("Client", "Client Chat",
                                WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, 0, 0, 0, NULL, NULL, hInstance, NULL);
  ShowWindow(client.hMainWnd, iCmdShow);
  
  CreateDialog(hInstance, MAKEINTRESOURCE(IDD_SETUP), client.hMainWnd, (DLGPROC)SetupDlgProc);
  
  client.hMainDlg = CreateDialog(hInstance, MAKEINTRESOURCE(IDD_MAINDIALOG), client.hMainWnd, (DLGPROC)client.DlgProc);
  ShowWindow(client.hMainDlg, SW_SHOW);

  while(GetMessage(&msg, NULL, 0, 0))
  {
    if(client.hMainDlg == 0 || !IsDialogMessage(client.hMainDlg, &msg))
    {
      //if(!TranslateAccelerator(hMainWnd, hAccel, &msg))
      //{
      TranslateMessage(&msg);
      DispatchMessage(&msg);
      //}
    }
  }
  return msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  switch(message)
  {
    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDM_ABOUT:
          DialogBox((HINSTANCE)GetWindowLong(hwnd, GWL_HINSTANCE), MAKEINTRESOURCE(IDD_ABOUTDLG), hwnd, AboutDlgProc);
          return 0;

        case IDM_SETUP:
          DialogBox((HINSTANCE)GetWindowLong(hwnd, GWL_HINSTANCE), MAKEINTRESOURCE(IDD_SETUP), hwnd, SetupDlgProc);
		  return 0;

        case IDM_URGENT:
	      send(client.sock, "URGENT\r\n", 9, 0);
		  return 0;

        case ID_EXIT:
          PostMessage(hwnd, WM_CLOSE, NULL, NULL);
		  return 0;
      }
      
    case WM_SETFOCUS:
      SetFocus(client.hMainDlg);
      return 0;
      
    case WM_CREATE:
      //SetWindowPos(hwnd, HWND_TOPMOST, -1, -1, -1, -1, SWP_NOMOVE | SWP_NOSIZE);
      return 0;  

    case WM_CLOSE:
	  send(client.sock, "QUIT\r\n", 7, 0);
      WSACleanup();
      DestroyWindow(hwnd);	  
	  return 0;

    case WM_DESTROY:
      util.ChangeFont(hwnd, 0);
      PostQuitMessage(0);
      return 0;

    case WM_SIZE:
      util.RepositionControls(hwnd, lParam);
      return 0;  
   
    case WM_NOTIFY:
      return 0;
      
    case WM_SYSCOMMAND:
      if(wParam == ID_ABOUT)
      {
        MessageBox(hwnd, "Chat Client Program\nCopyright (C) 2020\n", "About",
                          MB_OK | MB_ICONINFORMATION);
        return 0;                   
      }
  }
  return DefWindowProc(hwnd, message, wParam, lParam);
}





