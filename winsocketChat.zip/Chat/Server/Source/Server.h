// Filename: Server.h

#ifndef SERVER_H
#define SERVER_H

#include "resource.h"
#include <windows.h>
#include <stdio.h>
#include <process.h>

// Child Windows Support
#define NUM_CONTROLS      3
#define DLG_CHAT          0

struct CLIENT_INFO
{
  SOCKET hClientSocket;
  struct sockaddr_in clientAddr;
};

VOID Thread(PVOID pvoid);
BOOL WINAPI ClientThread(LPVOID lpData);
LRESULT CALLBACK WndProc (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK AboutDlgProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK SetupDlgProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

class SERVER // Server.cpp
{
  void Initialize(HWND hwnd);
  void InitServer(HWND hwnd);
  
  public:
  SERVER()
  {
    hMainDlg  = 0;
    hMainWnd  = 0;
    UrgentAlert = 0;
	ToggleColor = 0;
  }
  void Chat(HWND hwnd);
  int UrgentAlert;
  int ToggleColor;

  HWND hMainDlg;  
  HWND hMainWnd;

  static BOOL CALLBACK DlgProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
};

class SETUP // Setup.cpp
{
  public:
  SETUP()
  {
    strcpy(IP_Address, "192.168.1.18");
    strcpy(Port, "5151");
  }
  char IP_Address[100];
  char Port[100];
};

class UTILITIES  // Utilities.cpp
{
  
  public:

  void ChangeFont(HWND hwnd, int id);
  void SizeMainWindow(HWND hwnd);
  void RepositionControls(HWND hwnd, LPARAM lParam);
  void CreateChildWindows(HWND hwnd);
  void InitWindowPosition(HWND hwnd);
};

extern SERVER    server;
extern SETUP     setup;
extern UTILITIES util;
extern HINSTANCE hInst;
extern HWND      hwndChild[NUM_CONTROLS];

#endif
