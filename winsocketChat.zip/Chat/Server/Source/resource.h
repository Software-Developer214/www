//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Server.rc
//
#define IDD_MAINDIALOG                  101
#define IDD_ABOUTDLG                    102
#define IDT_TIMER                       103
#define IDD_SETUP                       104
#define IDR_MENU1                       105
#define ID_EXIT                         106
#define IDM_SETUP                       107
#define IDM_CLEAR                       108
#define IDM_STARTSERVER                 109
#define IDM_URGENT_STOP                 110
#define IDM_ABOUT                       111
#define ID_ABOUT                        112
#define IDC_CHAT                        113
#define IDC_IP_ADDR                     114
#define IDC_DESIGNATOR_IP_ADDRESS       115
#define IDC_PORT                        116
#define IDC_DESIGNATOR_PORT             117

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        200
#define _APS_NEXT_COMMAND_VALUE         300
#define _APS_NEXT_CONTROL_VALUE         400
#define _APS_NEXT_SYMED_VALUE           500
#endif
#endif
