// Filename: Setup.cpp

#include "resource.h"
#include "Server.h"

BOOL CALLBACK SetupDlgProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  static int id;
  static HBRUSH hBlueBrush;
     
  switch(message)
  {
    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDOK:
        case IDCANCEL:
          GetDlgItemText(hwnd, IDC_IP_ADDR, setup.IP_Address, 100);
          GetDlgItemText(hwnd, IDC_PORT, setup.Port, 100);
          EndDialog(hwnd, 0);
          return TRUE;
      }
      break;
    
    case WM_INITDIALOG:
      hBlueBrush = CreateSolidBrush(RGB(0, 0, 255));
      
      util.ChangeFont(hwnd, IDC_IP_ADDR);
      util.ChangeFont(hwnd, IDC_DESIGNATOR_IP_ADDRESS);
      util.ChangeFont(hwnd, IDC_PORT);
      util.ChangeFont(hwnd, IDC_DESIGNATOR_PORT);

      SetDlgItemText(hwnd, IDC_IP_ADDR, setup.IP_Address); 
      SetDlgItemText(hwnd, IDC_PORT, setup.Port);
      return TRUE;

    case WM_CTLCOLOREDIT:
      id = GetWindowLong((HWND)lParam, GWL_ID);

      if(id == IDC_IP_ADDR || id == IDC_PORT)
      {
        SetTextColor((HDC)wParam, RGB(255, 255, 255));
        SetBkColor((HDC)wParam, RGB(0, 0, 255));
       return (LRESULT)hBlueBrush;
      }
      break;
  }
  return FALSE;
}
