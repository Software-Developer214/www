// Filename: Server.cpp

#include "resource.h"
#include "Server.h"

VOID Thread(PVOID pvoid)
{
  while(TRUE)
  {
    server.Chat(server.hMainDlg);
  }
}

// Dialog Proc
BOOL CALLBACK SERVER::DlgProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  static int id;
  static HBRUSH hBlueBrush, hRedBrush;
     
  switch(message)
  {
    case WM_COMMAND:
      switch(LOWORD(wParam))
      {
        case IDOK:
        case IDCANCEL:
          //EndDialog(hwnd, 0);
          return TRUE;
      }
      break;

    case WM_TIMER:
      if(server.UrgentAlert)
	  {
        server.ToggleColor ? server.ToggleColor = 0 : server.ToggleColor = 1;
	    InvalidateRect(hwnd, NULL, TRUE);
	  }
      return TRUE;
 
    case WM_CLOSE:
      DeleteObject(hBlueBrush);
      DestroyWindow(hwnd);
      server.hMainDlg = NULL;
      PostMessage(GetParent(hwnd), WM_CLOSE, NULL, NULL);
      return TRUE;
    
    case WM_INITDIALOG:
      hBlueBrush = CreateSolidBrush(RGB(0, 0, 255));
      hRedBrush = CreateSolidBrush(RGB(255, 0, 0));
      server.Initialize(hwnd);
      util.CreateChildWindows(hwnd);
      util.InitWindowPosition(hwnd);
      util.SizeMainWindow(hwnd);
      SetTimer(hwnd, IDT_TIMER, 500, (TIMERPROC)NULL);
      return TRUE;

    case WM_CTLCOLOREDIT:
      id = GetWindowLong((HWND)lParam, GWL_ID);

      if(id == IDC_CHAT)
      {
        SetTextColor((HDC)wParam, RGB(255, 255, 255));
        if(server.ToggleColor)
        {
          SetBkColor((HDC)wParam, RGB(255, 0, 0));
          return (LRESULT)hRedBrush;
        }
        else
        {
          SetBkColor((HDC)wParam, RGB(0, 0, 255));
          return (LRESULT)hBlueBrush;
        }
      }
      break;
  }
  return FALSE;
}

void SERVER::Initialize(HWND hwnd)
{
  util.ChangeFont(hwnd, IDC_CHAT);
  util.ChangeFont(hwnd, IDC_IP_ADDR);
  util.ChangeFont(hwnd, IDC_PORT);
  util.ChangeFont(hwnd, IDC_DESIGNATOR_IP_ADDRESS);
  util.ChangeFont(hwnd, IDC_DESIGNATOR_PORT);
}

void SERVER::Chat(HWND hwnd)
{
  WSADATA wsd ;
  char Str[1024], EditContents[1024];

  if(WSAStartup(MAKEWORD(2, 2), &wsd) != 0)
  {
    MessageBox(hwnd, "Failed to load Winsock library!", "Error", MB_OK);
    return;
  }

  SOCKET hServerSocket;
  hServerSocket = socket(AF_INET, SOCK_STREAM, 0); //sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  if(hServerSocket == INVALID_SOCKET)
  {
    MessageBox(hwnd, "Unable to create Server socket", "Error", MB_OK);
    WSACleanup();
    return;
  }

  struct sockaddr_in serverAddr;
  serverAddr.sin_family = AF_INET;
  serverAddr.sin_addr.s_addr = inet_addr(setup.IP_Address);
  serverAddr.sin_port = htons(atoi(setup.Port));
  if(bind(hServerSocket, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR)
  {
    sprintf(Str, "Unable to bind to IP Address or Port");
    MessageBox(hwnd, Str, "Error", MB_OK);
    closesocket(hServerSocket);
    WSACleanup();
    SendMessage(server.hMainWnd, WM_COMMAND, ID_EXIT, 0);
    return;
  }

  if(listen(hServerSocket, SOMAXCONN) == SOCKET_ERROR)
  {
    MessageBox(hwnd, "Unable to put server in listen state", "Error", MB_OK);
    closesocket(hServerSocket);
    WSACleanup();
    return;
  }
	
  
  struct CLIENT_INFO clientInfo[100];

  int nClients = 0;
	
  for(;;)
  {
    SOCKET hClientSocket;
    struct sockaddr_in clientAddr;
    int nSize = sizeof(clientAddr);
    hClientSocket = accept(hServerSocket, (struct sockaddr *)&clientAddr, &nSize);
    if(hClientSocket == INVALID_SOCKET)
    {
      MessageBox(hwnd, "accept() failed\r\n", "Error", MB_OK);
    }
    else
    {
	  

      HANDLE hClientThread[100];
      
      DWORD dwThreadId[100];

      clientInfo[nClients].hClientSocket = hClientSocket;
      clientInfo[nClients].clientAddr = clientAddr;

	  //sprintf(Str, "Socket = %d", hClientSocket);
	  //MessageBox(server.hMainDlg, Str, "Debug", MB_OK);

      GetDlgItemText(hwnd, IDC_CHAT, EditContents, 1024);
      sprintf(Str, "Client connected from %s:%d\r\n", inet_ntoa(clientAddr.sin_addr), ntohs(clientAddr.sin_port));
      strcat(EditContents, Str);
      SetDlgItemText(hwnd, IDC_CHAT, EditContents);

      hClientThread[nClients] = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ClientThread, (LPVOID)&clientInfo[nClients], 0, &dwThreadId[nClients]);
	  nClients +=1;
	  
	  Beep(500, 1000);

	  if(hClientThread == NULL)
      {
        MessageBox(hwnd, "Unable to create client thread", "Error", MB_OK);
        CloseHandle(hClientThread);
      }
    }
  }
  closesocket(hServerSocket);
  WSACleanup();
}

BOOL WINAPI ClientThread(LPVOID lpData)
{
  CLIENT_INFO *pClientInfo = (CLIENT_INFO*)lpData;
  char szBuffer[1024], Str[1024], EditContents[1024];
  int nLength ;

  //sprintf(Str, "Socket = %d", pClientInfo->hClientSocket);
  //MessageBox(server.hMainDlg, Str, "Debug", MB_OK);

  for(;;)
  {
    nLength = recv(pClientInfo->hClientSocket, szBuffer, sizeof(szBuffer), 0);
    if(nLength > 0)
    {
      szBuffer[nLength] = '\0';
      *strrchr(szBuffer, '\r') = '\0'; // strip \r\n
      GetDlgItemText(server.hMainDlg, IDC_CHAT, EditContents, 1024);
      sprintf(Str, "%s(%d)\r\n", szBuffer, ntohs(pClientInfo->clientAddr.sin_port));
      strcat(EditContents, Str);
      SetDlgItemText(server.hMainDlg, IDC_CHAT, EditContents);

      SendMessageA(GetDlgItem(server.hMainDlg, IDC_CHAT), EM_SETSEL, 0, -1);     // Select all. 
      SendMessageA(GetDlgItem(server.hMainDlg, IDC_CHAT), EM_SETSEL, -1, -1);    // Unselect and stay at the end pos
      SendMessageA(GetDlgItem(server.hMainDlg, IDC_CHAT), EM_SCROLLCARET, 0, 0); // Set scrollcaret to the current Pos

      if(strcmp(szBuffer, "QUIT") == 0)
      {
        closesocket(pClientInfo->hClientSocket);
        return TRUE ;
      }

      if(strcmp(szBuffer, "URGENT") == 0)
      {
        server.UrgentAlert = 1;
        ShowWindow(server.hMainWnd, SW_RESTORE);
        InvalidateRect(server.hMainWnd, NULL, TRUE);
      }

      int nCntSend = 0;
      char *pBuffer = szBuffer;

      while((nCntSend = send(pClientInfo->hClientSocket, pBuffer, nLength, 0) != nLength))
      {
        if(nCntSend == -1)
        {
          sprintf(Str, "Error sending the data to %s\r\n", inet_ntoa(pClientInfo->clientAddr.sin_addr));
          MessageBox(0, Str, "Error", MB_OK);
          break;
        }
        if(nCntSend == nLength)
        {
          break;
        }

        pBuffer += nCntSend;
        nLength -= nCntSend;
      }
    }
    else
    {
      Beep(500, 100);
      sprintf(Str, "Error Reading Data %s", WSAGetLastError());
      MessageBox(server.hMainDlg, Str, "Error", MB_OK);

      //printf(Str, "Error reading the data from %s\r\n", inet_ntoa(pClientInfo->clientAddr.sin_addr));
      //MessageBox(0, Str, "Error", MB_OK);
    }
  }
  return TRUE;
}


