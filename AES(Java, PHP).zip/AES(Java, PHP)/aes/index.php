<!DOCTYPE html>
<html lang="en">
<head>
  <title>Encrypt</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<div class="jumbotron text-center">
  <h1>AES Encryption</h1>
</div>
<div class="container">
  <div class="row">
    <div class="col-sm-0 ">
    </div>
    <div class="col-sm-12">
      <input type="text" class="form-control" id="enTxt" name="enTxt" placeholder="Input the text to encrypt">
      <br>
      <button style="margin-left:37%;" type="button" id="encBtn" name="encBtn" class="btn btn-primary">Encrypt</button>    
      <br><br>
      
    </div>
  </div>

</div>
<p style="margin-left: 30px;" id="enRTxt" name="enRTxt"></p>    
<script>
  $(document).ready(function(){
    $("#encBtn").click(function(){
      var encTxt = $("#enTxt").val();
      $.post("aes.php",
      {
        txt: encTxt
      },
      function(data,status){
        $("#enRTxt").html(data);
      //  alert("Data: " + data + "\nStatus: " + status);
      });
    });
});
</script>
</body>
</html>
