<?php
// sooper-secret message
$original = $_POST['txt'];
// ultra-seekrit key
$key = '3BB1060264E351B3';
// hard-coded initialization vector to prove we really know our stuff
//$iv = unpack('C*', $key);

$iv = mb_convert_encoding($key, "UTF-8");

//$original = "{\"end_date\":\"12/31/2019\",\"account\":\"2CT00009\",\"document_type\":\"Confirms\",\"start_date\":\"01/01/2019\"}";

// encrypt using openssl
$ocrypted = openssl_encrypt($original, 'AES-128-CBC', $key, OPENSSL_RAW_DATA, $iv);

//echo $original.PHP_EOL;
echo "Encrypted:  ";
echo base64_encode($ocrypted)."\n";

$encstr = base64_encode($ocrypted);
// decrypt using openssl
$o_from_m_decrypt = openssl_decrypt($encstr, 'AES-128-CBC', $key, 0, $iv);

echo "Decrypted: ".$o_from_m_decrypt;
