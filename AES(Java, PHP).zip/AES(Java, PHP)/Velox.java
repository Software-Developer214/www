/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * 
 */
package velox;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import sun.misc.BASE64Encoder;

import org.json.simple.JSONObject;
import sun.misc.BASE64Decoder;
import sun.net.www.http.HttpClient;

public class Velox {

    public static String encrypteAES(String sSrc, String encrypt_key) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        byte[] raw = encrypt_key.getBytes();
        SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
        IvParameterSpec iv = new IvParameterSpec(encrypt_key.getBytes());
       

        cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);
        byte[] encrypted = cipher.doFinal(sSrc.getBytes("utf-8"));
        return new BASE64Encoder().encode(encrypted);
    }

    public static String decryptAES(String sSrc, String encrypt_key)
            throws Exception {
        try {
            byte[] raw = encrypt_key.getBytes();

            SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            IvParameterSpec iv = new IvParameterSpec(encrypt_key.getBytes());
            cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
            byte[] encrypted1 = new BASE64Decoder().decodeBuffer(sSrc);
            byte[] original = cipher.doFinal(encrypted1);
            String originalString = new String(original, "utf-8");
            return originalString;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    

    public static void main(String args[]) throws IOException, Exception {

        JSONObject obj = new JSONObject();

        obj.put("end_date", "12/31/2019");
        obj.put("account", "2CT00009");
        obj.put("document_type", "Confirms");
        obj.put("start_date", "01/01/2019");

        System.out.println("Unencrypted :" + obj.toString().replace("\\", ""));

        String key = "3BB1060264E351B3";
        String enc = "";
        try {
            enc = encrypteAES(obj.toString().replace("\\", ""), key);
        } catch (Exception ex) {
            Logger.getLogger(Velox.class.getName()).log(Level.SEVERE, null, ex);
        }

        System.out.println("Encrypted string: " + enc);
        System.out.println("Decrypted string: " + decryptAES(enc,key));
       // doPost(enc);

    }

}
