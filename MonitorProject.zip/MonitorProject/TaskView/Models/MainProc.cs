﻿using System;
using System.IO;
using System.Timers;
using System.Threading;
using System.Collections.Generic;
using Monitor.TaskView.Globals;
using Monitor.TaskView.Models;
using Monitor.TaskView.Utils;
using System.Diagnostics;
using System.Text;
using Microsoft.Win32;

namespace Monitor.TaskView.Models
{
    public class MainProc
    {
        private static System.Timers.Timer CheckTimer { get; set; }
        public ScreenCaptures ScrCapture { get; set; }
        public ProcessInfos PrcInfo { get; set; }
        public URLProc UrlInfo { get; set; }
        public DownloadProc DownProc { get; set; }
        public AudioProc AudioInfo { get; set; }

        public static Thread MainWorkThread;
        public static Thread VidCaptureThread;
        public static Thread UrlThread;
        public static Thread AudioThread;

        private static MainProc _instance;
        public static MainProc Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new MainProc();
                }

                return _instance;
            }
        }
        private MainProc()
        {
         //   AllProcessStart();
        }
        static MainProc()
        {
            //CheckTimer = new System.Timers.Timer(60 * 1000);
            //CheckTimer.Elapsed += OnSaveTimerElapsed;
            //CheckTimer.Start();
        }
        private static void OnSaveTimerElapsed(object sender, ElapsedEventArgs elapsedEventArgs)
        {
        //    string today = DateTime.Now.Year.ToString() + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Day.ToString();
        //    string todayDir = Path.Combine(Settings.Instance.Directories.WorkDirectory, today);
        /////    DateTime.Now.
        //    try
        //    {
        //        if (!Directory.Exists(todayDir))
        //        {
        //            List<string> dirs = new List<string>(Directory.EnumerateDirectories( Settings.Instance.Directories.WorkDirectory ));
        //            foreach (var dir in dirs)
        //            {
        //                string[] TempDate = dir.Substring(dir.LastIndexOf(Path.DirectorySeparatorChar) + 1).Split('-');
        //                DateTime lastDay = new DateTime(int.Parse(TempDate[0]), int.Parse(TempDate[1]), int.Parse(TempDate[2]));
        //                double daysDiff = DateTime.Today.Subtract(lastDay).TotalDays;
        //                if (daysDiff > Constants.DelDataDay)
        //                {                            
        //                   Directory.Delete(dir, true);
        //                   Thread.Sleep(150);
        //                }
        //            }

        //            MainWorkThread.Suspend();
        //            // Process list clear
        //            Settings.Instance.ProcessList.Clear();
        //            if (Windows.MainWindow != null)
        //            {
        //                Windows.MainWindow.NewDayClearList();
        //            }
        //            MainWorkThread.Resume();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        CustomEx.DoExecption(Constants.exResume, ex);
        //    }      

        }

        public void CaptureStart()
        {
            VidCaptureThread = new Thread(new ThreadStart(DoCapture));
            VidCaptureThread.Start();
        }

        public void DoCapture()
        {
            while (true)
            {
                //byte[] dataSlide = ScrCapture.GetVideoStream();
                ScrCapture.GetStream("video");
                Thread.Sleep(500);
            }
            
        }

        public void CaptureStop()
        {
            VidCaptureThread.Abort();
        }

        public void DoUrl()
        {
            int nCount = 0;
            Thread.Sleep(300);
            while (true)
            {
                try
                {
                    nCount += Constants.urlSessionTime;

                    if (nCount % Constants.urlSessionTime == 0)  // 3 seconds
                    {
                        UrlInfo.URLProcFunc();
                    }

                }
                catch (Exception ex)
                {
                    CustomEx.DoExecption(Constants.exResume, ex);
                }
                if (nCount == 10000) nCount = 0;
                Thread.Sleep(Constants.urlSessionTime * 1000);
            }
        }

        public void DoAudio()
        {
            
            while (true)
            {
                AudioInfo.CheckAudioLevels();
                Thread.Sleep(1000);
            }
        }

        public void AllProcessStart()
        {
            RegistryKey key = Registry.CurrentUser.OpenSubKey("Software", true);
            var rk = key.OpenSubKey("RMClient");
            if (rk == null)
            {
                key = key.CreateSubKey("RMClient");
                key.SetValue("Version", "1.0");
            }
            else
            {
                Settings.current_version = rk.GetValue("Version").ToString();
            }
            ScrCapture = new ScreenCaptures();
            PrcInfo = new ProcessInfos();
            UrlInfo = new URLProc();
            DownProc = new DownloadProc();
            AudioInfo = new AudioProc();

            PrcInfo.GetProcessInfo();
            //if (Windows.MainWindow != null)
            //    Windows.MainWindow.Init();
            
            MainWorkThread = new Thread(new ThreadStart(DoWork));
            MainWorkThread.Start();

            UrlThread = new Thread(new ThreadStart(DoUrl));
            UrlThread.Start();

            AudioThread = new Thread(new ThreadStart(DoAudio));
            AudioThread.Start();
            
        }

        public void DoWork()
        {
            int nCount = 0;
            Thread.Sleep(300);
            
            while (true)
            {
                try
                {
                    nCount += Settings.Instance.RegValue.SessionTime;
                  
                    ///// Date changing...
                    if (nCount % 1/*Settings.Instance.RegValue.SessionTime*/ == 0) // 1 minute
                    {
                        ChangeNewDay();
                    }

                    //// Slide Image 
                    if (nCount % Constants.slideTime == 0)
                    {                       
                        ScrCapture.SaveImage("slide");
                        ScrCapture.GetStream("slide");
                    }
                    
                    ///// Capture Image 
                    if (nCount % Settings.Instance.RegValue.CaptureTime == 0)   //CaptureTime
                    {                       
                        ScrCapture.GetStream("capture");
                        
                    }

                    /////  process processing              
                    if (nCount % Settings.Instance.RegValue.SessionTime == 0)  // 1 minuts
                    {
                        byte[] dataProcess = PrcInfo.GetProcessInfo();
                        CommProc.Instance.SendDataAnalysis(Constants.Re_DataProcess, dataProcess, dataProcess.Length);
                    }

                    ///// Download File
                    if (nCount % Constants.SessionTime == 0)   // 10 seconds
                    {
                        DownProc.FindDownloadfile();
                    }

                    GC.Collect();
                    
                }
                catch (Exception ex)
                {
                    CustomEx.DoExecption(Constants.exResume, ex);
                }              
                               
                ///////////////////////  time repair and count 
                if (nCount == 10000) nCount = 0;
                Thread.Sleep(Settings.Instance.RegValue.SessionTime * 1000);
            }
        }

        public void ChangeNewDay()
        {
            string today = DateTime.Now.Year.ToString() + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Day.ToString();
            string todayDir = Path.Combine(Settings.Instance.Directories.WorkDirectory, today);
            string strSlidePath = Path.Combine(todayDir, "Slide");
            string strCapturePath = Path.Combine(todayDir, "Capture");

            if (!Directory.Exists(strSlidePath) || !Directory.Exists(strCapturePath)/*DateTime.Now.ToString("HH:mm") == "00:00" || DateTime.Now.ToShortTimeString() == "12:00 AM"*/)
            {
                    
                try
                {
                    List<string> dirs = new List<string>(Directory.EnumerateDirectories(Settings.Instance.Directories.WorkDirectory));
                    foreach (var dir in dirs)
                    {
                        string[] TempDate = dir.Substring(dir.LastIndexOf(Path.DirectorySeparatorChar) + 1).Split('-');
                        DateTime lastDay = new DateTime(int.Parse(TempDate[0]), int.Parse(TempDate[1]), int.Parse(TempDate[2]));
                        double daysDiff = DateTime.Today.Subtract(lastDay).TotalDays;
                        if (daysDiff > Constants.DelDataDay)
                        {
                            Directory.Delete(dir, true);
                            Thread.Sleep(150);
                        }
                    }
                    byte[] endData = Encoding.UTF8.GetBytes(Constants.Re_End);
                    Settings.Instance.SockCom.Send(endData);
                    EnvironmentHelper.Restart();
                }
                catch (Exception ex)
                {
                    CustomEx.DoExecption(Constants.exResume, ex);
                    EnvironmentHelper.Restart();
                }
                    
            }

        }
        public void AllProcessStop()
        {
            MainWorkThread.Abort();
        }
    }
}
