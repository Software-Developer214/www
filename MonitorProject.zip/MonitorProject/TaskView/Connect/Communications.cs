﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;
using Monitor.TaskView.Globals;
using Monitor.TaskView.Models;
using Monitor.TaskView.myEvents;
using Monitor.TaskView.Logger;
using System.IO;
using System.Diagnostics;
using Monitor.TaskView.Utils;

namespace Monitor.TaskView.Connect
{
    public class Communications
    {
        private static int bytePerSize = 1024;
        private static byte[] byteData = new byte[bytePerSize];
        private static bool flag = false;

        public Communications()
        {
            //StartUpSocket();
        }
        public static void StartUpSocket()
        {
            flag = false;

            Settings.Instance.bSend = false;
            string strIPAddress = "";
            if (Settings.Instance.RegValue.ServerIP == "")
            {
                strIPAddress = "127.0.0.1";
            }
            else
            {
                strIPAddress = Settings.Instance.RegValue.ServerIP;
            }
            IPAddress ipAddress = IPAddress.Parse(Settings.Instance.RegValue.ServerIP);
            IPEndPoint localEndPoint = new IPEndPoint(ipAddress, Constants.Port);
            Settings.Instance.SockCom = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                Settings.Instance.SockCom.Connect(localEndPoint);
                Settings.Instance.bConnect = true;
                
                string strComName = Environment.MachineName;
                Process p = new Process();
                // Redirect the output stream of the child process.
                p.StartInfo.UseShellExecute = false;
                p.StartInfo.CreateNoWindow = true;
                p.StartInfo.RedirectStandardOutput = true;
                p.StartInfo.FileName = "cmd";
                p.StartInfo.Arguments = "/c systeminfo | find /i \"install date\"";
                p.Start();
                string output = p.StandardOutput.ReadToEnd();
                p.WaitForExit();
                string strOSDate = output.Replace("Original Install Date:", "").Trim(); //+ Directory.GetCreationTime(@"C:\Windows").ToLongTimeString();
                string strTemp = Settings.Instance.RegValue.UserName + ";" + Settings.Instance.RegValue.Password + ";" + Settings.Instance.RegValue.Company + ";" + Settings.Instance.RegValue.SessionTime + ";" + Settings.Instance.RegValue.CaptureTime + ";" + Settings.Instance.RegValue.SlideWidth + ";" + Settings.Instance.RegValue.SlideHeight + ";" + Settings.Instance.RegValue.CaptureWidth + ";" + Settings.Instance.RegValue.CaptureHeight + ";" + strComName + ";" + strOSDate;

                string strClientInfo = Constants.Re_ClientInfo + strTemp;
                byte[] buffer = Encoding.UTF8.GetBytes(strClientInfo);
                Settings.Instance.SockCom.Send(buffer);
                
                


                Thread thread = new Thread(new ThreadStart(Receive));
                thread.Start();
            }
            catch (Exception e)
            {
                Settings.Instance.bConnect = false;
                CustomEx.DoExecption(Constants.exRepair, e);
                Thread thread = new Thread(new ThreadStart(Reconnect));
                thread.Start();
            }

        }


        public static void Reconnect()
        {
            if (Settings.Instance.bConnect == false)
            {
                Settings.Instance.SockCom.Close();
                StartUpSocket();
            }

        }
        public static void Receive()
        {
            try
            {
                byte[] buffer = new byte[1024 * 5 * 1000];
                while (!flag)
                {
                    int byteData = Settings.Instance.SockCom.Receive(buffer, SocketFlags.None);
                    if (byteData > 0)
                    {
                        CommProc.Instance.RecDataAnalysis(buffer, byteData);
                    }
                }

            }
            catch (Exception e)
            {
                CustomEx.DoExecption(Constants.exRepair, e);
                Disconnect();
            }

        }

        public static void Send(byte[] data)
        {
            try
            {
                Settings.Instance.SockCom.Send(data, SocketFlags.None);
            }
            catch (Exception e)
            {
                CustomEx.DoExecption(Constants.exRepair, e);
                Disconnect();
            }
        }

        public static void Disconnect()
        {
            try
            {
                Settings.Instance.bSend = false;
                Settings.Instance.bConnect = false;
                Settings.Instance.SockCom.Close();
                flag = true;
                StartUpSocket();
            }
            catch (Exception e)
            {
                CustomEx.DoExecption(Constants.exRepair, e);
            }

        }
    }
}
