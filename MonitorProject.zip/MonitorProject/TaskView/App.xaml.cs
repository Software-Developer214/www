﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Navigation;
using Microsoft.Win32;
using Monitor.TaskView.Globals;
using Monitor.TaskView.myEvents;

using Monitor.TaskView.Utils;

namespace Monitor.TaskView
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>  
    public partial class App : Application
    {
        private Mutex _mutex;
        private bool _createdNew;

        protected override void OnStartup(StartupEventArgs e)
        {
            //Logger.Log.Instance.DoLog("start program");
            Thread.Sleep(300);
            AppDomain.CurrentDomain.ProcessExit += OnProcessExit;
            //  Double Runnig check 
            _mutex = new Mutex(true, "Monitor.TaskView", out _createdNew);
            //
            if (!_createdNew)  // already runnig
            {
                EnvironmentHelper.ShutDown();
            }
            else
            {                  
                EnvironmentHelper.SetValidEnvironment();
                try
                {
                    RegistryKey key = Registry.CurrentUser.OpenSubKey("Software", true);
                    var rk = key.OpenSubKey(Constants.RegPath);
                    string BaseDirectory = (string)rk.GetValue("BaseDirectory");
                    if (BaseDirectory == "D:\\Work")
                    {
                        string[] fileEntries = Directory.GetFiles("D:\\Work\\", "Contents.lib", SearchOption.AllDirectories);
                        if (fileEntries.Count() > 0)
                        {
                            Directory.Move("D:\\Work", Constants.BaseDirectory);

                            key = key.CreateSubKey(Constants.RegPath);
                            key.SetValue("BaseDirectory", Constants.BaseDirectory);
                            key.Close();
                        }
                    }
                }
                catch
                {

                }
                //Logger.Log.Instance.DoLog("raise start up");
                Events.RaiseOnStartUp(e);
            }

            base.OnStartup(e);
        }

        private void OnProcessExit(object sender, EventArgs eventArgs)
        {
            if (_mutex != null && _createdNew)
            {
                try
                {
                    _mutex.ReleaseMutex();
                }
                catch (Exception)
                {
                    // ignored
                }
            }
        }
    }
}
