﻿using Monitor.TaskControl.Globals;
using Monitor.TaskControl.Utils;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Monitor.TaskControl.View
{
    /// <summary>
    /// Interaction logic for ExplorerWindow.xaml
    /// </summary>
    public partial class ExplorerWindow : Window
    {
        public ExplorerWindow()
        {
            InitializeComponent();
        }

        List<string> fileList = new List<string>();
        int nWidth, nHeight;
        int nStart, nEnd, nCount, nIndex;

        public void Window_Loaded1(string strPath, string strIP, string strUser, string strDate)
        {
            chSmall.IsChecked = true;
            this.Title = strUser + " : " + strIP + "        " + strDate;
            string[] supportedExtensions = new[] { ".psl" };
            var files = Directory.GetFiles(strPath, "*.*").Where(s => supportedExtensions.Contains(System.IO.Path.GetExtension(s).ToLower()));
            fileList.Clear();
            foreach (var file in files)
            {
                fileList.Add(file);
            }

            nWidth = Constants.smallWidth;
            nHeight = Constants.smallHeight;
            nCount = fileList.Count;
            PreviewImageDisplay(0);
            nStart = 0;
            if (nCount > 100)
            {
                nEnd = 100;
            }
            else
            {
                nEnd = nCount;
            }
            DisplayImage();
        }

        public void DisplayImage()
        {
            ImageList.Items.Clear();
            for (int i = nStart; i < nEnd; i++)
            {
                try
                {
                    string strFileName = System.IO.Path.GetFileName(fileList[i]);
                    string strRealFileName = Md5Crypto.OnGetRealName(strFileName).Replace("-", ":");
                    byte[] temp = Md5Crypto.OnReadImgFile(fileList[i]);

                    StackPanel ImgStackPanel = new StackPanel();
                    ImgStackPanel.Orientation = Orientation.Vertical;
                    Image imgTemp = new Image();
                    Label lblFileName = new Label();
                    lblFileName.Content = strRealFileName;
                    
                    lblFileName.HorizontalAlignment = HorizontalAlignment.Center;
                    lblFileName.VerticalAlignment = VerticalAlignment.Bottom;
                    lblFileName.Margin = new Thickness(0, 0, 0, 0);

                    BitmapImage imageSource = new BitmapImage();
                    imageSource.BeginInit();
                    MemoryStream ms = new MemoryStream(temp);
                    imageSource.StreamSource = ms;
                    imageSource.EndInit();
                    imgTemp.Source = imageSource;
                    imgTemp.Width = nWidth;
                    imgTemp.Height = nHeight;
                    imgTemp.Margin = new Thickness(0, nWidth *0.8 - nHeight , 0, 0);
                    ImgStackPanel.Children.Add(imgTemp);
                    ImgStackPanel.Children.Add(lblFileName);
                    ImgStackPanel.Width = nWidth ;
                    ImgStackPanel.Height = nWidth;
                    
                    ImageList.Items.Add(ImgStackPanel);
                    //ImageList.Items.Add(_grid);
                }
                catch (Exception ex)
                {

                }
            }
        }

        private void SetCount()
        {
            if (nIndex > (nEnd - nStart) / 2 + 25)
            {
                if (nEnd != nCount)
                {
                    //ImageList.Items.Clear();
                    //if (nEnd + 50 < nCount)
                    //{
                    //    nStart = nStart + 50;
                    //    nEnd = nEnd + 50;
                    //    DisplayImage();
                    //    //ListViewItem item = ImageList.ItemContainerGenerator.ContainerFromIndex(nIndex - 50) as ListViewItem;
                    //    //item.Focus();
                    //}
                    //else
                    //{
                    //    nStart = nCount - 100;
                    //    int nTemp = nCount - nEnd;
                    //    nEnd = nCount;
                    //    DisplayImage();
                    //    //ListViewItem item = ImageList.ItemContainerGenerator.ContainerFromIndex(nIndex - nTemp) as ListViewItem;
                    //    //item.Focus();
                    //}
                    ListViewItem item = ImageList.ItemContainerGenerator.ContainerFromIndex(nIndex - 50) as ListViewItem;
                    item.Focus();
                }
            }

            if (nIndex < (nEnd - nStart) / 2 - 25)
            {
                if (nStart != 0)
                {
                    //ImageList.Items.Clear();
                    //if (nStart - 50 > 0)
                    //{
                    //    nStart = nStart - 50;
                    //    nEnd = nEnd - 50;
                    //    DisplayImage();
                    //    //ListViewItem item = ImageList.ItemContainerGenerator.ContainerFromIndex(50 + nIndex) as ListViewItem;
                    //    //item.Focus();
                    //}
                    //else
                    //{
                    //    int nTemp = nStart;
                    //    nStart = 0;
                    //    nEnd = 100;
                    //    DisplayImage();
                    //    //ListViewItem item = ImageList.ItemContainerGenerator.ContainerFromIndex(nIndex + nTemp) as ListViewItem;
                    //    //item.Focus();
                    //}
                    ListViewItem item = ImageList.ItemContainerGenerator.ContainerFromIndex(50 + nIndex) as ListViewItem;
                    item.Focus();
                }
            }
        }

        private void SmallCheckBox_Click(object sender, RoutedEventArgs e)
        {
            if (chMedium.IsChecked == true)
            {
                chMedium.IsChecked = false;
            }
            if (chLarge.IsChecked == true)
            {
                chLarge.IsChecked = false;
            }
            ImageList.Items.Clear();
            nWidth = Constants.smallWidth;
            nHeight = Constants.smallHeight;
            DisplayImage();
        }

        private void MediumCheckBox_Click(object sender, RoutedEventArgs e)
        {
            if (chSmall.IsChecked == true)
            {
                chSmall.IsChecked = false;
            }
            if (chLarge.IsChecked == true)
            {
                chLarge.IsChecked = false;
            }
            ImageList.Items.Clear();
            nWidth = Constants.mediumWidth;
            nHeight = Constants.mediumHeight;
            DisplayImage();
        }

        private void LargeCheckBox_Click(object sender, RoutedEventArgs e)
        {
            if (chSmall.IsChecked == true)
            {
                chSmall.IsChecked = false;
            }
            if (chMedium.IsChecked == true)
            {
                chMedium.IsChecked = false;
            }
            ImageList.Items.Clear();
            nWidth = Constants.largeWidth;
            nHeight = Constants.largeHeight;
            DisplayImage();
        }

        private void listview_ScrollChanged(object sender, ScrollChangedEventArgs e)
        {
            Decorator border = VisualTreeHelper.GetChild(ImageList, 0) as Decorator;
            ScrollViewer scrollViewer = border.Child as ScrollViewer;
            if (scrollViewer != null)
            {
                double scrollVerticalChange = e.VerticalChange;
                double currentHeight = e.VerticalOffset;
                double scrollHeight = scrollViewer.ScrollableHeight;
                if (scrollVerticalChange > 0)
                {
                    if (currentHeight > (scrollHeight / 4) * 3)
                    {
                        if (nEnd != nCount)
                        {
                            if (nEnd + 50 > nCount)
                            {
                                nStart = nCount - 100;
                                nEnd = nCount;
                            }
                            else
                            {
                                nStart += 50;
                                nEnd += 50;
                            }
                            DisplayImage();
                            scrollViewer.ScrollToVerticalOffset(scrollHeight / 4);
                        }
                    }
                }
                else
                {
                    if (currentHeight < scrollHeight / 4)
                    {
                        if (nStart != 0)
                        {
                            if (nStart - 50 < 0)
                            {
                                nStart = 0;
                                nEnd = 100;
                            }
                            else
                            {
                                nStart -= 50;
                                nEnd -= 50;
                            }
                            DisplayImage();
                            scrollViewer.ScrollToVerticalOffset((scrollHeight / 4) * 3);
                        }
                    }
                }
            }
        }

        private void PreviewImageDisplay(int nIndex)
        {
            if (nIndex == -1)
            {
                return;
            }
            try
            {
                byte[] temp = Md5Crypto.OnReadImgFile(fileList[nIndex]);
            
                BitmapImage imageSource = new BitmapImage();
                imageSource.BeginInit();
                MemoryStream ms = new MemoryStream(temp);
                imageSource.StreamSource = ms;
                imageSource.EndInit();
                currentImage.Source = imageSource;
            }
            catch (Exception ex)
            {

            }

            if (nIndex == fileList.Count - 1)
            {
                forwardImage.Source = null;
            }
            else
            {
                try
                {
                    byte[] temp = Md5Crypto.OnReadImgFile(fileList[nIndex + 1]);
                
                    BitmapImage imageSource = new BitmapImage();
                    imageSource.BeginInit();
                    MemoryStream ms1 = new MemoryStream(temp);
                    imageSource.StreamSource = ms1;
                    imageSource.EndInit();
                    forwardImage.Source = imageSource;
                }
                catch (Exception ex)
                {

                }
            }

            if (nIndex == 0)
            {
                backImage.Source = null;
            }
            else
            {
                try
                {
                    byte[] temp = Md5Crypto.OnReadImgFile(fileList[nIndex - 1]);
                
                    BitmapImage imageSource = new BitmapImage();
                    imageSource.BeginInit();
                    MemoryStream ms1 = new MemoryStream(temp);
                    imageSource.StreamSource = ms1;
                    imageSource.EndInit();
                    backImage.Source = imageSource;
                }
                catch (Exception ex)
                {

                }
            }
        }

        private void ListView_MouseDown(object sender, MouseButtonEventArgs e)
        {
            nIndex = ImageList.SelectedIndex;
            PreviewImageDisplay(nIndex + nStart);
            SetCount();
        }

        private void ListView_MouseDoubleDown(object sender, MouseButtonEventArgs e)
        {
            nIndex = ImageList.SelectedIndex;
            this.Dispatcher.Invoke(DispatcherPriority.Normal, (ThreadStart)delegate
            {
                ImageModal window = new ImageModal();

                window.OnImageShow(fileList[nIndex + nStart]);
                window.ShowDialog();
            });
            SetCount();
        }

        private void OnKeyDownHandler(object sender, KeyEventArgs e)
        {
            //switch (e.Key)
            //{
            //    case Key.Left:
            //        ImageList.SelectedIndex = ImageList.SelectedIndex == 0 ? ImageList.Items.Count - 1 : ImageList.SelectedIndex -= 1;
            //        //ImageList.SelectedItem = ImageList.Items[ImageList.SelectedIndex];
            //        e.Handled = true;
            //        break;

            //    case Key.Right:
            //        ImageList.SelectedIndex = ImageList.SelectedIndex == ImageList.Items.Count - 1 ? 0 : ImageList.SelectedIndex += 1;
            //        //ImageList.SelectedItem = ImageList.Items[ImageList.SelectedIndex];
            //        e.Handled = true;
            //        break;

            //}


            nIndex = ImageList.SelectedIndex;
            PreviewImageDisplay(nIndex + nStart);
            SetCount();
        }

    }
}
