from selenium import webdriver
from bs4 import BeautifulSoup
from selenium.webdriver.support.ui import WebDriverWait
import time
import tkinter as tk
from tkinter import ttk 
from tkinter import * 
from tkinter.ttk import *
import os
import csv
from selenium.webdriver.common.action_chains import ActionChains
from tkinter import messagebox 

root = tk.Tk(className=' AVATAR')
root.geometry("550x400")
def get_languageId(str):
	if str=="Arabic":
	   return 27
	elif str=="English":
		return 1
	elif str=="French":
		return 4
	elif str=="German":
		return 3
	elif str=="Greek":
		return 8
	elif str=="Hindi":
		return 24
	elif str=="Italian":
		return 7
	elif str=="Polish":
		return 14
	elif str=="Russian":
		return 21
	elif str=="Spanish":
		return 2
	elif str=="Tagalog":
		return 32
	elif str=="Ukrainian":
		return 40
class My_App(tk.Frame):
	def __init__(self, parent):
		tk.Frame.__init__(self, parent)
		self.parent = parent 

		lblLanguage = Label(self.parent, font="Verdana 10 bold", text = "Language")
		lblLanguage.place(x=60, y=40)

		n = tk.StringVar() 
		self.language = ttk.Combobox(self.parent, width = 24,  
                            textvariable = n) 
		self.language['values'] = ('Arabic',  
                          'English', 
                          'French', 
                          'German', 
                          'Greek', 
                          'Hindi',  
                          'Italian',  
                          'Polish',  
                          'Russian',  
                          'Spanish',  
                          'Tagalog',
                          'Ukrainian') 
  
		self.language.place(x=150, y=40)
		self.language.current(1)  

		self.lblOther = Label(self.parent, font="Verdana 10 bold")
		self.lblOther.place(x=50, y=90)
		self.lblOther.config(text = "The text must be less than 900 characters\n Usage:\n 1.Select the language and input the text below.\n 2.then click the 'Generate Button'\n and wait until there is messagebox")

		self.txtContent = Text(self.parent, height=12, width=46)
		self.txtContent.place(x=30, y=190)

		self.btnGenerate = tk.Button(self.parent, text="Generate", command = self.OnGenerate, width=12)
		self.btnGenerate.pack()
		self.btnGenerate.place(x=430, y=250)

		# self.progress = Progressbar(self.parent, orient = HORIZONTAL, 
  #           length = 490, mode = 'indeterminate') 
		# self.progress.place(x=30, y=350)


	def OnGenerate(self):
		
		time.sleep(1)
		langText=self.language.get()
		langId=get_languageId(langText)
		print("=============================")
		print(langId)
		print("=======================")
		

		nTime = 5
		
		driver = webdriver.Chrome()
		driver.set_window_position(-2000, -2000)
		driver.get('https://vhss.oddcast.com/admin/index.php')


		time.sleep(5)
		driver.find_element_by_xpath('//input[@type="text"]').send_keys("michaelwadefx1@gmail.com")
		time.sleep(1)
		driver.find_element_by_xpath('//input[@type="password"]').send_keys("walkbyfaith")
		time.sleep(1)
		driver.find_element_by_xpath('//input[@type="submit"]').click()
		time.sleep(15)
		driver.find_element_by_xpath('//form[@name="adminclients"]/table/tbody/tr[2]/td[2]/p/a').click()
		time.sleep(15)
		driver.find_element_by_xpath('//div[@id="row2704914"]/div[3]').click()
		time.sleep(30)
		parentGUID = driver.current_window_handle;
		iframe = driver.find_elements_by_tag_name('iframe')[5]
		driver.switch_to.frame(iframe)

		driver.implicitly_wait(30)

		driver.find_element_by_xpath('//div[@id="se-editor-menu"]/ul/li[4]/div/div').click()
		time.sleep(10)


		driver.find_element_by_xpath('//div[@class="overview"]/div[2]/div[2]').click()
		time.sleep(5)
		el3 = driver.find_element_by_xpath('//div[@class="se-tts_content"]/div[2]/div[1]/div[1]/span')
		
		el3.click()
		time.sleep(1)

		driver.find_element_by_xpath('//div[@id="se-allLanugageList"]/div[@language_id="1"]').click()

		print("Language_OK")
		time.sleep(3)
		driver.find_element_by_xpath('//div[@class="se-tts_content"]/div[3]/span/div/div[1]/span').click()
		time.sleep(1)
		driver.find_element_by_xpath('//div[@id="se-allVoiceList"]/div[34]').click()
		print("Tom human ok")
		time.sleep(1)

		strText=self.txtContent.get("1.0", "end-1c")
		driver.find_element_by_xpath('//div[@class="se-tts_content"]/div[4]/textarea').clear()
		driver.find_element_by_xpath('//div[@class="se-tts_content"]/div[4]/textarea').send_keys(strText)
		print("text Writing is ok")
		time.sleep(2)
		driver.find_element_by_xpath('//div[@class="se-tts_content"]/div[6]/span[3]').click()
		print("Audio Saved !")
		time.sleep(5)
		driver.find_element_by_xpath('//div[@class="overview"]/div[2]/div[1]').click()
		time.sleep(1)
		driver.find_element_by_xpath('//div[@id="se-save-button"]/span').click()
		
		time.sleep(2)
		driver.switch_to.window(parentGUID);

		driver.implicitly_wait(30)
		time.sleep(10)
		driver.find_element_by_xpath('//div[@id="row2704914"]/div[8]/div/div[3]/a').click()



		driver.get('https://vhss.oddcast.com/admin/publishWizard_splash.php?ss=2704914&sitepal=1&hidebox=undefined')
		driver.set_window_position(-2000, -2000)

		driver.implicitly_wait(10)
		button = driver.find_element_by_xpath('//div[@id="divOptions_Main"]/div[4]/a')
		driver.set_window_position(-2000, -2000)
		ahref = button.get_attribute('href')

		driver.get(ahref)

		time.sleep(10)

		
		driver.find_element_by_xpath('//button[@id="btnGenerate"]').click()
		time.sleep(10)
		driver.find_element_by_xpath('//button[@id="record"]').click()
		time.sleep(60)
		driver.find_element_by_xpath('//button[@id="download1"]').click()
		time.sleep(20)
		driver.quit()

		messagebox.showwarning("Message", "The video was made successfully.") 

root.resizable(False, False) 
My_App(root)
root.mainloop()
