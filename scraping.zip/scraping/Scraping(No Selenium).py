import re
import requests as r
from bs4 import BeautifulSoup
from logzero import logger

NUM_RETRIES = 5

class BCAEndPoint:
    """
    BCAssessmentEndPoint is a class to get data from bcassessment.ca directly from its end point
    BCAssessment has given id, called `info_code` here to each property of their database,
    this info_code will be used to send request to BCA end point

    there are 4 main functions:
    1. get_prop_data_via_pid(pid_no)
    input: pid_no
    output: dictionary data for the specific PID
    2. get_prop_data_via_address(address)
    input: address
    output: dictionary data for the specific address or first suggestion from BCA
    3. crawl_entire_bca_web(code)
    input: starter code which become the starting point for the crawler
    for ex: crawl_entire_bca_web('QTAwMDAwMzNQRQ==')
    output: list of dictionary embedded in `scraping_results`
    4. get_entire_data_via_pid()
    input: None
    output: list of dictionary embedded in `scraping_results`

    there are 5 support functions:
    - to get info_codes of the property
    1. _get_info_code_via_pid(pid_no)
    2. _get_info_code_via_address(address)
    - tools to get the crawler running by getting:
        a. nearby properties
        b. properties with similar sales
    3. _get_nearby_codes(info_code)
    4. _get_similar_sales_codes(info_code)
    - to get property data by using info_code
    5. _get_prop_data(info_code)
    """
    def __init__(self):
        self.main_url = 'https://www.bcassessment.ca/Property'
        # this is used for crawling (func 3) and scraping via its PID number (func 4)
        self.scraped_codes = set()
        self.scraping_results = []


    # get info code from pid number
    def _get_info_code_via_pid(self, pid_no):
        try:
            pid_no = str(pid_no).replace('-','')
            if pid_no.isnumeric():
                url = f'{self.main_url}/Search/GetByPid/{pid_no}'
                response = r.get(url)
                resp_text = response.text
                if 'found_no_results' not in resp_text:
                    resp_json = response.json()
                    info_code = resp_json.get('aaData')[0][-1]
                else:
                    logger.error(f'No results for: {pid_no}')
                    info_code = None
            return info_code

        except Exception as e:
            logger.error(f'Error fetching info_code for: {pid_no}\n{e}')

    # get info code from address
    def _get_info_code_via_address(self, address):
        try:
            url = f'{self.main_url}/Search/GetByAddress/?addr={address}'
            response = r.get(url)
            resp_json_list = response.json()
            # get the first suggestions
            resp_json = resp_json_list[0]
            code = resp_json['value']
            if code and len(code) == 16:
                info_code = code
            else:
                logger.error(f'No results for: {address}')
                info_code = None
            return info_code

        except Exception as e:
            logger.error(f'Error fetching info_code for: {address}\n{e}')

    # get info codes of nearby properties
    def _get_nearby_codes(self, info_code):
        url = f'{self.main_url}/Nearby'
        payload = {'oid': info_code}

        retries_left = NUM_RETRIES
        while retries_left > 0:
            try:
                response = r.post(url, data=payload)
                resp_text = response.text
                nearby_codes = re.findall(r'\"\/Property/Info/(.*?)/', resp_text)
                break
            except Exception as e:
                logger.error(f'Error fetching nearby codes for: {info_code}\n{e}')
                retries_left -= 1
                nearby_codes = None

        return nearby_codes

    # get info codes of properties with similar sales
    def _get_similar_sales_codes(self, info_code):
        url = f'{self.main_url}/SimilarSales'
        payload = {'oid': info_code}

        retries_left = NUM_RETRIES
        while retries_left > 0:
            try:
                response = r.post(url, data=payload)
                resp_text = response.text
                similar_sales_codes = re.findall(r'\"\/Property/Info/(.*?)/', resp_text)
                break
            except Exception as e:
                logger.error(f'Error fetching similar_sales codes for: {info_code}\n{e}')
                retries_left -= 1
                similar_sales_codes = None

        return similar_sales_codes

    # get property data based on info_code
    def _get_prop_data(self,info_code):
        url = f'{self.main_url}/Info/{info_code}'
        # sending the request
        retries_left = NUM_RETRIES
        while retries_left > 0:
            try:
                response = r.get(url)
                resp_text = response.text
                if 'mainaddresstitle' in resp_text:
                    break
                retries_left -= 1
            except Exception as e:
                logger.error(f'Error fetching data for: {info_code}\n{e}')
                retries_left -= 1
                resp_text = ''

        # start exracting the soup
        soup = BeautifulSoup(resp_text,'html.parser')

        data = {}

        data['id'] = info_code

        address = soup.find(id='mainaddresstitle')
        if address:
            data['address'] = address.text.strip()

        area_juris = soup.find(id='areajursrolltitlebox')
        if area_juris:
            area_juris_text = area_juris.text.strip().replace('Area-Jurisdiction-Roll: ', '')
            data['area_juris_roll'] = area_juris_text

        tot_assess_value = soup.find(id='lblTotalAssessedValue')
        if tot_assess_value:
            data['total_value'] = tot_assess_value.text.strip()

        last_assess_date = soup.find(id='lblLastAssessmentDate')
        if last_assess_date:
            data['last_assess_date'] = last_assess_date.text.strip()

        tot_assess_land = soup.find(id='lblTotalAssessedLand')
        if tot_assess_land:
            data['land_value'] = tot_assess_land.text.strip()

        building_assess_value = soup.find(id='lblTotalAssessedBuilding')
        if building_assess_value:
            data['bldg_value'] = building_assess_value.text.strip()

        prev_assess_value = soup.find(id='lblPreviousAssessedValue')
        if prev_assess_value:
            data['prev_tot_value'] = prev_assess_value.text.strip()

        prev_assess_land = soup.find(id='lblPreviousAssessedLand')
        if prev_assess_land:
            data['prev_land_value'] = prev_assess_land.text.strip()

        prev_building_value = soup.find(id='lblPreviousAssessedBuilding')
        if prev_building_value:
            data['prev_bldg_value'] = prev_building_value.text.strip()

        image_div = soup.find(id='assessmentImageDiv')
        if image_div:
            image_link = image_div.find('img').get('src')
            data['img'] = image_link.strip()

        year_built = soup.find(id='lblYearBuilt')
        if year_built:
            data['year_built'] = year_built.text.strip()

        desc = soup.find(id='lblDescription')
        if desc:
            data['desc'] = desc.text.strip()

        no_bedrooms = soup.find(id='lblBedrooms')
        if no_bedrooms:
            data['no_bedrooms'] = no_bedrooms.text.strip()

        no_bathrooms = soup.find(id='lblBathRooms')
        if no_bedrooms:
            data['no_bathrooms'] = no_bathrooms.text.strip()

        car_ports = soup.find(id='lblCarPorts')
        if car_ports:
            data['carports'] = car_ports.text.strip()

        garages = soup.find(id='lblGarages')
        if garages:
            data['garages'] = garages.text.strip()

        land_size = soup.find(id='lblLandSize')
        if land_size:
            data['land_size'] = land_size.text.strip()

        first_floor_area = soup.find(id='lblFirstFloorArea')
        if first_floor_area:
            data['first_floor_area'] = first_floor_area.text.strip()

        second_floor_area = soup.find(id='lblSecondFloorArea')
        if second_floor_area:
            data['second_floor_area'] = second_floor_area.text.strip()

        bsmnt_fin_area = soup.find(id='lblBasementFinishArea')
        if bsmnt_fin_area:
            data['bsmnt_fin_Area'] = bsmnt_fin_area.text.strip()

        strata_area = soup.find(id='lblStrataTotalArea')
        if bsmnt_fin_area:
            data['strata_area'] = strata_area.text.strip()

        stories_building = soup.find(id='lblStoriesBuilding')
        if stories_building:
            data['building_storeys'] = stories_building.text.strip()

        gross_lease_area = soup.find(id='lblGrossLeasableArea')
        if gross_lease_area:
            data['gross_lease_area'] = gross_lease_area.text.strip()

        net_lease_area = soup.find(id='lblNetLeasableArea')
        if net_lease_area:
            data['net_leasable_area'] = net_lease_area.text.strip()

        no_unit_apt = soup.find(id='lblNumberUnitApartment')
        if no_unit_apt:
            data['no_apt_units'] = no_unit_apt.text.strip()

        legal_desc = soup.find(id='lblLegalDescription')
        if legal_desc:
            data['legal_desc'] = []
            desc_list = legal_desc.findAll('p')
            desc_list_text = [x.text.strip() for x in desc_list]
            for desc in desc_list_text:
                if 'pid' in desc.lower():
                    data['pid'] = desc.replace('PID: ', '').strip()
                else:
                    data['legal_desc'].append(desc)
            data['legal_desc'] = ". ".join(data['legal_desc']).strip()

        sales_history = soup.find(id='lblSalesHistory')
        if sales_history:
            sales_history_list = sales_history.findAll('tr')
            for no, row in enumerate(sales_history_list):
                content = row.findAll('td')
                content_text = [x.text for x in content]
                if len(content_text) == 2:
                    key_date = f'sales_hist_{no}_date'
                    key_price = f'sales_hist_{no}_price'
                    data[key_date] = content_text[0].strip()
                    data[key_price] = content_text[1].strip()

        manf_width = soup.find(id='manufacturehomewidth')
        if manf_width:
            data['manu_home_width'] = manf_width.text.strip()

        manf_length = soup.find(id='manufacturehomeLength')
        if manf_length:
            data['manu_home_length'] = manf_length.text.strip()

        manf_total_area = soup.find(id='manufacturehomeTotalarea')
        if manf_total_area:
            data['manu_total_area'] = manf_total_area.text.strip()

        # get coordinates
        script_items = soup.find('body').findAll('script')
        if script_items:
            # find script tag containing location
            script_loc = [str(x) for x in script_items if 'var mapInitialCenter' in str(x)]
            if script_loc:
                str_loc = script_loc[0]
                # extract the coordinates
                lng_lat_regex = re.search(r'\[(.*?)\]', str_loc)
                if lng_lat_regex:
                    lng_lat_str = lng_lat_regex.groups(1)[0]
                    lng, lat = lng_lat_str.split(',')
                    data['latitude'] = lat.strip()
                    data['longitude'] = lng.strip()

        # function to rename field names of the data
        def _rename_headers(data):
            headers = {
                'id': 'bcAssessmentID',
                'address': 'address',
                'area_juris_roll': 'areaJurisdicationRoll',
                'last_assess_date': 'bcAssessmentLastAssessmentDate',
                'total_value': 'bcAssessmentTotalValue',
                'land_value': 'bcAssessmentLandValue',
                'bldg_value': 'bcAssessmentBuildingValue',
                'prev_tot_value': 'bcAssessmentPreviousYearValue',
                'prev_land_value': 'bcAssessmentPreviousYearLandValue',
                'prev_bldg_value': 'bcAssessmentPreviousBuldingValue',
                'img': 'propImage',
                'year_built': 'yearBuilt',
                'desc': 'description',
                'no_bedrooms': 'noBedrooms',
                'no_bathrooms': 'noBaths',
                'carports': 'carPorts',
                'garages': 'garages',
                'land_size': 'lotSizeSqFeet',
                'first_floor_area': 'floorAreaFinMainFloor',
                'second_floor_area': 'floorAreaFinAboveMain',
                'bsmnt_fin_Area': 'floorAreaFinBsmt',
                'strata_area': 'strataArea',
                'building_storeys': 'buildingStoreys',
                'gross_lease_area': 'grossLeasableArea',
                'net_leasable_area': 'netLeasableArea',
                'no_apt_units': 'noAptUnits',
                'legal_desc': 'legalDescription',
                'pid': 'pidNo',
                'manu_home_width': 'manufacturedHomeWidth',
                'manu_home_length': 'manufacturedHomeLength',
                'manu_total_area': 'manufacturedHomeArea',
                'latitude': 'latitude',
                'longitude': 'longitude'
            }

            # creating header for sales history
            total_no = 30
            for no in range(0, total_no + 1):
                headers[f'sales_hist_{no}_date'] = f'salesHist{no}_date'
                headers[f'sales_hist_{no}_price'] = f'salesHist{no}_price'


            renamed_data = {}
            for key, value in data.items():
                if key in headers.keys():
                    new_key = headers.get(key)
                    renamed_data[new_key] = value
                else:
                    renamed_data[key] = value

            return renamed_data

        # rename the field name of the data
        data = _rename_headers(data)

        return data

    # get BCA property data via PID no
    def get_prop_data_via_pid(self, pid_no):
        try:
            info_code = self._get_info_code_via_pid(pid_no)
            prop_data = self._get_prop_data(info_code)
            return prop_data
        except Exception as e:
            logger.error(f'Error fetching property data via PID: {pid_no}\n{e}')

    # get BCA propert data from address
    def get_prop_data_via_address(self, address):
        try:
            info_code = self._get_info_code_via_address(address)
            prop_data = self._get_prop_data(info_code)
            return prop_data
        except Exception as e:
            logger.error(f'Error fetching property data via address: {address}\n{e}')

    # crawling entire BCA website
    def crawl_web(self, code):
        try:
            # get the property data
            scraping_result = self._get_prop_data(code)
            logger.error(code)
            self.scraping_results.append(scraping_result)

            # store the code
            self.scraped_codes.add(code)

            # get nearby and similar sales code
            nearby_codes = self._get_nearby_codes(code)
            similar_sales_codes = self._get_similar_sales_codes(code)
            add_codes = nearby_codes + similar_sales_codes

            # looping through the new list of codes
            for add_code in add_codes:
                if add_code not in self.scraped_codes:
                    self.crawl_web(add_code)

        except Exception as e:
            logger.error(f'Error crawling code : {code}\n{e}')

    # scrape all PID no in BCA website
    def get_entire_data_via_pid(self):
        # looping through all possible pid number
        for no in range(int(1e9)):
            try:
                pid_no = f"{no:09d}"
                scraping_result = self.get_prop_data_via_pid(pid_no)
                self.scraping_results.append(scraping_result)
            except Exception as e:
                logger.error(f'Error fetching property data via PID: {pid_no}\n{e}')
