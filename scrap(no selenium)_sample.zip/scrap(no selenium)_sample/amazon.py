from bs4 import BeautifulSoup
import requests
import time
import queue
import threading
from log import log
from concurrent.futures import ThreadPoolExecutor
from timer import timer
from constants import ASINLIST1, DBHOST, DBUSERNAME, DBPASSWORD, DBNAME, DBPORT, ASINLIST, ASINLIST_TEST, PROXIES, HEADERS
import concurrent.futures
#import pymysql
import mysql.connector
from mysql.connector import Error
#from retry_requests import retry

asinList = ASINLIST

mainURL = "https://www.amazon.fr/gp/product"
ukURL = "https://www.amazon.co.uk/gp/product"
itURL = "https://www.amazon.it/gp/product"
deURL = "https://www.amazon.de/gp/product"
esURL = "https://www.amazon.es/gp/product"
secondURL = "https://www.amazon.fr/gp/offer-listing"


print("ASIN : 1 ~ " + str(len(asinList)))


def manageDB(product):
	try:
		mydb = mysql.connector.connect(
			host=DBHOST,
			user=DBUSERNAME,
			password=DBPASSWORD,
			database=DBNAME,
			port=DBPORT,
		)
		mycursor = mydb.cursor()
		sql = "DELETE FROM products WHERE Asin = '" + product[0] + "'"
		mycursor.execute(sql)
		mydb.commit()
		log('i', "asin: {}".format(product[0]))
		sql = "INSERT INTO products (Asin, Ean, Title, Description, Features, Images, Root_Category, Brand, Model, Price, Shipping_fees, Shipping_Time_Delivery, Sold_by, Delivered_by, Seller_name, Seller_rating, Seller_number_reviews, isPrime, isInStock, Stock_amazon_quantity, isProductNew, Rating, Number_Reviews, Coupon, UK_Price, UK_Shipping_fees, UK_isInStock, IT_Price, IT_Shipping_fees, IT_isInStock, DE_Price, DE_Shipping_fees, DE_isInStock, ES_Price, ES_Shipping_fees, ES_isInStock, Color) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
		# val = (Asin, Ean, Title, Description, Features, Images, Root_Category, Brand, Model, Price, Shipping_fees,
		# 	   Shipping_Time_Delivery, Sold_by, Delivered_by, Seller_name, Seller_rating, Seller_number_reviews, isPrime,
		# 	   isInStock, Stock_amazon_quantity, isProductNew, Rating, Number_Reviews, Coupon, UK_Price, UK_Shipping_fees,
		# 	   UK_isInStock, IT_Price, IT_Shipping_fees, IT_isInStock, DE_Price, DE_Shipping_fees, DE_isInStock, ES_Price,
		# 	   ES_Shipping_fees, ES_isInStock, Color)
		val = (product[0], product[1], product[2], product[3], product[4], product[5], product[6], product[7], product[8], product[9], product[10],
			   product[11], product[12], product[13], product[14], product[15], product[16], product[17],
			   product[18], product[19], product[20], product[21], product[22], product[23], product[24], product[25],
			   product[26], product[27], product[28], product[29], product[30], product[31], product[32], product[33],
			   product[34], product[35], product[36])

		mycursor.execute(sql, val)
		mydb.commit()
	except Error as e:
		print("Error while connecting to MySQL", e)

def apiCall(url):
	while True:
		try:
			# log('i', "url: {}".format(url))
			# response = retry(retries=10, status_to_retry=(500, 502, 503, 504, 404)).get(url, timeout=10, headers=HEADERS, proxies=PROXIES)

			response = requests.get(url, timeout=40, headers=HEADERS, proxies=PROXIES)
		except Exception as ex:
			time.sleep(1)
			continue
		if response.status_code == 200:
			if response.text:
				log('i', "asin: {}".format(response.status_code))
				return response.text
		elif response.status_code == 400:
			log("f", "BadRequest")
			apiCall(url)
		elif response.status_code == 500:
			log('f', "Internal Server Error")
			apiCall(url)
		else:
			log('f', "Unknown Error Code: {}".format(response.status_code))
			apiCall(url)

def scraper():
	while True:
		asin = q.get()
		if asin is None:
			break
		Asin = ""
		Title = ""
		Root_Category = ""
		Images = ""
		Description = ""
		Features = ""
		Brand = ""
		Color = ""
		Price = ""
		Shipping_fees = ""
		Shipping_Time_Delivery = ""
		isInStock = "false"
		Stock_amazon_quantity = ""
		Manufacturer = ""
		Model = ""
		Ean = ""
		Rating = "0"
		Number_Reviews = "0"
		Sold_by = "Amazon"
		Delivered_by = "Amazon"
		Coupon = ""
		isPrime = "false"
		isProductNew = "false"
		Seller_name = ""
		Seller_rating = ""
		Seller_number_reviews = ""
		IT_Price = ""
		IT_isInStock = "false"
		IT_Shipping_fees = ""
		UK_Price = ""
		UK_isInStock = "false"
		UK_Shipping_fees = ""
		DE_Price = ""
		DE_isInStock = "false"
		DE_Shipping_fees = ""
		ES_Price = ""
		ES_isInStock = "false"
		ES_Shipping_fees = ""

		url = f'{mainURL}/{asin}'

		data = apiCall(url)
		soup = BeautifulSoup(data, 'html.parser')

		# nTemp = 0

		# while True:
		# 	nTemp = nTemp + 1
		# 	data = apiCall(url)
		# 	soup = BeautifulSoup(data, 'html.parser')
		# 	Tag = soup.select_one('#navbar')
		# 	if Tag:
		# 		break
		# 	if nTemp == 7:
		# 		break

		Asin = asin

		try:
			Title = soup.select_one('#productTitle').text.strip()
		except Exception as e:
			print("Title: " + str(e))

		try:
			Root_Category = soup.select_one('#wayfinding-breadcrumbs_feature_div a').text.strip()
		except Exception as e:
			print("Root_Category: " + str(e))

		try:
			ImageItem = soup.find("img", id='landingImage')
			if ImageItem:
				Images = ImageItem['data-old-hires']
				if Images == "":
					Images = ImageItem['data-a-dynamic-image'].split(":")[0] + ":" + ImageItem['data-a-dynamic-image'].split(":")[1]
					Images = Images[2:-1]
		except Exception as e:
			print("Images: " + str(e))

		try:
			Description = soup.select_one('#productDescription').text.strip()
		except Exception as e:
			print("Description: " + str(e))
		if Description == "":
			try:
				Description = soup.select_one('div.launchpad-text-left-justify').text.strip()
			except Exception as e:
				print("Description: " + str(e))

		try:
			Features = soup.select_one('#feature-bullets').text.strip()
		except Exception as e:
			print("Features: " + str(e))

		rows = soup.select('table#productDetails_techSpec_section_1 tr')
		for row in rows:
			temp = row.select_one('.prodDetSectionEntry').text.strip()
			if temp == "Marque":
				Brand = row.select_one('td.a-size-base').text.strip()
			if temp == "Couleur":
				Color = row.select_one('td.a-size-base').text.strip()
			if temp == "Fabricant":
				Manufacturer = row.select_one('td.a-size-base').text.strip()
			if temp == "Numéro du modèle":
				Model = row.select_one('td.a-size-base').text.strip()

		rows = soup.select('table#product-specification-table tr')
		for row in rows:
			temp = row.select_one('th').text.strip()
			if temp == "Ean":
				Ean = row.select_one('td').text.strip()

		try:
			Price = soup.select_one('#price_inside_buybox').text.strip().replace(",", ".")
		except Exception as e:
			print("Price: " + str(e))
		if Price == "":
			try:
				Price = soup.select_one('#newBuyBoxPrice').text.strip().replace(",", ".")
			except Exception as e:
				print("Price: " + str(e))
			if Price == "":
				try:
					Price = soup.select_one('#buyNew_noncbb span').text.strip().replace(",", ".")
				except Exception as e:
					print("Price: " + str(e))

		try:
			Shipping_fees_Temp = soup.select_one('#price-shipping-message b').text.strip()
			Shipping_fees_Temp_Array = Shipping_fees_Temp.split(" ")
			for temp in Shipping_fees_Temp_Array:
				if temp.find(",") != -1:
					Shipping_fees = temp.replace(",", ".")
					if Shipping_fees.find("€") == -1:
						Shipping_fees += " €"
		except Exception as e:
			print("Shipping_fees: " + str(e))

		try:
			Shipping_Time_Temp = soup.select_one('#ddmDeliveryMessage b').text.strip()

			Shipping_Time_Temp_Array = Shipping_Time_Temp.split(" ")
			if len(Shipping_Time_Temp_Array) == 5:
				Shipping_Time_Delivery = str(int(Shipping_Time_Temp_Array[3]) + 30 - int(Shipping_Time_Temp_Array[0]))
			elif len(Shipping_Time_Temp_Array) == 4:
				Shipping_Time_Delivery = str(int(Shipping_Time_Temp_Array[2]) - int(Shipping_Time_Temp_Array[0]))
			else:
				Shipping_Time_Delivery = ""
		except Exception as e:
			print("Shipping_Time_Delivery: " + str(e))

		try:
			isInStock = soup.select_one('#availability span').text.strip()
			if isInStock == "En stock.":
				isInStock = "true"
				Stock_amazon_quantity = "0"
			else:
				Stock_amazon_quantity = isInStock.split(" ")[5]
				if Stock_amazon_quantity.find("exemplaire(s)") != -1:
					Stock_amazon_quantity = Stock_amazon_quantity.replace("exemplaire(s)", "")
				isInStock = "true"
		except Exception as e:
			print("isInStock: " + str(e))
		if Stock_amazon_quantity.find(".") != -1:
			Stock_amazon_quantity = "0"
		if len(isInStock) > 5:
			isInStock = "false"

		try:
			Rating = soup.select_one('#acrPopover')['title'].strip().split(" ")[0].replace(",", ".")
		except Exception as e:
			print("Rating: " + str(e))

		try:
			Number_Reviews = soup.select_one('#acrCustomerReviewText').text.strip().split(" ")[0]
		except Exception as e:
			print("Number_Reviews: " + str(e))

		try:
			Sold_by = soup.select_one('div#merchant-info a').text.strip()
		except Exception as e:
			print("Sold_by: " + str(e))
		if Sold_by == "":
			Sold_by = "Amazon"

		try:
			Coupon_Temp = soup.select_one('span.a-checkbox-label span').text.strip()
			Coupon_Temp_Array = Coupon_Temp.split(" ")
			for temp in Coupon_Temp_Array:
				if temp.find(",") != -1:
					if temp.find("€") == -1:
						Coupon = temp.replace(",", ".") + " €"
					else:
						Coupon = temp.replace(",", ".")
		except Exception as e:
			print("Coupon: " + str(e))

		try:
			PrimeTemp = soup.find_all("i", class_="a-icon-prime")
			if PrimeTemp:
				isPrime = "true"
		except Exception as e:
			print("isPrime: " + str(e))

		try:
			NewTemp = soup.find(id='olp-upd-new')
			if NewTemp:
				isProductNew = "true"
		except Exception as e:
			print("isProductNew: " + str(e))

		# log('i', "FR URL: {}".format(url))
		url = f'{itURL}/{asin}'
		# log('i', "IT URL: {}".format(url))
		data = apiCall(url)
		soup = BeautifulSoup(data, 'html.parser')

		# nTemp = 0

		# while True:
		# 	nTemp = nTemp + 1
		# 	data = apiCall(url)
		# 	soup = BeautifulSoup(data, 'html.parser')
		# 	Tag = soup.select_one('#navbar')
		# 	if Tag:
		# 		break
		# 	if nTemp == 7:
		# 		break

		try:
			IT_Price = soup.select_one('#price_inside_buybox').text.strip().replace(",", ".")
		except Exception as e:
			print("IT_Price: " + str(e))
		if IT_Price == "":
			try:
				IT_Price = soup.select_one('#newBuyBoxPrice').text.strip().replace(",", ".")
			except Exception as e:
				print("IT_Price: " + str(e))

		try:
			IT_isInStock = soup.select_one('#availability span').text.strip()
			if IT_isInStock == "En stock.":
				IT_isInStock = "true"
			else:
				IT_isInStock = "true"
		except Exception as e:
			print("IT_isInStock: " + str(e))
		if len(IT_isInStock) > 5:
			IT_isInStock = "false"

		try:
			IT_Shipping_fees_Temp = soup.select_one('#price-shipping-message b').text.strip()
			IT_Shipping_fees_Temp_Array = IT_Shipping_fees_Temp.split(" ")
			for temp in IT_Shipping_fees_Temp_Array:
				if temp.find(",") != -1:
					IT_Shipping_fees = temp.replace(",", ".")
					if IT_Shipping_fees.find("€") == -1:
						IT_Shipping_fees += " €"
		except Exception as e:
			print("IT_Shipping_fees: " + str(e))

		url = f'{ukURL}/{asin}'
		data = apiCall(url)
		soup = BeautifulSoup(data, 'html.parser')
		# nTemp = 0
		# while True:
		# 	nTemp = nTemp + 1
		# 	data = apiCall(url)
		# 	soup = BeautifulSoup(data, 'html.parser')
		# 	Tag = soup.select_one('#navbar')
		# 	if Tag:
		# 		break
		# 	if nTemp == 7:
		# 		break

		try:
			UK_Price = soup.select_one('#price_inside_buybox').text.strip().replace(",", ".")
		except Exception as e:
			print("UK_Price: " + str(e))
		if UK_Price == "":
			try:
				UK_Price = soup.select_one('#newBuyBoxPrice').text.strip().replace(",", ".")
			except Exception as e:
				print("UK_Price: " + str(e))

		try:
			UK_isInStock = soup.select_one('#availability span').text.strip()
			if UK_isInStock == "En stock.":
				UK_isInStock = "true"
			else:
				UK_isInStock = "true"
		except Exception as e:
			print("UK_isInStock: " + str(e))
		if len(UK_isInStock) > 5:
			UK_isInStock = "false"

		try:
			UK_Shipping_fees_Temp = soup.select_one('#price-shipping-message b').text.strip()
			UK_Shipping_fees_Temp_Array = UK_Shipping_fees_Temp.split(" ")
			for temp in UK_Shipping_fees_Temp_Array:
				if temp.find(",") != -1:
					UK_Shipping_fees = temp.replace(",", ".")
					if UK_Shipping_fees.find("€") == -1:
						UK_Shipping_fees += " €"
		except Exception as e:
			print("UK_Shipping_fees: " + str(e))

		url = f'{deURL}/{asin}'
		data = apiCall(url)
		soup = BeautifulSoup(data, 'html.parser')

		# nTemp = 0
		# while True:
		# 	nTemp = nTemp + 1
		# 	data = apiCall(url)
		# 	soup = BeautifulSoup(data, 'html.parser')
		# 	Tag = soup.select_one('#navbar')
		# 	if Tag:
		# 		break
		# 	if nTemp == 7:
		# 		break

		try:
			DE_Price = soup.select_one('#price_inside_buybox').text.strip().replace(",", ".")
		except Exception as e:
			print("DE_Price: " + str(e))
		if DE_Price == "":
			try:
				DE_Price = soup.select_one('#newBuyBoxPrice').text.strip().replace(",", ".")
			except Exception as e:
				print("DE_Price: " + str(e))

		try:
			DE_isInStock = soup.select_one('#availability span').text.strip()
			if DE_isInStock == "En stock.":
				DE_isInStock = "true"
			else:
				DE_isInStock = "true"
		except Exception as e:
			print("DE_isInStock: " + str(e))
		if len(DE_isInStock) > 5:
			DE_isInStock = "false"

		try:
			DE_Shipping_fees_Temp = soup.select_one('#price-shipping-message b').text.strip()
			DE_Shipping_fees_Temp_Array = DE_Shipping_fees_Temp.split(" ")
			for temp in DE_Shipping_fees_Temp_Array:
				if temp.find(",") != -1:
					DE_Shipping_fees = temp.replace(",", ".")
					if DE_Shipping_fees.find("€") == -1:
						DE_Shipping_fees += " €"
		except Exception as e:
			print("DE_Shipping_fees: " + str(e))

		url = f'{esURL}/{asin}'
		data = apiCall(url)
		soup = BeautifulSoup(data, 'html.parser')

		# nTemp = 0
		# while True:
		# 	nTemp = nTemp + 1
		# 	data = apiCall(url)
		# 	soup = BeautifulSoup(data, 'html.parser')
		# 	Tag = soup.select_one('#navbar')
		# 	if Tag:
		# 		break
		# 	if nTemp == 7:
		# 		break

		try:
			ES_Price = soup.select_one('#price_inside_buybox').text.strip().replace(",", ".")
		except Exception as e:
			print("ES_Price: " + str(e))
		if ES_Price == "":
			try:
				ES_Price = soup.select_one('#newBuyBoxPrice').text.strip().replace(",", ".")
			except Exception as e:
				print("ES_Price: " + str(e))

		try:
			ES_isInStock = soup.select_one('#availability span').text.strip()
			if ES_isInStock == "En stock.":
				ES_isInStock = "true"
			else:
				ES_isInStock = "true"
		except Exception as e:
			print("ES_isInStock: " + str(e))
		if len(ES_isInStock) > 5:
			ES_isInStock = "false"

		try:
			ES_Shipping_fees_Temp = soup.select_one('#price-shipping-message b').text.strip()
			ES_Shipping_fees_Temp_Array = ES_Shipping_fees_Temp.split(" ")
			for temp in ES_Shipping_fees_Temp_Array:
				if temp.find(",") != -1:
					ES_Shipping_fees = temp.replace(",", ".")
					if ES_Shipping_fees.find("€") == -1:
						ES_Shipping_fees += " €"
		except Exception as e:
			print("ES_Shipping_fees: " + str(e))

		url = f'{secondURL}/{asin}'
		data = apiCall(url)
		soup = BeautifulSoup(data, 'html.parser')

		# nTemp = 0
		# while True:
		# 	nTemp = nTemp + 1
		# 	data = apiCall(url)
		# 	soup = BeautifulSoup(data, 'html.parser')
		# 	Tag = soup.select_one('#navbar')
		# 	if Tag:
		# 		break
		# 	if nTemp == 7:
		# 		break

		try:
			Seller_name = soup.select_one('h3.olpSellerName a').text.strip()
		except Exception as e:
			print("Seller_name: " + str(e))

		try:
			Seller_rating = soup.select_one('p.a-spacing-small b').text.strip().split(" ")[0]
		except Exception as e:
			print("Seller_rating: " + str(e))

		try:
			Seller_number_reviews = soup.select_one('p.a-spacing-small').text.strip()
			Seller_number_reviews = Seller_number_reviews.split(" ")[10][1:]
		except Exception as e:
			print("Seller_number_reviews: " + str(e))

		product = []
		
		product.append(Asin)
		product.append(Ean)
		product.append(Title)
		product.append(Description)
		product.append(Features)
		product.append(Images)
		product.append(Root_Category)
		product.append(Brand)
		product.append(Model)
		product.append(Price)
		product.append(Shipping_fees)
		product.append(Shipping_Time_Delivery)
		product.append(Sold_by)
		product.append(Delivered_by)
		product.append(Seller_name)
		product.append(Seller_rating)
		product.append(Seller_number_reviews)
		product.append(isPrime)
		product.append(isInStock)
		product.append(Stock_amazon_quantity)
		product.append(isProductNew)
		product.append(Rating)
		product.append(Number_Reviews)
		product.append(Coupon)
		product.append(UK_Price)
		product.append(UK_Shipping_fees)
		product.append(UK_isInStock)
		product.append(IT_Price)
		product.append(IT_Shipping_fees)
		product.append(IT_isInStock)
		product.append(DE_Price)
		product.append(DE_Shipping_fees)
		product.append(DE_isInStock)
		product.append(ES_Price)
		product.append(ES_Shipping_fees)
		product.append(ES_isInStock)
		product.append(Color)
		if Title != "":
			manageDB(product)
			return product
		q.task_done()


NUMTHREADS = int(input("Please input the thread count: "))
q = queue.Queue()
threads = []
for i in range(NUMTHREADS):
	t = threading.Thread(target=scraper)
	t.start()
	threads.append(t)

for item in asinList:
	q.put(item)

q.join()

for i in range(len(asinList)):
	q.put(None)

for t in threads:
	t.join()
