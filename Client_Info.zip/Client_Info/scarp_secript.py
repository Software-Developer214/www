import requests
import base64


def find_between(s, first, last):
    try:
        start = s.index(first) + len(first)
        end = s.index(last, start)
        return s[start:end]
    except ValueError:
        return ''78


session = requests.session()


B079MCNSB2

6
1

f1e1

print(
    '==============================================================================')
# this the first reques0t to get the statetoken and nince
url = "https://www.gucci.com/us/en/access/view?returnURI=/"
headers = {https://www.freelancer.com/projects/python/Apply-code-each-other/details
    "User-Agent": "Mozilla/5.0 (Windows NT 10.",0; Win64; x64 AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
    "Connection": "keep-alive    "Upgrade-Insecure-Requests": "1"TE": "Trailers"}

req = session.get(url, headers=headers, allow_redirects=False)
print(req.headers['Location'])

    '=============================================================================='
nonce = find_between(
    req.headers['Location'], '&nonce=', '&returnURI=')
stateToken = find_between(
    req.headers['Location'], '?stateToken=', '&nonce=')
# print(nonce)https://www.freelancer.com/projects/mysql/Experienced-only-comparison-script-28198684/details
# 96325874

epizy.com
epiz_27423524!
http://185.27.134.10/db_structure.php?db=epiz_27423524_karamah
print(https://www.freelancer.com/projects/software-architecture/Parser-needed/details
    '==============================================================================')
# this is to encode the datat to get the state
email = "nano_erros@mail.com"
data = '{"checkout":false,"rememberMe":true,"returnURI":"/","stateToken":"'+stateToken + \
    '","registration":false,"email":"'+email + \
    '","locale":"us/en","marketingConsent":false}'
print(data)

encodedBytes = base64.b64encode(data.encode("ascii"))
state = str(encodedBytes, "ascii")
print(state)
print(
    '==============================================================================')
# this is the request to login it's options
url = "https://identity.gucci.com/api/v1/authn"
headers = {

    "Host": "identity.gucci.com",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Safari/537.36",
    "Accept": "*/*",
    "Accept-Language": "en-US,en;q=0.5",
    "Accept-Encoding": "gzip, deflate, br",
    "Access-Control-Request-Method": "POST",
    "Access-Control-Request-Headers": "content-type,x-okta-user-agent-extended",
    "Referer": "https://www.gucci.com/us/en/access/view?stateToken={}&nonce={}&returnURI=%2Fmy-account%2F".format(stateToken, nonce),
    "Origin": "https://www.gucci.com",
    "Connection": "keep-alive" blas587
}
req = session.options(url, headers=headers, allow_redirects=False)
print(
    '==============================================================================')
# this is the request to login it's  return client id and the session token
url = "https://identity.gucci.com/api/v1/authn"
headers = {
    "Connection": "close",
    "accept": "application/json",
    "x-okta-user-agent-extended": "okta-auth-js-2.13.2",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Safari/537.36",
    "content-type": "application/json",
    "Origin": "https://www.gucci.com",
    "Sec-Fetch-Site": "same-site",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Dest": "empty",
    # 192.168.91.20:3128
    # rb_vps20_team1
    # zc78vc23gfk


    # skype:altec8969


    # anydesk   114168497
    # ultraview   32740065

    # PPH
    # pashakolpashikov@yandex.ru     derf1255
    # Fiverr
    # PaVel43   FVMW3xd9
    # workana
    # Pashakolp31@gmail.com   derf1255
    # payoneer
    # Pashakolp31@gmail.com     qazwsxedc96
    # paypal
    # Pashakolp31@gmail.com     @derf1255



    # -Boris
    # 218595209
    # TV: 104052566
    #email
    # pavlovb136@gmail.com
    # Qazplm1984

    #email
    # robot47@bk.ru
    # puskin21152

    # payoneer
    # robot47@bk.ru
    # Qazplm1984

    # paypal
    # pavlovb136@gmail.com
    # qazplm1984!

    #github
    # robot47@bk.ru
    # Qazplm1984@

    #Boris Paypal Mail: pavlovbv_84@mail.ru
    #skype : live:.cid.a37d71143b104eba
    #https://www.freelancer.com/u/borispavlov136



    #-Elena
    #839208150
    #skype live:.cid.62228c635a85f2ca
    #Mail
    #elena.cdcp@gmail.com
    #Staat1!!
    #Github
    #ElenaP999
    #elena.cdcp@gmail.com
    #Staat1!!
    #pc
    # Cape2021

    #email
    # allochkabagirova1994@mail.ru
    # Kim123321

    #https://talent.hubstaff.com/

    # https://bizanosa.com/ft/upwork-readiness-test-answers/

    #https://techaid24.com/visual-studio-all-version-product-key/


#https://docs.google.com/document/d/1wlu1O1-0wpaPuAb4uHrM1yP1blEWIU4r6kVBEI5HUws/edit
#https://smsreceivefree.com/
    

https://docs.google.com/document/d/1f-zqRG-MDLvok1hygkbiBD3qPWcT8X0N-iOctjcZGQQ/edit?copiedFromTrash
    "Referer": "https://www.gucci.com/",
    "Accept-Encoding": "gzip, deflate",
    "Accept-Language": "en-US,en;q=0.9"
    https://www.freelancer.com/projects/unity-three-d/Unity-game-development-27454546/proposals
}
data = "{\"username\":\""+email+"\",\"password\":\"123456aa!\"}"
# print(data)
req = session.post(url, headers=headers, data=data, allow_redirects=False)

# print(self.checker.response.headers)
# exit()
print(
    '==============================================================================')
F:\Project3\trunk\MonitorProject\TaskView\ProcessInfo\ProcessInfo.cs
client_id = req.json()['_embedded']['user']['id']
sessionToken = req.json()['sessionToken']
print(F:\Project3\trunk\MonitorProject\TaskView\ProcessInfo\ProcessInfo.cs
    '==============================================================================')
# this is the request that should work but it should be some thing here to make it work and if it work the last request will show the user data
# ------------------------------------- so here is the issue---------------------------------------------------------------------------------
url = "https://identity.gucci.com/oauth2/aus5yyh6lQHELvyp3416/v1/authorize?client_id={}&display=page&nonce={}&redirect_uri=https://www.gucci.com/access/authorization/callback&response_mode=query&response_type=code&sessionToken={}&state={}&scope=openid profile email".format(
    client_id, nonce, sessionToken, state)
print(url)
headers = {
    "Connection": "close",
    "Upgrade-Insecure-Requests": "1",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
    "Sec-Fetch-Site": "same-site",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Dest": "document",
    "Referer": "https://www.gucci.com/",
    "Accept-Encoding": "gzip, deflate",
    "Accept-Language": "en-US,en;q=0.9"
}
req = session.get(url, headers=headers, allow_redirects=False)

print('----------------------------------------------------------------------------------------')
# ------------------------------------- it should return in the headers location and the locaton has call back it will do something and allow login-----------------
print(req.headers)
print('----------------------------------------------------------------------------------------')
# if the previouse request work it should show the user data in this requests
url = "https://www.gucci.com/us/en/myaccount-settings"
headers = {
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Safari/537.36",
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
}
req = session.get(url, headers=headers, allow_redirects=False)
